#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${CC:=cc}"
"$CC" -O2 -I. -o spc spc_sparkde.c lis.c -lm
SPC_SPARKDE_X11="$(pwd)/spark_x11.h" ./spc sparkde.sp -o sparkde
file sparkde

"$CC" -O2 -o spcde-clipboard spcde-clipboard.c -lX11
