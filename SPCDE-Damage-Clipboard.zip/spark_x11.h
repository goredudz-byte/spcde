#ifndef SPARK_X11_BRIDGE_H
#define SPARK_X11_BRIDGE_H
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <dlfcn.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <dirent.h>
#include <limits.h>
#include <sys/stat.h>
#include <signal.h>
#include <poll.h>
#include <time.h>
static char sx_file_names[128][256];
static int sx_file_count=0;
static char sx_file_dir[PATH_MAX];
/* Window decorations: X11 drawing only; Sparks decides button actions. */
#define SX_MAX_DECOR 128
typedef struct { Window client, bar; int maximized, ox,oy,ow,oh; } SXDecor;
static SXDecor sx_decors[SX_MAX_DECOR];
static int sx_decor_count=0;
static Display *sx_decor_display;
static Window sx_decor_root;
static GC sx_decor_gc;
static int sx_decor_screen_w,sx_decor_screen_h;
static SXDecor *sx_find_client(Window w){for(int i=0;i<sx_decor_count;i++)if(sx_decors[i].client==w)return &sx_decors[i];return NULL;}
static SXDecor *sx_find_bar(Window w){for(int i=0;i<sx_decor_count;i++)if(sx_decors[i].bar==w)return &sx_decors[i];return NULL;}
/* Visuals are rendered by Sparks using these small X11 drawing primitives. */
static void sx_paint_title(SXDecor *d){(void)d;}
static void sx_sync_title(Window client){
 SXDecor *d=sx_find_client(client);if(!d)return;
 XWindowAttributes a;if(!XGetWindowAttributes(sx_decor_display,client,&a))return;
 Window child;int x,y;
 XTranslateCoordinates(sx_decor_display,client,sx_decor_root,0,0,&x,&y,&child);
 XMoveResizeWindow(sx_decor_display,d->bar,x,y-22,a.width,22);
 sx_paint_title(d);
}
static void sx_decorate(int id){
 Window client=(Window)(unsigned)id;
 if(!sx_decor_display||sx_find_client(client)||sx_decor_count>=SX_MAX_DECOR||client==sx_decor_root)return;
 XWindowAttributes a;if(!XGetWindowAttributes(sx_decor_display,client,&a)||a.override_redirect||a.class==InputOnly)return;
 SXDecor *d=&sx_decors[sx_decor_count++];memset(d,0,sizeof(*d));d->client=client;
 d->bar=XCreateSimpleWindow(sx_decor_display,sx_decor_root,a.x,a.y-22,a.width,22,0,0,0x173C78);
 XSelectInput(sx_decor_display,d->bar,ExposureMask|ButtonPressMask|ButtonReleaseMask|PointerMotionMask);
 XSelectInput(sx_decor_display,client,StructureNotifyMask);
 XGrabButton(sx_decor_display,Button1,AnyModifier,client,False,ButtonPressMask,GrabModeSync,GrabModeAsync,None,None);
 XMapRaised(sx_decor_display,d->bar);sx_sync_title(client);
}
static int sx_title_action(int id,int x){
 SXDecor *d=sx_find_bar((Window)(unsigned)id);if(!d)return 0;
 XWindowAttributes a;if(!XGetWindowAttributes(sx_decor_display,d->client,&a))return 0;
 if(x>=a.width-25)return 1; /* close */
 if(x>=a.width-49)return 2; /* maximize / restore */
 return 3; /* titlebar drag */
}
static int sx_title_width_for_bar(int id){SXDecor*d=sx_find_bar((Window)(unsigned)id);if(!d)return 0;XWindowAttributes a;return XGetWindowAttributes(sx_decor_display,d->bar,&a)?a.width:0;}
static int sx_title_client(int id){SXDecor*d=sx_find_bar((Window)(unsigned)id);return d?(int)d->client:0;}
static void sx_maximize(int id){
 SXDecor*d=sx_find_client((Window)(unsigned)id);if(!d)return;
 XWindowAttributes a;if(!XGetWindowAttributes(sx_decor_display,d->client,&a))return;
 if(!d->maximized){d->ox=a.x;d->oy=a.y;d->ow=a.width;d->oh=a.height;d->maximized=1;
 XMoveResizeWindow(sx_decor_display,d->client,0,22,sx_decor_screen_w,sx_decor_screen_h-52);
 }else{d->maximized=0;XMoveResizeWindow(sx_decor_display,d->client,d->ox,d->oy,d->ow,d->oh);}
 sx_sync_title(d->client);
}
static void sx_remove_decor(int id){
 Window w=(Window)(unsigned)id;
 for(int i=0;i<sx_decor_count;i++)if(sx_decors[i].client==w){
 XDestroyWindow(sx_decor_display,sx_decors[i].bar);
 sx_decors[i]=sx_decors[--sx_decor_count];return;
 }
}
static void sx_files_refresh(void){
 const char *home=getenv("HOME"); if(!home)home="/tmp";
 snprintf(sx_file_dir,sizeof sx_file_dir,"%s/Desktop",home);
 struct stat st; if(stat(sx_file_dir,&st)!=0||!S_ISDIR(st.st_mode))mkdir(sx_file_dir,0755);
 DIR *dir=opendir(sx_file_dir); sx_file_count=0; if(!dir)return;
 struct dirent *e; while((e=readdir(dir))&&sx_file_count<128){
  if(e->d_name[0]=='.')continue;
  snprintf(sx_file_names[sx_file_count],sizeof sx_file_names[0],"%s",e->d_name);
  sx_file_count++;
 }closedir(dir);
}
static Display *sx_d; static Window sx_root,sx_bar,sx_menu; static GC sx_gc; static int sx_w,sx_h,sx_running=1;
static XEvent sx_ev; static int sx_event_type,sx_window,sx_x,sx_y,sx_detail,sx_state,sx_wid,sx_hei,sx_rootx,sx_rooty;
static int sx_error(Display*d,XErrorEvent*e){if(e->error_code==BadAccess && e->request_code==2){fprintf(stderr,"SparkDE: another window manager is running\n");exit(2);}return 0;}
static Atom sx_atom(const char *n){return XInternAtom(sx_d,n,False);}
static Window sx_drop_source; static int sx_drop_ok;
static void sx_reply(Window w,const char *type,long a,long b,long c,long d,long e){XEvent ev={0};ev.xclient.type=ClientMessage;ev.xclient.window=w;ev.xclient.message_type=sx_atom(type);ev.xclient.format=32;ev.xclient.data.l[0]=a;ev.xclient.data.l[1]=b;ev.xclient.data.l[2]=c;ev.xclient.data.l[3]=d;ev.xclient.data.l[4]=e;XSendEvent(sx_d,w,False,NoEventMask,&ev);XFlush(sx_d);}
static void sx_file_action(int i,const char *action){char path[PATH_MAX];if(i>=0&&i<sx_file_count)snprintf(path,sizeof path,"%s/%s",sx_file_dir,sx_file_names[i]);else path[0]=0;pid_t p=fork();if(p==0){close(ConnectionNumber(sx_d));execl("/opt/spcde/spcde-fileops","spcde-fileops",action,path,(char*)0);_exit(127);}}
static int sx_theme_icon(int id,int x,int y,int kind){const char*h=getenv("HOME");if(!h)return 0;char p[PATH_MAX];snprintf(p,sizeof p,"%s/.config/spcde/icon-%d.ppm",h,kind);FILE*f=fopen(p,"rb");if(!f)return 0;int w,hg,m;if(fscanf(f,"P6 %d %d %d",&w,&hg,&m)!=3||w<1||hg<1||w>64||hg>64||m!=255){fclose(f);return 0;}fgetc(f);unsigned char rgb[3];for(int j=0;j<hg;j++)for(int i=0;i<w;i++){if(fread(rgb,1,3,f)!=3){fclose(f);return 0;}XSetForeground(sx_d,sx_gc,((unsigned long)rgb[0]<<16)|((unsigned long)rgb[1]<<8)|rgb[2]);XDrawPoint(sx_d,(Window)(unsigned)id,sx_gc,x+i,y+j);}fclose(f);return 1;}
static int sx_file_kind(int i){if(i<0||i>=sx_file_count)return 0;char p[PATH_MAX];snprintf(p,sizeof p,"%s/%s",sx_file_dir,sx_file_names[i]);struct stat st;if(stat(p,&st)==0){if(S_ISDIR(st.st_mode))return 1;if(st.st_mode&0111)return 5;}const char *e=strrchr(p,'.');if(!e)return 2;if(!strcasecmp(e,".png")||!strcasecmp(e,".jpg")||!strcasecmp(e,".jpeg")||!strcasecmp(e,".webp")||!strcasecmp(e,".gif"))return 3;if(!strcasecmp(e,".zip")||!strcasecmp(e,".gz")||!strcasecmp(e,".xz")||!strcasecmp(e,".tar"))return 4;if(!strcasecmp(e,".sp")||!strcasecmp(e,".c")||!strcasecmp(e,".py")||!strcasecmp(e,".sh"))return 5;if(!strcasecmp(e,".mp4")||!strcasecmp(e,".mkv")||!strcasecmp(e,".mp3"))return 6;return 2;}
static int sx_drop_event(XEvent *ev){if(ev->type==ClientMessage){XClientMessageEvent *m=&ev->xclient;if(m->message_type==sx_atom("XdndEnter")){sx_drop_source=m->data.l[0];sx_drop_ok=0;Atom uri=sx_atom("text/uri-list");if(m->data.l[1]&1){Atom t;int f;unsigned long n,l;unsigned char *p=NULL;if(XGetWindowProperty(sx_d,sx_drop_source,sx_atom("XdndTypeList"),0,1024,False,XA_ATOM,&t,&f,&n,&l,&p)==Success&&f==32&&p){for(unsigned long i=0;i<n;i++)if(((Atom*)p)[i]==uri)sx_drop_ok=1;}if(p)XFree(p);}else for(int i=2;i<5;i++)if((Atom)m->data.l[i]==uri)sx_drop_ok=1;return 1;}if(m->message_type==sx_atom("XdndPosition")){sx_reply(m->data.l[0],"XdndStatus",sx_root,sx_drop_ok?3:0,0,0,sx_drop_ok?sx_atom("XdndActionCopy"):0);return 1;}if(m->message_type==sx_atom("XdndDrop")){if(sx_drop_ok)XConvertSelection(sx_d,sx_atom("XdndSelection"),sx_atom("text/uri-list"),sx_atom("SPCDE_DROP"),sx_root,m->data.l[2]);else sx_reply(m->data.l[0],"XdndFinished",sx_root,0,0,0,0);return 1;}}
if(ev->type==SelectionNotify&&ev->xselection.selection==sx_atom("XdndSelection")){Atom t;int f;unsigned long n,l;unsigned char *p=NULL;int ok=0;if(ev->xselection.property!=None&&XGetWindowProperty(sx_d,sx_root,ev->xselection.property,0,262144,True,AnyPropertyType,&t,&f,&n,&l,&p)==Success&&f==8&&!l&&p){int fd[2];if(pipe(fd)==0){pid_t child=fork();if(child==0){close(fd[1]);dup2(fd[0],0);close(fd[0]);close(ConnectionNumber(sx_d));execl("/opt/spcde/spcde-fileops","spcde-fileops","drop",(char*)0);_exit(127);}close(fd[0]);if(child>0){size_t off=0;while(off<n){ssize_t k=write(fd[1],p+off,n-off);if(k<=0)break;off+=k;}ok=off==n;}close(fd[1]);}}if(p)XFree(p);sx_reply(sx_drop_source,"XdndFinished",sx_root,ok,ok?sx_atom("XdndActionCopy"):0,0,0);return 1;}return 0;}
static int sx_init(void){const char *permit=getenv("SPCDE_EXPLICIT_SESSION");if(!permit||strcmp(permit,"1")){fprintf(stderr,"SPCDE: explicit session required\n");exit(64);}sx_d=XOpenDisplay(NULL);if(!sx_d){fprintf(stderr,"SparkDE: cannot open DISPLAY\n");return 0;} sx_root=DefaultRootWindow(sx_d);sx_w=DisplayWidth(sx_d,DefaultScreen(sx_d));sx_h=DisplayHeight(sx_d,DefaultScreen(sx_d));sx_gc=DefaultGC(sx_d,DefaultScreen(sx_d));XSetGraphicsExposures(sx_d,sx_gc,False);sx_decor_display=sx_d;sx_decor_root=sx_root;sx_decor_gc=sx_gc;sx_decor_screen_w=sx_w;sx_decor_screen_h=sx_h;sx_files_refresh();XSetErrorHandler(sx_error);if(XGetSelectionOwner(sx_d,XInternAtom(sx_d,"WM_S0",False))!=None){fprintf(stderr,"SPCDE: existing WM selection\n");exit(2);}XSelectInput(sx_d,sx_root,SubstructureRedirectMask|SubstructureNotifyMask|KeyPressMask|ButtonPressMask|ButtonReleaseMask|PointerMotionMask|StructureNotifyMask|PropertyChangeMask|ExposureMask);XSync(sx_d,False);XSetWindowBackground(sx_d,sx_root,0x37618B);XClearWindow(sx_d,sx_root);sx_bar=XCreateSimpleWindow(sx_d,sx_root,0,sx_h-30,sx_w,30,0,0,0xC0C0C0);XSelectInput(sx_d,sx_bar,ExposureMask|ButtonPressMask);XMapRaised(sx_d,sx_bar);sx_menu=XCreateSimpleWindow(sx_d,sx_root,0,sx_h-160,180,130,1,0x444444,0xC0C0C0);XSelectInput(sx_d,sx_menu,ExposureMask|ButtonPressMask);XGrabKey(sx_d,XKeysymToKeycode(sx_d,XK_Return),Mod4Mask,sx_root,True,GrabModeAsync,GrabModeAsync);XGrabKey(sx_d,XKeysymToKeycode(sx_d,XK_q),Mod4Mask,sx_root,True,GrabModeAsync,GrabModeAsync);XGrabKey(sx_d,XKeysymToKeycode(sx_d,XK_Escape),Mod4Mask|ShiftMask,sx_root,True,GrabModeAsync,GrabModeAsync);unsigned long ver=5;XChangeProperty(sx_d,sx_root,sx_atom("XdndAware"),XA_ATOM,32,PropModeReplace,(unsigned char*)&ver,1);signal(SIGCHLD,SIG_IGN);signal(SIGPIPE,SIG_IGN);XFlush(sx_d);return 1;}
static int sx_next(void){if(!sx_d)return 0;XSetClipMask(sx_d,sx_gc,None);if(!XPending(sx_d)){struct pollfd p={ConnectionNumber(sx_d),POLLIN,0};if(poll(&p,1,1000)==0){int old=sx_file_count;char before[sizeof sx_file_names];memcpy(before,sx_file_names,sizeof before);sx_files_refresh();static struct timespec theme_time;char tp[PATH_MAX];struct stat ts;snprintf(tp,sizeof tp,"%s/.config/spcde/icon-theme",getenv("HOME")?getenv("HOME"):"/tmp");if(!stat(tp,&ts)&&(ts.st_mtim.tv_sec!=theme_time.tv_sec||ts.st_mtim.tv_nsec!=theme_time.tv_nsec)){theme_time=ts.st_mtim;sx_window=(int)sx_root;return 12;}if(old!=sx_file_count||memcmp(before,sx_file_names,sizeof before)){sx_window=(int)sx_root;return 12;}return 0;}}XNextEvent(sx_d,&sx_ev);if(sx_drop_event(&sx_ev))return 0;sx_event_type=sx_ev.type;sx_window=(int)sx_ev.xany.window;sx_x=0;sx_y=0;sx_detail=0;sx_state=0;sx_wid=0;sx_hei=0;sx_rootx=0;sx_rooty=0;switch(sx_ev.type){case MapRequest:sx_window=(int)sx_ev.xmaprequest.window;break;case ConfigureRequest:sx_window=(int)sx_ev.xconfigurerequest.window;sx_x=sx_ev.xconfigurerequest.x;sx_y=sx_ev.xconfigurerequest.y;sx_wid=sx_ev.xconfigurerequest.width;sx_hei=sx_ev.xconfigurerequest.height;break;case ButtonPress:if(sx_find_client(sx_ev.xbutton.window)){XSetInputFocus(sx_d,sx_ev.xbutton.window,RevertToPointerRoot,CurrentTime);XRaiseWindow(sx_d,sx_ev.xbutton.window);XRaiseWindow(sx_d,sx_find_client(sx_ev.xbutton.window)->bar);XAllowEvents(sx_d,ReplayPointer,sx_ev.xbutton.time);XFlush(sx_d);return 0;}sx_window=(int)sx_ev.xbutton.subwindow;if(!sx_window)sx_window=(int)sx_ev.xbutton.window;sx_x=(sx_window==sx_bar||sx_window==sx_menu||sx_find_bar((Window)(unsigned)sx_window))?sx_ev.xbutton.x:sx_ev.xbutton.x_root;sx_y=(sx_window==sx_bar||sx_window==sx_menu||sx_find_bar((Window)(unsigned)sx_window))?sx_ev.xbutton.y:sx_ev.xbutton.y_root;sx_rootx=sx_ev.xbutton.x_root;sx_rooty=sx_ev.xbutton.y_root;sx_detail=sx_ev.xbutton.button;sx_state=sx_ev.xbutton.state;if((Window)sx_window==sx_root)XSetInputFocus(sx_d,sx_root,RevertToPointerRoot,CurrentTime);break;case ButtonRelease:sx_detail=sx_ev.xbutton.button;sx_rootx=sx_ev.xbutton.x_root;sx_rooty=sx_ev.xbutton.y_root;break;case MotionNotify:sx_x=sx_ev.xmotion.x_root;sx_y=sx_ev.xmotion.y_root;sx_state=sx_ev.xmotion.state;break;case KeyPress:sx_detail=(int)XLookupKeysym(&sx_ev.xkey,0);sx_state=sx_ev.xkey.state;break;case PropertyNotify:if(sx_ev.xproperty.window==sx_root && sx_ev.xproperty.atom==XInternAtom(sx_d,"_XROOTPMAP_ID",False)){sx_window=(int)sx_root;return 12;}break;case Expose:if(sx_ev.xexpose.window==sx_root){Region region=XCreateRegion();XEvent more=sx_ev;do{XRectangle r={more.xexpose.x,more.xexpose.y,more.xexpose.width,more.xexpose.height};XUnionRectWithRegion(&r,region,region);}while(XCheckTypedWindowEvent(sx_d,sx_root,Expose,&more));XSetRegion(sx_d,sx_gc,region);XDestroyRegion(region);}else if(sx_ev.xexpose.count)return 0;break;case UnmapNotify:sx_window=(int)sx_ev.xunmap.window;break;case DestroyNotify:sx_window=(int)sx_ev.xdestroywindow.window;break;}return sx_event_type;}
static int sx_icon_style=-1;
static int sx_icon_path(char *p,size_t n){const char *h=getenv("HOME");return h && snprintf(p,n,"%s/.spcde-icon-style",h)<(int)n;}
static int sx_icon_get(void){if(sx_icon_style<0){char p[PATH_MAX];int v=0;if(sx_icon_path(p,sizeof p)){FILE *f=fopen(p,"r");if(f){if(fscanf(f,"%d",&v)!=1)v=0;fclose(f);}}sx_icon_style=v>=0&&v<=3?v:0;}return sx_icon_style;}
static void sx_icon_set(int v){if(v<0||v>3)return;const char *home=getenv("HOME");if(home){char path[PATH_MAX];for(int i=1;i<=6;i++){snprintf(path,sizeof path,"%s/.config/spcde/icon-%d.ppm",home,i);unlink(path);}}sx_icon_style=v;char p[PATH_MAX];if(sx_icon_path(p,sizeof p)){FILE *f=fopen(p,"w");if(f){fprintf(f,"%d\n",v);fclose(f);}}}
static int sx_val(int n){switch(n){case 0:return sx_window;case 1:return sx_x;case 2:return sx_y;case 3:return sx_detail;case 4:return sx_state;case 5:return sx_wid;case 6:return sx_hei;case 7:return (int)sx_bar;case 8:return (int)sx_menu;case 9:return sx_w;case 10:return sx_h;case 11:return (int)sx_root;case 12:return sx_rootx;case 13:return sx_rooty;case 14:return (sx_state & Button1Mask)!=0;case 16:return sx_icon_get();case 15:return (sx_state & Mod4Mask)!=0;}return 0;}
static void sx_map(int id){if(sx_d)XMapWindow(sx_d,(Window)(unsigned)id);}
static void sx_raise(int id){if(sx_d){XRaiseWindow(sx_d,(Window)(unsigned)id);SXDecor *d=sx_find_client((Window)(unsigned)id);if(d)XRaiseWindow(sx_d,d->bar);XSetInputFocus(sx_d,(Window)(unsigned)id,RevertToPointerRoot,CurrentTime);}}
static void sx_move(int id,int x,int y){if(sx_d)XMoveWindow(sx_d,(Window)(unsigned)id,x,y);}
static void sx_move_relative(int id,int dx,int dy){if(!sx_d||id<=0||!sx_find_client((Window)(unsigned)id))return;Window rr,cc;int rx,ry,wx,wy;unsigned mask;if(!XQueryPointer(sx_d,sx_root,&rr,&cc,&rx,&ry,&wx,&wy,&mask)||!(mask&Button1Mask))return;XWindowAttributes a;if(XGetWindowAttributes(sx_d,(Window)(unsigned)id,&a)){XMoveWindow(sx_d,(Window)(unsigned)id,a.x+dx,a.y+dy);sx_sync_title((Window)(unsigned)id);}}
static void sx_configure(int id){if(!sx_d)return;XWindowChanges c={0};c.x=sx_x;c.y=sx_y;c.width=sx_wid;c.height=sx_hei;c.border_width=sx_ev.xconfigurerequest.border_width;c.sibling=sx_ev.xconfigurerequest.above;c.stack_mode=sx_ev.xconfigurerequest.detail;XConfigureWindow(sx_d,(Window)(unsigned)id,sx_ev.xconfigurerequest.value_mask,&c);sx_sync_title((Window)(unsigned)id);}
static void sx_draw(void){if(sx_d)XFlush(sx_d);}
static void sx_rect(int id,int x,int y,int w,int h,int color){if(!sx_d||w<=0||h<=0)return;XSetForeground(sx_d,sx_gc,(unsigned long)(unsigned)color);XFillRectangle(sx_d,(Window)(unsigned)id,sx_gc,x,y,(unsigned)w,(unsigned)h);}
/* feh owns the retained server-side wallpaper pixmap; no image decoding in the WM. */
static void sx_background(void){
 Atom actual; int fmt; unsigned long n,left; unsigned char *data=NULL;
 Atom prop=XInternAtom(sx_d,"_XROOTPMAP_ID",False);
 if(XGetWindowProperty(sx_d,sx_root,prop,0,1,False,XA_PIXMAP,&actual,&fmt,&n,&left,&data)==Success && actual==XA_PIXMAP && fmt==32 && n==1 && data){
 Pixmap pix=*(unsigned long*)data; XFree(data);
 Window r; int x,y; unsigned w,h,b,d;
 if(XGetGeometry(sx_d,pix,&r,&x,&y,&w,&h,&b,&d) && d==(unsigned)DefaultDepth(sx_d,DefaultScreen(sx_d))){
 XCopyArea(sx_d,pix,sx_root,sx_gc,0,0,w<(unsigned)sx_w?w:(unsigned)sx_w,h<(unsigned)sx_h?h:(unsigned)sx_h,0,0);return;}
 }else if(data)XFree(data);
 sx_rect((int)sx_root,0,0,sx_w,sx_h,3629451);
}
static void sx_outline(int id,int x,int y,int w,int h,int color){if(!sx_d||w<=0||h<=0)return;XSetForeground(sx_d,sx_gc,(unsigned long)(unsigned)color);XDrawRectangle(sx_d,(Window)(unsigned)id,sx_gc,x,y,(unsigned)w,(unsigned)h);}
static void sx_text(int id,int x,int y,const char *str,int color){if(!sx_d||!str)return;XSetForeground(sx_d,sx_gc,(unsigned long)(unsigned)color);XDrawString(sx_d,(Window)(unsigned)id,sx_gc,x,y,str,(int)strnlen(str,200));}
static int sx_file_count_get(void){return sx_file_count;}
static const char *sx_file_name(int i){return i>=0&&i<sx_file_count?sx_file_names[i]:"";}
static int sx_title_count(void){return sx_decor_count;}
static int sx_title_bar(int i){return i>=0&&i<sx_decor_count?(int)sx_decors[i].bar:0;}
static int sx_title_width(int i){if(i<0||i>=sx_decor_count)return 0;XWindowAttributes a;return XGetWindowAttributes(sx_d,sx_decors[i].bar,&a)?a.width:0;}
static int sx_title_maximized(int i){return i>=0&&i<sx_decor_count?sx_decors[i].maximized:0;}
static const char *sx_title_name(int i){static char buf[128];buf[0]=0;if(i<0||i>=sx_decor_count)return buf;char *name=NULL;if(XFetchName(sx_d,sx_decors[i].client,&name)&&name){snprintf(buf,sizeof(buf),"%s",name);XFree(name);}return buf;}
static int sx_file_at(int x,int y){
 for(int i=0;i<sx_file_count;i++){
  int xx=20+(i/8)*180,yy=42+(i%8)*58;
  if(x>=xx&&x<xx+155&&y>=yy&&y<yy+48)return i;
 }return -1;
}
static void sx_files_open(int index){
 if(index<0||index>=sx_file_count)return;
 char path[PATH_MAX];snprintf(path,sizeof path,"%s/%s",sx_file_dir,sx_file_names[index]);
 pid_t pid=fork();if(pid==0){
  if(sx_d)close(ConnectionNumber(sx_d));setsid();
  execlp("xdg-open","xdg-open",path,(char*)0);
  execlp("thunar","thunar",path,(char*)0);
  _exit(127);
 }
}
static void sx_popup(int mode){
 int w=mode!=1?440:220,h=mode!=1?260:300;
 int x=sx_rootx,y=sx_rooty;
 if(x+w>sx_w)x=sx_w-w;if(y+h>sx_h-30)y=sx_h-30-h;if(x<0)x=0;if(y<0)y=0;
 XMoveResizeWindow(sx_d,sx_menu,x,y,w,h);
 void *lib=dlopen("libXext.so.6",RTLD_LAZY);if(lib){
 typedef void (*shape_fn)(Display*,Window,int,int,int,XRectangle*,int,int,int);
 shape_fn shape=(shape_fn)dlsym(lib,"XShapeCombineRectangles");
 if(shape){XRectangle r[64];int n=0;for(int i=0;i<24;i++){int inset=24-i;r[n++]=(XRectangle){inset,i,w-2*inset,1};r[n++]=(XRectangle){inset,h-1-i,w-2*inset,1};}r[n++]=(XRectangle){0,24,w,h-48};shape(sx_d,sx_menu,0,0,0,r,n,0,0);}dlclose(lib);}
 XMapRaised(sx_d,sx_menu);XFlush(sx_d);
}
static void sx_menu_show(int show){if(!sx_d)return;if(show)XMapRaised(sx_d,sx_menu);else XUnmapWindow(sx_d,sx_menu);sx_draw();}
static void sx_spawn(const char*cmd){pid_t p=fork();if(p==0){if(sx_d)close(ConnectionNumber(sx_d));setsid();execl("/bin/sh","sh","-c",cmd,(char*)0);_exit(127);}}
static void sx_close(int id){if(!sx_d||id<=0)return;Atom prot=XInternAtom(sx_d,"WM_PROTOCOLS",False),del=XInternAtom(sx_d,"WM_DELETE_WINDOW",False);Atom *supported=NULL;int count=0,ok=0;if(XGetWMProtocols(sx_d,(Window)(unsigned)id,&supported,&count)){for(int i=0;i<count;i++)if(supported[i]==del)ok=1;XFree(supported);}if(ok){XEvent e={0};e.xclient.type=ClientMessage;e.xclient.window=(Window)(unsigned)id;e.xclient.message_type=prot;e.xclient.format=32;e.xclient.data.l[0]=del;e.xclient.data.l[1]=CurrentTime;XSendEvent(sx_d,(Window)(unsigned)id,False,NoEventMask,&e);}else XKillClient(sx_d,(XID)(unsigned)id);}
static void sx_stop(void){if(sx_d){XCloseDisplay(sx_d);sx_d=NULL;}}
#endif
