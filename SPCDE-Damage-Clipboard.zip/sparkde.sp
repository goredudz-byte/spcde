$import "syscalls"

// All visual composition and button decisions live in Sparks.
fn paint_icon(root, xx, yy, style)
    if style == 1
        sx_rect(root, xx + 2, yy + 2, 12, 7, 14725200)
        sx_rect(root, xx, yy + 7, 28, 18, 16764006)
        sx_outline(root, xx, yy + 7, 28, 18, 6307872)
    else if style == 2
        sx_rect(root, xx + 4, yy, 20, 25, 16777215)
        sx_outline(root, xx + 4, yy, 20, 25, 4210752)
        sx_rect(root, xx + 8, yy + 8, 12, 2, 4210752)
        sx_rect(root, xx + 8, yy + 14, 12, 2, 4210752)
    else if style == 3
        sx_rect(root, xx, yy, 26, 26, 2631720)
        sx_outline(root, xx, yy, 26, 26, 65535)
        sx_text(root, xx + 7, yy + 18, ">_", 65535)
    else
        sx_rect(root, xx, yy, 24, 24, 2575239)

fn paint_file(root, xx, yy, kind, style)
    if sx_theme_icon(root, xx, yy, kind) == 1
        return
    if kind == 1
        sx_rect(root, xx, yy + 5, 28, 21, 16764006)
        sx_rect(root, xx + 2, yy, 12, 8, 14725200)
        sx_outline(root, xx, yy + 5, 28, 21, 6307872)
    else
        paint_icon(root, xx, yy, style)
        if kind == 3
            sx_text(root, xx + 3, yy + 18, "IMG", 65280)
        else if kind == 4
            sx_text(root, xx + 3, yy + 18, "ZIP", 16776960)
        else if kind == 5
            sx_text(root, xx + 3, yy + 18, ">_", 65535)
        else if kind == 6
            sx_text(root, xx + 3, yy + 18, "AV", 16711935)
        else
            sx_text(root, xx + 3, yy + 18, "TXT", 12632256)

fn paint_bar()
    let bar = sx_val(7)
    let width = sx_val(9)
    sx_rect(bar, 0, 0, width, 30, 12632256)
    sx_outline(bar, 2, 3, 68, 23, 4210752)
    sx_text(bar, 12, 19, "Spark", 0)
    sx_text(bar, 90, 19, "Files", 0)
    sx_text(bar, 160, 19, "SPCDE | Sparks", 128)
    sx_outline(bar, width - 100, 3, 96, 23, 4210752)
    sx_text(bar, width - 90, 19, "Disable DE", 0)
    sx_draw()

fn paint_desktop()
    let root = sx_val(11)
    sx_background()
    mut i = 0
    loop
        if i >= sx_file_count_get()
            break
        let xx = 20 + (i / 8) * 180
        let yy = 42 + (i % 8) * 58
        paint_file(root, xx, yy, sx_file_kind(i), sx_val(16))
        sx_text(root, xx, yy + 38, sx_file_name(i), 16777215)
        i = i + 1
    sx_draw()

fn paint_popup(mode)
    let menu = sx_val(8)
    if mode == 1
        sx_rect(menu, 0, 0, 220, 300, 0)
        sx_rect(menu, 24, 24, 172, 252, 12632256)
        sx_text(menu, 34, 48, "Web >", 0)
        sx_text(menu, 34, 78, "Terminal >", 0)
        sx_text(menu, 34, 108, "Games >", 0)
        sx_text(menu, 34, 138, "Reset de", 0)
        sx_text(menu, 34, 168, "Node >", 0)
        sx_text(menu, 34, 198, "Htop", 0)
        sx_text(menu, 34, 228, "Wallpaper", 0)
        sx_text(menu, 34, 258, "Icon Style >", 0)
    else if mode == 2
        sx_rect(menu, 0, 0, 440, 260, 0)
        sx_rect(menu, 24, 24, 392, 212, 12632256)
        mut i = 0
        loop
            if i >= 4
                break
            sx_outline(menu, 38 + i * 94, 48, 80, 72, 0)
            i = i + 1
        sx_text(menu, 74, 88, "1", 0)
        sx_text(menu, 168, 88, "2", 0)
        sx_text(menu, 262, 88, "3", 0)
        sx_text(menu, 356, 88, "4", 0)
        sx_text(menu, 36, 150, "Custom image...", 0)
        sx_outline(menu, 24, 170, 391, 65, 0)
        sx_text(menu, 36, 191, "Change shape", 0)
        sx_text(menu, 230, 191, "Default", 0)
        sx_text(menu, 36, 222, "Scale", 0)
        sx_text(menu, 230, 222, "Gradient", 0)
    else if mode == 3
        sx_rect(menu, 0, 0, 440, 260, 0)
        sx_rect(menu, 24, 24, 392, 212, 12632256)
        sx_text(menu, 38, 48, "Desktop icon style", 0)
        mut j = 0
        loop
            if j >= 4
                break
            sx_outline(menu, 38 + j * 94, 65, 80, 100, 0)
            paint_icon(menu, 64 + j * 94, 85, j)
            if sx_val(16) == j
                sx_outline(menu, 40 + j * 94, 67, 76, 96, 255)
            j = j + 1
        sx_text(menu, 48, 148, "Classic", 0)
        sx_text(menu, 142, 148, "Retro", 0)
        sx_text(menu, 236, 148, "Paper", 0)
        sx_text(menu, 330, 148, "Neon", 0)
        sx_text(menu, 38, 210, "Installed themes...", 0)
    sx_draw()

fn paint_titles()
    mut i = 0
    loop
        if i >= sx_title_count()
            break
        let title = sx_title_bar(i)
        let width = sx_title_width(i)
        if width >= 75
            sx_rect(title, 0, 0, width, 22, 1522808)
            sx_text(title, 7, 15, sx_title_name(i), 16777215)
            sx_rect(title, width - 47, 3, 20, 16, 12632256)
            sx_rect(title, width - 24, 3, 20, 16, 12632256)
            sx_outline(title, width - 47, 3, 20, 16, 1052688)
            sx_outline(title, width - 24, 3, 20, 16, 1052688)
            if sx_title_maximized(i) == 1
                sx_text(title, width - 42, 15, "R", 1052688)
            else
                sx_text(title, width - 42, 15, "[]", 1052688)
            sx_text(title, width - 18, 15, "X", 1052688)
        i = i + 1
    sx_draw()

fn main()
    if sx_init() == 0
        print "SPCDE: X11 initialization failed"
        return
    paint_desktop()
    paint_bar()
    sx_spawn("/opt/spcde/spcde-wallpaper --restore")
    mut popup = 0
    mut file_selected = -1
    mut active = 0
    mut dragging = 0
    mut dragwin = 0
    mut lastx = 0
    mut lasty = 0
    loop
        let event = sx_next()
        let win = sx_val(0)
        let x = sx_val(1)
        let y = sx_val(2)
        let key = sx_val(3)
        let state = sx_val(4)
        if event == 20
            sx_map(win)
            sx_decorate(win)
            sx_raise(win)
            active = win
            paint_titles()
        if event == 23
            sx_configure(win)
            paint_titles()
        if event == 17 or event == 18
            if win == dragwin
                dragging = 0
            sx_remove_decor(win)
        if event == 12
            if win == sx_val(8)
                if popup != 0
                    paint_popup(popup)
            else if sx_title_client(win) != 0
                paint_titles()
            else if win == sx_val(7)
                paint_bar()
            else if win == sx_val(11)
                paint_desktop()
        if event == 4
            dragging = 0
            let button = sx_val(3)
            let client = sx_title_client(win)
            if client != 0 and button == 1
                active = client
                sx_raise(client)
                let width = sx_title_width_for_bar(win)
                if x >= width - 25
                    sx_close(client)
                else if x >= width - 49
                    sx_maximize(client)
                    paint_titles()
                else
                    dragging = 1
                    dragwin = active
                    lastx = sx_val(12)
                    lasty = sx_val(13)
            else if button == 1 and win == sx_val(7)
                if x >= sx_val(9) - 100
                    break
                else if x < 75
                    popup = 1
                    sx_popup(1)
                    paint_popup(popup)
                else if x < 150
                    sx_spawn("thunar")
            else if button == 1 and win == sx_val(8)
                if popup == 1 and y >= 24 and y < 276
                    if y >= 240
                        popup = 3
                        sx_popup(3)
                        paint_popup(popup)
                    else if y >= 210
                        popup = 2
                        sx_popup(2)
                        paint_popup(popup)
                    else
                        if y < 60
                            sx_spawn("/opt/spcde/spcde-actions web")
                        else if y < 90
                            sx_spawn("/opt/spcde/spcde-actions terminal")
                        else if y < 120
                            sx_spawn("/opt/spcde/spcde-actions games")
                        else if y < 150
                            sx_spawn("/opt/spcde/spcde-actions reset")
                        else if y < 180
                            sx_spawn("/opt/spcde/spcde-actions node")
                        else
                            sx_spawn("/opt/spcde/spcde-actions htop")
                        popup = 0
                        sx_menu_show(0)
                else if popup == 2
                    if y >= 48 and y <= 120
                        if x >= 38 and x < 118
                            sx_spawn("/opt/spcde/spcde-wallpaper 1")
                        else if x >= 132 and x < 212
                            sx_spawn("/opt/spcde/spcde-wallpaper 2")
                        else if x >= 226 and x < 306
                            sx_spawn("/opt/spcde/spcde-wallpaper 3")
                        else if x >= 320 and x < 400
                            sx_spawn("/opt/spcde/spcde-wallpaper 4")
                    else if y >= 130 and y < 170
                        sx_spawn("/opt/spcde/spcde-wallpaper")
                    else if y >= 170 and y < 202
                        if x < 220
                            sx_spawn("/opt/spcde/spcde-wallpaper --shape")
                        else
                            sx_spawn("/opt/spcde/spcde-wallpaper --default")
                    else if y >= 202 and y < 236
                        if x < 220
                            sx_spawn("/opt/spcde/spcde-wallpaper --scale")
                        else
                            sx_spawn("/opt/spcde/spcde-wallpaper --gradient")
                    popup = 0
                    sx_menu_show(0)
                else if popup == 3
                    if y >= 180
                        sx_file_action(-1, "theme")
                    if y >= 65 and y < 165
                        if x >= 38 and x < 118
                            sx_icon_set(0)
                        else if x >= 132 and x < 212
                            sx_icon_set(1)
                        else if x >= 226 and x < 306
                            sx_icon_set(2)
                        else if x >= 320 and x < 400
                            sx_icon_set(3)
                    popup = 0
                    sx_menu_show(0)
                    paint_desktop()
            else if button == 3 and win == sx_val(11)
                if sx_file_at(x, y) >= 0
                    sx_file_action(sx_file_at(x, y), "menu")
                else
                    popup = 1
                    sx_popup(1)
                    paint_popup(popup)
            else if button == 1 and win == sx_val(11)
                popup = 0
                sx_menu_show(0)
                let selected = sx_file_at(x, y)
                if selected >= 0
                    if file_selected == selected
                        sx_files_open(selected)
                    file_selected = selected
                else
                    file_selected = -1
            else if button == 1
                active = win
                sx_raise(win)
        if event == 6
            if dragging == 1 and sx_val(14) == 1
                sx_move_relative(dragwin, x - lastx, y - lasty)
                lastx = x
                lasty = y
            else
                dragging = 0
        if event == 5
            if sx_val(3) == 1
                dragging = 0
        if event == 2
            if state % 8 >= 4 and win == sx_val(11)
                if key == 99 and file_selected >= 0
                    sx_file_action(file_selected, "copy")
                if key == 120 and file_selected >= 0
                    sx_file_action(file_selected, "cut")
                if key == 118
                    sx_file_action(-1, "paste")
            if key == 65293 and sx_val(15) == 1
                sx_spawn("xterm")
            if key == 113 and sx_val(15) == 1
                sx_close(active)
            if key == 65307 and sx_val(15) == 1
                break
    sx_stop()
