#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || exit 1
install -m 644 /opt/spcde/spcde.desktop /usr/share/xsessions/spcde.desktop
