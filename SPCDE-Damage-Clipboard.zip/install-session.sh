#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run with sudo'; exit 1; }
cd "$(dirname "$0")"
[ -f /usr/share/xsessions/xfce.desktop ] || { echo 'Install XFCE first'; exit 1; }
for c in feh zenity sudo visudo xfce4-clipman xclip python3 flock; do command -v "$c" >/dev/null || { echo "Missing $c"; exit 1; }; done
u=${1:-${SUDO_USER:-}}
[ -n "$u" ] || { echo "Specify graphical login account: bash install-session.sh root (or deb)"; exit 1; }
bash ./build.sh
install -d -m 755 /opt/spcde /usr/share/xsessions
for f in sparkde spcde-clipboard spcde-session spcde-wallpaper spcde-actions spcde-fileops load-spcde.sh disable-session.sh enable-session.sh memory-report.sh; do install -m 755 "$f" /opt/spcde/; done
install -d -m 755 /opt/spcde/wallpapers
install -m 644 wallpapers/*.jpg /opt/spcde/wallpapers/
install -m 644 spcde.desktop /opt/spcde/spcde.desktop
# Explicitly authorize only the selected local account to disable SPCDE globally.
u=${1:-${SUDO_USER:-}}
[ -n "$u" ] || { echo "Specify your graphical login account: bash install-session.sh root (or deb)"; exit 1; }
if [ "$u" != root ]; then
 case "$u" in *[!a-zA-Z0-9_-]*|'') exit 1;; esac
 id "$u" >/dev/null
 t=$(mktemp); trap 'rm -f "$t"' EXIT
 printf '%s ALL=(root) NOPASSWD: /opt/spcde/disable-session.sh ""\n' "$u" > "$t"
 visudo -cf "$t"
 install -m 440 "$t" /etc/sudoers.d/spcde-exit
fi
/opt/spcde/disable-session.sh
/opt/spcde/enable-session.sh
printf 'SPCDE enabled for one session; other session settings untouched.\n'
