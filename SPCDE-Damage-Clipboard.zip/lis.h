#ifndef SPARKS_LIS_H
#define SPARKS_LIS_H
#include <stddef.h>
/* LIS resolves an explicit module replacement. It does not compile or load it. */
typedef struct {
    char source[1024];
    char pkg_config[128];
} LisLibrary;
/* Returns 0 on success, -1 on invalid input, -2 if not found, -3 on invalid manifest. */
int lis_resolve(const char *root, const char *module, const char *alternative,
                LisLibrary *out, char *error, size_t error_size);
#endif
