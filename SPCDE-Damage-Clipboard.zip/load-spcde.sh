#!/bin/sh
# Launch SPCDE on its own X server from a Linux text console (TTY).
set -eu
if [ ! -x /opt/spcde/sparkde ]; then
  echo "SPCDE is not installed. Run ./build.sh && ./install-session.sh first." >&2
  exit 1
fi
if [ -n "${DISPLAY:-}" ]; then
  echo "You're already in a graphical session. Do not launch another WM over XFCE." >&2
  echo "Switch to a TTY (Ctrl+Alt+F3), log in, and run this script there." >&2
  exit 2
fi
if ! command -v startx >/dev/null 2>&1; then
  echo "Install xinit first: apt install xinit" >&2
  exit 1
fi
exec startx /opt/spcde/spcde-session --explicit-spcde -- :1
