/* =============================================================================
 *  spc - the Sparks compiler                                      (version 0.2)
 *
 *  A small, readable compiler written in C. It turns a Sparks program (.sp)
 *  into a real native program. There is NO interpreter: your code is checked,
 *  translated to C, and handed to the system C compiler, which makes machine code.
 *
 *  THE PIPELINE  (read this file top to bottom, it follows the same order!)
 *
 *    your .sp file
 *       |  1. LEXER    characters -> tokens
 *       |  2. PARSER   tokens     -> syntax tree (AST)   <- SYNTAX errors are caught here
 *       |  3. CHECKER  the tree   -> names + types       <- NAME / TYPE errors are caught here
 *       |  4. CODEGEN  the tree   -> C source code       (3 and 4 happen in one walk)
 *       |     + THE SEALER: works out who owns every piece of text and writes the
 *       |       free() calls, so programs never leak (no garbage collector at runtime)
 *       |  5. cc/gcc   C source   -> machine code
 *       v
 *    a program you can run
 *
 *  Build:  cc -Os -s -o spc spc.c
 *  Use:    ./spc game.sp --run          (see ./spc --help)
 * ============================================================================= */

#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include "lis.h"
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <setjmp.h>
#include <stdbool.h>
#include <errno.h>
#include <time.h>
#ifdef _WIN32
#include <windows.h>
#endif
#ifndef _WIN32
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#ifdef _WIN32
#include <io.h>
#define ISATTY(fd) _isatty(fd)
#define PATH_SEP '\\'
#define EXE_SUFFIX ".exe"
#define NULL_DEV "nul"
#else
#include <unistd.h>
#define ISATTY(fd) isatty(fd)
#define PATH_SEP '/'
#define EXE_SUFFIX ""
#define NULL_DEV "/dev/null"
#endif

#define VERSION    "0.11"
#define MAX_ERRORS 100
#define MAX_PARAMS 12
#define MAX_FIELDS 24

/* =============================================================================
 *  0. TINY HELPERS
 * ============================================================================= */

static void die(const char *msg) { fprintf(stderr, "spc: %s\n", msg); exit(2); }
static void *xmalloc(size_t n) { void *p = malloc(n ? n : 1); if (!p) die("out of memory"); return p; }
static void *xrealloc(void *p, size_t n) { p = realloc(p, n ? n : 1); if (!p) die("out of memory"); return p; }
static char *xstrndup(const char *s, size_t n) { char *r = xmalloc(n + 1); memcpy(r, s, n); r[n] = 0; return r; }
static char *xstrdup(const char *s) { return xstrndup(s, strlen(s)); }

/* A growing string. We build all the generated C code with these. */
typedef struct { char *s; int len, cap; } Buf;
#define BS(b) ((b).s ? (b).s : "")          /* the text inside a Buf ("" if empty) */

static void buf_reserve(Buf *b, int extra) {
    if (b->len + extra + 1 > b->cap) {
        b->cap = (b->len + extra + 1) * 2;
        if (b->cap < 64) b->cap = 64;
        b->s = xrealloc(b->s, b->cap);
    }
}
static void buf_add(Buf *b, const char *s) {
    int n = (int)strlen(s);
    buf_reserve(b, n);
    memcpy(b->s + b->len, s, n + 1);
    b->len += n;
}
static void buf_vprintf(Buf *b, const char *fmt, va_list ap) {
    va_list ap2; va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap2);
    va_end(ap2);
    buf_reserve(b, n);
    vsnprintf(b->s + b->len, n + 1, fmt, ap);
    b->len += n;
}
static void buf_printf(Buf *b, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); buf_vprintf(b, fmt, ap); va_end(ap);
}

/* "Did you mean ...?" support: how different are two words? */
static int edit_distance(const char *a, const char *b) {
    int la = (int)strlen(a), lb = (int)strlen(b);
    if (la > 40 || lb > 40) return 99;
    int d[41][41];
    for (int i = 0; i <= la; i++) d[i][0] = i;
    for (int j = 0; j <= lb; j++) d[0][j] = j;
    for (int i = 1; i <= la; i++)
        for (int j = 1; j <= lb; j++) {
            int c = tolower((unsigned char)a[i-1]) != tolower((unsigned char)b[j-1]);
            int m = d[i-1][j] + 1;
            if (d[i][j-1] + 1 < m) m = d[i][j-1] + 1;
            if (d[i-1][j-1] + c < m) m = d[i-1][j-1] + c;
            d[i][j] = m;
        }
    return d[la][lb];
}
static const char *closest(const char *name, const char **cands, int n) {
    int L = (int)strlen(name);
    if (L < 2) return NULL;
    int lim = L <= 3 ? 1 : (L <= 7 ? 2 : 3);
    const char *best = NULL; int bd = 99;
    for (int i = 0; i < n; i++) {
        if (!strcmp(name, cands[i])) continue;
        int dd = edit_distance(name, cands[i]);
        if (dd < bd) { bd = dd; best = cands[i]; }
    }
    return (best && bd <= lim && bd < L) ? best : NULL;
}

/* =============================================================================
 *  1. SOURCE FILES, TOKENS AND THE ERROR REPORTER
 * ============================================================================= */

typedef struct { char *path; char *text; } Source;
static Source srcs[64];
static int nsrcs = 0;
static int use_color = 0;

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    char *b = xmalloc(n + 1);
    size_t got = fread(b, 1, n, f); fclose(f);
    /* drop '\r' (Windows line endings) and a UTF-8 byte-order mark */
    char *w = b; size_t i = 0;
    if (got >= 3 && (unsigned char)b[0] == 0xEF && (unsigned char)b[1] == 0xBB && (unsigned char)b[2] == 0xBF) i = 3;
    for (; i < got; i++) if (b[i] != '\r') *w++ = b[i];
    *w = 0;
    return b;
}

enum {
    T_EOF, T_NEWLINE, T_INDENT, T_DEDENT, T_IDENT, T_INT, T_FLOAT, T_STRING, T_IMPORT,
    /* keywords (must stay in this order: T_LET .. T_NOT) */
    T_LET, T_MUT, T_CONST, T_FN, T_IF, T_ELSE, T_FOR, T_IN, T_LOOP, T_RETURN, T_BREAK,
    T_CONTINUE, T_PRINT, T_STRUCT, T_TRUE, T_FALSE, T_AND, T_OR, T_NOT,
    T_LPAREN, T_RPAREN, T_LBRACE, T_RBRACE, T_COMMA, T_COLON, T_DOT, T_DOTDOT, T_ARROW, T_FATARROW,
    T_ASSIGN, T_EQ, T_NE, T_LT, T_LE, T_GT, T_GE, T_PLUS, T_MINUS, T_STAR, T_SLASH, T_PERCENT,
    T_PLUSEQ, T_MINUSEQ, T_STAREQ, T_SLASHEQ,
    T_NTOK
};
static const char *tk_name[T_NTOK] = {
    "EOF", "NEWLINE", "INDENT", "DEDENT", "IDENT", "INT", "FLOAT", "STRING", "$import",
    "let", "mut", "const", "fn", "if", "else", "for", "in", "loop", "return", "break",
    "continue", "print", "struct", "true", "false", "and", "or", "not",
    "(", ")", "{", "}", ",", ":", ".", "..", "->", "=>",
    "=", "==", "!=", "<", "<=", ">", ">=", "+", "-", "*", "/", "%",
    "+=", "-=", "*=", "/="
};

typedef struct {
    int kind;
    int file, line, col, len;   /* where it is (for error messages) */
    long long ival;             /* value of an INT */
    char *sval;                 /* text of IDENT / STRING / INT / FLOAT */
} Token;

/* ---- the error reporter: every message in the compiler goes through here ---- */

static FILE *audit_log = NULL;
static int audit_byte_corrections = 0; /* logging only: no byte repair is performed */
static int audit_compilation_succeeded = 0;
static char audit_path[1200];
static void audit(const char *fmt, ...) {
    if (!audit_log) return;
    va_list ap; va_start(ap, fmt); vfprintf(audit_log, fmt, ap); va_end(ap);
    fputc('\n', audit_log);
}
static void audit_finish(void) {
    if (!audit_log) return;
    audit("[BYTE CORRECTIONS] Recorded corrections: %d (SPC does not perform automatic byte repair)", audit_byte_corrections);
    audit("[SUMMARY] Compilation: %s", audit_compilation_succeeded ? "SUCCESS" : "INCOMPLETE OR FAILED");
    fflush(audit_log); fclose(audit_log); audit_log = NULL;
    printf("\n===== Sparks --L audit: %s =====\n", audit_path);
    FILE *f = fopen(audit_path, "rb");
    if (!f) return;
    char b[4096]; size_t n;
    while ((n = fread(b, 1, sizeof b, f)) != 0) fwrite(b, 1, n, stdout);
    fclose(f);
    puts("===== End of audit =====");
}
static int n_errors = 0, n_warnings = 0;
static char *reported[512];
static int nreported = 0;

static void diag(int warn, const Token *t, const char *help, const char *fmt, va_list ap) {
    char msg[600];
    vsnprintf(msg, sizeof msg, fmt, ap);
    audit("[%s] %s (%s:%d:%d)", warn ? "WARNING" : "ERROR", msg, t ? srcs[t->file].path : "compiler", t ? t->line : 0, t ? t->col : 0);
    char key[760];                       /* don't print the same message twice */
    snprintf(key, sizeof key, "%d|%d|%d|%d|%s", warn, t ? t->file : -1, t ? t->line : 0, t ? t->col : 0, msg);
    for (int i = 0; i < nreported; i++) if (!strcmp(reported[i], key)) return;
    if (nreported < 512) reported[nreported++] = xstrdup(key);

    const char *k = use_color ? (warn ? "\033[1;33m" : "\033[1;31m") : "";
    const char *b = use_color ? "\033[1m" : "";
    const char *c = use_color ? "\033[1;36m" : "";
    const char *r = use_color ? "\033[0m" : "";
    fprintf(stderr, "%s%s%s: %s%s%s\n", k, warn ? "warning" : "error", r, b, msg, r);
    if (t) {
        Source *s = &srcs[t->file];
        fprintf(stderr, "  %s-->%s %s:%d:%d\n", c, r, s->path, t->line, t->col);
        const char *p = s->text; int ln = 1;
        while (ln < t->line && *p) { if (*p++ == '\n') ln++; }
        const char *e = p; while (*e && *e != '\n') e++;
        fprintf(stderr, "      %s|%s\n%5d %s|%s %.*s\n      %s|%s ", c, r, t->line, c, r, (int)(e - p), p, c, r);
        for (int i = 1; i < t->col && p + i - 1 < e; i++) fputc(p[i-1] == '\t' ? '\t' : ' ', stderr);
        int room = (int)(e - p) - (t->col - 1); if (room < 1) room = 1;
        int len = t->len < room ? t->len : room; if (len < 1) len = 1;
        fputs(k, stderr); for (int i = 0; i < len; i++) fputc('^', stderr); fputs(r, stderr);
        fputc('\n', stderr);
    }
    if (help) fprintf(stderr, "      %s= help:%s %s\n", c, r, help);
    fputc('\n', stderr);
    if (warn) n_warnings++;
    else if (++n_errors >= MAX_ERRORS) {
        fprintf(stderr, "Too many errors - stopping here. Fix the first ones and try again.\n");
        exit(1);
    }
}
static void error_at(const Token *t, const char *help, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); diag(0, t, help, fmt, ap); va_end(ap);
}
static void warn_at(const Token *t, const char *help, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); diag(1, t, help, fmt, ap); va_end(ap);
}

/* =============================================================================
 *  2. THE LEXER   (characters -> tokens)
 *
 *  Besides words and symbols, the lexer looks at the INDENTATION of every line.
 *  When a line is indented more than the one before, it emits an INDENT token;
 *  when less, one DEDENT token per block that ended. That is how Sparks knows
 *  where blocks start and stop, without any { } characters.
 * ============================================================================= */

typedef struct { Token *v; int n, cap; } Toks;
static void tpush(Toks *t, Token k) {
    if (t->n == t->cap) { t->cap = t->cap ? t->cap * 2 : 256; t->v = xrealloc(t->v, t->cap * sizeof(Token)); }
    t->v[t->n++] = k;
}
static Token mk(int kind, int file, int line, int col, int len) {
    Token t; memset(&t, 0, sizeof t);
    t.kind = kind; t.file = file; t.line = line; t.col = col; t.len = len;
    return t;
}

static void lex(int file, Toks *out) {
    const char *s = srcs[file].text;
    int i = 0, line = 1, ls = 0;       /* i = position, ls = where this line starts */
    int depth = 0;                     /* how many ( or { are open: newlines are ignored inside */
    int at_start = 1;                  /* are we at the start of a line? */
    int ind[128], nind = 1; ind[0] = 0;/* stack of indentation widths */
    int last_end = 1;                  /* column just after the last token (for NEWLINE position) */

    for (;;) {
        /* ---- start of a line: measure the indentation ---- */
        if (at_start && depth == 0) {
            int j = i, col = 0, tab_seen = 0;
            while (s[j] == ' ' || s[j] == '\t') {
                if (s[j] == '\t') {
                    if (!tab_seen) {
                        Token tt = mk(T_INDENT, file, line, j - ls + 1, 1);
                        error_at(&tt, "use spaces (4 per level) to indent your code", "tabs are not allowed in Sparks code");
                        tab_seen = 1;
                    }
                    col += 4;
                } else col++;
                j++;
            }
            if (s[j] == '\n' || s[j] == '\0' || (s[j] == '/' && s[j+1] == '/')) {   /* blank or comment-only line */
                while (s[j] && s[j] != '\n') j++;
                if (!s[j]) { i = j; break; }
                i = j + 1; line++; ls = i;
                continue;
            }
            i = j;
            Token t = mk(T_INDENT, file, line, i - ls + 1, 1);
            if (col > ind[nind-1]) {
                if (nind >= 127) die("code is nested too deeply");
                ind[nind++] = col;
                tpush(out, t);
            } else if (col < ind[nind-1]) {
                t.kind = T_DEDENT;
                while (nind > 1 && col < ind[nind-1]) { nind--; tpush(out, t); }
                if (col != ind[nind-1])
                    error_at(&t, "line this up with an earlier line of the same block",
                             "this line's indentation doesn't match any block above it");
            }
            at_start = 0; last_end = 1;
        }

        char c = s[i];
        if (c == '\0') break;
        if (c == '\n') {
            i++;
            if (depth == 0) { tpush(out, mk(T_NEWLINE, file, line, last_end, 1)); at_start = 1; }
            line++; ls = i;
            continue;
        }
        if (c == ' ' || c == '\t') { i++; continue; }
        if (c == '/' && s[i+1] == '/') { while (s[i] && s[i] != '\n') i++; continue; }   /* comment */

        int col = i - ls + 1;
        Token t = mk(T_EOF, file, line, col, 1);

        /* ---- numbers ---- */
        if (isdigit((unsigned char)c)) {
            int j = i;
            while (isdigit((unsigned char)s[j])) j++;
            int isf = 0;
            if (s[j] == '.' && isdigit((unsigned char)s[j+1])) {       /* 0..10 must NOT become the float "0." */
                isf = 1; j++;
                while (isdigit((unsigned char)s[j])) j++;
            }
            if (isalpha((unsigned char)s[j]) || s[j] == '_') {
                int k = j; while (isalnum((unsigned char)s[k]) || s[k] == '_') k++;
                t.len = k - i;
                error_at(&t, "names can't start with a digit, and numbers can't contain letters", "`%.*s` is not a valid number or name", k - i, s + i);
                i = k; continue;
            }
            t.len = j - i; t.sval = xstrndup(s + i, j - i);
            if (isf) t.kind = T_FLOAT;
            else {
                t.kind = T_INT;
                long long v = strtoll(t.sval, NULL, 10);
                if (t.len > 10 || v > 2147483647LL) { error_at(&t, "an int can go up to 2147483647", "this number is too big"); v = 0; }
                t.ival = v;
            }
            tpush(out, t); i = j; last_end = col + t.len;
            continue;
        }

        /* ---- words: names and keywords ---- */
        if (isalpha((unsigned char)c) || c == '_') {
            int j = i;
            while (isalnum((unsigned char)s[j]) || s[j] == '_') j++;
            t.len = j - i; t.sval = xstrndup(s + i, t.len); t.kind = T_IDENT;
            for (int k = T_LET; k <= T_NOT; k++) if (!strcmp(t.sval, tk_name[k])) { t.kind = k; break; }
            if (!strcmp(t.sval, "da") && (s[j] == '?' || s[j] == '!' || s[j] == '@')) {
                char op = s[j++];
                t.sval = xstrdup(op == '?' ? "da_check" : op == '!' ? "da_delete" : "da_incoming");
                t.len = j - i;
            }
            tpush(out, t); i = j; last_end = col + t.len;
            continue;
        }

        /* ---- $import ---- */
        if (c == '$') {
            int j = i + 1;
            while (isalpha((unsigned char)s[j])) j++;
            t.len = j - i;
            if (j - i == 7 && !strncmp(s + i, "$import", 7)) { t.kind = T_IMPORT; tpush(out, t); last_end = col + t.len; }
            else error_at(&t, "the only directive is $import", "I don't know the directive `%.*s`", j - i, s + i);
            i = j; continue;
        }

        /* ---- text in "quotes" ---- */
        if (c == '"') {
            Buf sb = {0};
            int j = i + 1, ok = 0;
            while (s[j] && s[j] != '\n') {
                if (s[j] == '"') { ok = 1; break; }
                if (s[j] == '\\') {
                    char e = s[j+1]; int ch = -1;
                    if (!e || e == '\n') break;
                    switch (e) {
                        case 'n': ch = '\n'; break;  case 't': ch = '\t'; break;
                        case '\\': ch = '\\'; break; case '"': ch = '"'; break;
                        case 'e': ch = 27; break;
                    }
                    if (ch < 0) {
                        Token et = mk(T_STRING, file, line, j - ls + 1, 2);
                        error_at(&et, "valid escapes: \\n (new line)  \\t (tab)  \\\" (quote)  \\\\ (backslash)  \\e (terminal escape)",
                                 "unknown escape `\\%c` in this text", e);
                        ch = '?';
                    }
                    char tmp[2] = { (char)ch, 0 }; buf_add(&sb, tmp); j += 2; continue;
                }
                char tmp[2] = { s[j], 0 }; buf_add(&sb, tmp); j++;
            }
            if (!ok) {
                t.len = j - i;
                error_at(&t, "end the text with another \" on the same line", "this text never ends (the closing quote is missing)");
            } else j++;
            t.kind = T_STRING; t.len = j - i; t.sval = sb.s ? sb.s : xstrdup("");
            tpush(out, t); i = j; last_end = col + t.len;
            continue;
        }

        /* ---- symbols ---- */
        int k = T_EOF, len = 1; char d = s[i+1];
        switch (c) {
            case '(': k = T_LPAREN; depth++; break;
            case ')': k = T_RPAREN; if (depth > 0) depth--; break;
            case '{': k = T_LBRACE; depth++; break;
            case '}': k = T_RBRACE; if (depth > 0) depth--; break;
            case ',': k = T_COMMA; break;
            case ':': k = T_COLON; break;
            case '.': if (d == '.') { k = T_DOTDOT; len = 2; } else k = T_DOT; break;
            case '-': if (d == '>') { k = T_ARROW; len = 2; } else if (d == '=') { k = T_MINUSEQ; len = 2; } else k = T_MINUS; break;
            case '=': if (d == '=') { k = T_EQ; len = 2; } else if (d == '>') { k = T_FATARROW; len = 2; } else k = T_ASSIGN; break;
            case '!': if (d == '=') { k = T_NE; len = 2; } else k = T_NOT; break;
            case '<': if (d == '=') { k = T_LE; len = 2; } else k = T_LT; break;
            case '>': if (d == '=') { k = T_GE; len = 2; } else k = T_GT; break;
            case '+': if (d == '=') { k = T_PLUSEQ; len = 2; } else k = T_PLUS; break;
            case '*': if (d == '=') { k = T_STAREQ; len = 2; } else k = T_STAR; break;
            case '/': if (d == '=') { k = T_SLASHEQ; len = 2; } else k = T_SLASH; break;
            case '%': k = T_PERCENT; break;
            case '&': if (d == '&') { k = T_AND; len = 2; } break;
            case '|': if (d == '|') { k = T_OR; len = 2; } break;
        }
        if (k == T_EOF) {
            if (c == ';') error_at(&t, "just press Enter instead - every line is one statement", "Sparks doesn't use `;`");
            else if (c == '[' || c == ']') error_at(&t, NULL, "square brackets (lists) are not part of Sparks yet");
            else if (c == '&') error_at(&t, "write `and` (or &&) to mean \"both\"", "a single `&` isn't used in Sparks");
            else if (c == '|') error_at(&t, "write `or` (or ||) to mean \"either\"", "a single `|` isn't used in Sparks");
            else if (c == '\'') error_at(&t, "text goes in double quotes, like \"hello\"", "single quotes aren't used in Sparks");
            else error_at(&t, NULL, "I don't understand the character `%c`", c);
            i++; continue;
        }
        t.kind = k; t.len = len; tpush(out, t);
        i += len; last_end = col + len;
    }

    /* ---- end of file: close the last line and any blocks still open ---- */
    if (!at_start && depth == 0) tpush(out, mk(T_NEWLINE, file, line, last_end, 1));
    for (; nind > 1; nind--) tpush(out, mk(T_DEDENT, file, line, 1, 1));
    tpush(out, mk(T_EOF, file, line, last_end, 1));
}

/* =============================================================================
 *  3. THE SYNTAX TREE (AST)
 * ============================================================================= */

enum {
    N_PROGRAM, N_IMPORT, N_FN, N_STRUCT, N_PARAM, N_BLOCK,
    N_LET, N_ASSIGN, N_EXPRSTMT, N_PRINT, N_IF, N_LOOP, N_FOR, N_RETURN, N_BREAK, N_CONTINUE,
    N_INT, N_FLOAT, N_STR, N_BOOL, N_IDENT, N_UNARY, N_BINARY, N_CALL, N_FIELD, N_STRUCTLIT, N_FIELDINIT,
    N_GFX, N_SPASM,
    N_NKINDS
};
static const char *nk_name[N_NKINDS] = {
    "Program", "Import", "Fn", "Struct", "Param", "Block",
    "Let", "Assign", "ExprStmt", "Print", "If", "Loop", "For", "Return", "Break", "Continue",
    "Int", "Float", "Str", "Bool", "Ident", "Unary", "Binary", "Call", "Field", "StructLit", "FieldInit", "Gfx", "Spasm"
};

typedef struct Node Node;
struct Node {
    int kind;
    Token tok;                 /* where this node is in the source */
    char *name;                /* names, text values */
    long long ival;            /* ints and bools */
    int op;                    /* operator token kind */
    int flag;                  /* N_LET: 0 let / 1 mut / 2 const.  N_EXPRSTMT: 1 = last line of a function */
    Node *a, *b, *c;           /* children, meaning depends on kind */
    Node **list; int n, cap;   /* list of children (statements, arguments, fields...) */
    char *tname; Token ttok;   /* a written-out type, like  x: f32  */
};

static Node *node(int kind, const Token *t) {
    Node *n = xmalloc(sizeof *n);
    memset(n, 0, sizeof *n);
    n->kind = kind;
    if (t) n->tok = *t;
    return n;
}
static void push(Node *p, Node *c) {
    if (p->n == p->cap) { p->cap = p->cap ? p->cap * 2 : 4; p->list = xrealloc(p->list, p->cap * sizeof(Node *)); }
    p->list[p->n++] = c;
}

static void dump_node(Node *n, int d) {
    if (!n) return;
    printf("%*s%s", d * 2, "", nk_name[n->kind]);
    if (n->kind == N_STR) printf(" \"%s\"", n->name);
    else if (n->name) printf(" %s", n->name);
    if (n->kind == N_INT || n->kind == N_BOOL) printf(" %lld", n->ival);
    if (n->kind == N_FLOAT) printf(" %s", n->tok.sval);
    if (n->kind == N_UNARY || n->kind == N_BINARY || n->kind == N_ASSIGN) printf(" '%s'", tk_name[n->op]);
    if (n->kind == N_LET) printf(" (%s)", n->flag == 0 ? "let" : n->flag == 1 ? "mut" : "const");
    if (n->tname) printf(" : %s", n->tname);
    printf("\n");
    dump_node(n->a, d + 1); dump_node(n->b, d + 1); dump_node(n->c, d + 1);
    for (int i = 0; i < n->n; i++) dump_node(n->list[i], d + 1);
}

/* =============================================================================
 *  4. THE PARSER   (tokens -> syntax tree)
 *
 *  Recursive descent: one C function per grammar rule. When the parser finds
 *  something that doesn't fit the grammar, it reports a SYNTAX ERROR, skips the
 *  rest of the broken line (and its indented block) and keeps going, so you
 *  can see several mistakes in one run.
 * ============================================================================= */

static Toks *PT;                 /* the tokens being parsed */
static int ppos;                 /* index of the current token */
static jmp_buf *cur_jb;          /* where to jump after a syntax error */

static Token *cur(void) { return &PT->v[ppos]; }
static int at(int k) { return PT->v[ppos].kind == k; }
static Token *adv(void) { Token *t = &PT->v[ppos]; if (t->kind != T_EOF) ppos++; return t; }
static int accept(int k) { if (at(k)) { adv(); return 1; } return 0; }

static const char *describe(const Token *t) {      /* a token, in words */
    static char b[4][100]; static int k;
    char *r = b[k++ & 3];
    switch (t->kind) {
        case T_EOF:     return "the end of the file";
        case T_NEWLINE: return "the end of the line";
        case T_INDENT:  return "extra indentation";
        case T_DEDENT:  return "the end of the block";
        case T_IDENT:   snprintf(r, 100, "`%s`", t->sval); return r;
        case T_INT: case T_FLOAT: snprintf(r, 100, "the number `%s`", t->sval); return r;
        case T_STRING:  return "a piece of text";
        default:        snprintf(r, 100, "`%s`", tk_name[t->kind]); return r;
    }
}

#if defined(__GNUC__)
#define NORETURN __attribute__((noreturn))
#else
#define NORETURN
#endif
NORETURN static void perr(const Token *t, const char *help, const char *fmt, ...) {   /* report, then recover */
    va_list ap; va_start(ap, fmt); diag(0, t, help, fmt, ap); va_end(ap);
    if (cur_jb) longjmp(*cur_jb, 1);
    exit(1);
}

/* After an error: skip the rest of the broken line, and the block hanging off it. */
static void parser_sync(void) {
    while (!at(T_EOF) && !at(T_NEWLINE) && !at(T_DEDENT) && !at(T_INDENT)) adv();
    if (at(T_NEWLINE)) adv();
    if (at(T_INDENT)) {
        int d = 0;
        do {
            if (at(T_INDENT)) d++; else if (at(T_DEDENT)) d--;
            if (at(T_EOF)) break;
            adv();
        } while (d > 0);
    }
}

static void expect_eol(Node *first) {            /* a statement must end at the end of the line */
    if (at(T_NEWLINE)) { adv(); return; }
    if (at(T_EOF)) return;
    Token *t = cur();
    const char *help = NULL; char hb[200];
    if (first && first->kind == N_IDENT) {
        const char *kw[] = { "print", "let", "mut", "const", "return", "loop", "for", "if", "else", "break", "continue", "struct", "fn", "window", "color", "background", "draw", "show" };
        const char *s = closest(first->name, kw, 18);
        if (s) { snprintf(hb, sizeof hb, "did you mean `%s`? (`%s` is not a Sparks word)", s, first->name); help = hb; }
    }
    if (!help) switch (t->kind) {
        case T_ASSIGN: help = "to compare two values use `==`; a single `=` stores a value"; break;
        case T_LBRACE: case T_RBRACE: help = "Sparks doesn't use { } - group lines with indentation instead"; break;
        case T_RPAREN: help = "there is a `)` with no matching `(` before it"; break;
        case T_IDENT: case T_INT: case T_FLOAT: case T_STRING:
            help = "two values are side by side - did you forget an operator (like `+`) or a comma?"; break;
        default: help = "every statement goes on its own line"; break;
    }
    perr(t, help, "I didn't expect %s here - the line should have ended before it", describe(t));
}

static void expect_close(Token open, int kind, const char *expected) {
    if (at(kind)) { adv(); return; }
    Token *c = cur();
    if (c->kind == T_EOF || c->line != open.line)
        perr(&open, "add the matching closing bracket", "this `%s` is never closed", tk_name[open.kind]);
    perr(c, NULL, "expected %s here, but found %s", expected, describe(c));
}

/* ---------- expressions (lowest precedence first) ---------- */

static Node *parse_expr(void);
static Node *parse_statement(void);

static Node *binop(Node *l, const Token *op, Node *r) {
    Node *n = node(N_BINARY, op); n->op = op->kind; n->a = l; n->b = r; return n;
}

static Node *parse_primary(void) {
    Token *t = cur();
    switch (t->kind) {
    case T_INT:    { Node *n = node(N_INT, t); n->ival = t->ival; adv(); return n; }
    case T_FLOAT:  { Node *n = node(N_FLOAT, t); n->name = t->sval; adv(); return n; }
    case T_STRING: { Node *n = node(N_STR, t); n->name = t->sval; adv(); return n; }
    case T_TRUE: case T_FALSE: { Node *n = node(N_BOOL, t); n->ival = t->kind == T_TRUE; adv(); return n; }
    case T_LPAREN: {
        Token open = *adv();
        Node *e = parse_expr();
        expect_close(open, T_RPAREN, "`)`");
        return e;
    }
    case T_IDENT: {
        Token nm = *adv();
        if (at(T_LPAREN)) {                                   /* function call */
            Token open = *adv();
            Node *n = node(N_CALL, &nm); n->name = nm.sval;
            while (!at(T_RPAREN)) {
                push(n, parse_expr());
                if (!accept(T_COMMA)) break;
            }
            expect_close(open, T_RPAREN, "`,` or `)`");
            return n;
        }
        if (at(T_LBRACE) && isupper((unsigned char)nm.sval[0])) {   /* struct literal:  Name { x: 1, y: 2 } */
            Token open = *adv();
            Node *n = node(N_STRUCTLIT, &nm); n->name = nm.sval;
            while (!at(T_RBRACE)) {
                Token *ft = cur();
                if (!at(T_IDENT)) perr(ft, "fields are written like  x: 1.0", "expected a field name, but found %s", describe(ft));
                Node *fi = node(N_FIELDINIT, ft); fi->name = ft->sval; adv();
                if (!at(T_COLON)) perr(cur(), "fields are written like  x: 1.0", "expected `:` after the field name `%s`, but found %s", fi->name, describe(cur()));
                adv();
                fi->a = parse_expr();
                push(n, fi);
                if (!accept(T_COMMA)) break;
            }
            expect_close(open, T_RBRACE, "`,` or `}`");
            return n;
        }
        Node *n = node(N_IDENT, &nm); n->name = nm.sval;
        return n;
    }
    default: break;
    }
    const char *help = "a value is a number, some text, a name, or something in ( )";
    if (t->kind == T_NEWLINE) help = "the line ended too early - an operator like `+` needs a value on its right";
    else if (t->kind >= T_LET && t->kind <= T_NOT && t->kind != T_NOT) help = "that is a reserved word, it can't be used as a name or a value";
    else if (t->kind == T_RPAREN) help = "there is a `)` with no matching `(`";
    perr(t, help, "I expected a value here, but found %s", describe(t));
    return NULL;
}

static Node *parse_postfix(void) {
    Node *e = parse_primary();
    while (at(T_DOT)) {
        adv();
        Token *nm = cur();
        if (!at(T_IDENT)) perr(nm, "example: player.score", "expected a field name after `.`, but found %s", describe(nm));
        Node *n = node(N_FIELD, nm); n->name = nm->sval; n->a = e; adv();
        e = n;
    }
    return e;
}
static Node *parse_unary(void) {
    if (at(T_MINUS)) { Token op = *adv(); Node *n = node(N_UNARY, &op); n->op = T_MINUS; n->a = parse_unary(); return n; }
    return parse_postfix();
}
static Node *parse_mul(void) {
    Node *l = parse_unary();
    while (at(T_STAR) || at(T_SLASH) || at(T_PERCENT)) { Token op = *adv(); Node *r = parse_unary(); l = binop(l, &op, r); }
    return l;
}
static Node *parse_add(void) {
    Node *l = parse_mul();
    while (at(T_PLUS) || at(T_MINUS)) { Token op = *adv(); Node *r = parse_mul(); l = binop(l, &op, r); }
    return l;
}
static Node *parse_cmp(void) {
    Node *l = parse_add();
    while (at(T_EQ) || at(T_NE) || at(T_LT) || at(T_LE) || at(T_GT) || at(T_GE)) { Token op = *adv(); Node *r = parse_add(); l = binop(l, &op, r); }
    return l;
}
static Node *parse_not(void) {
    if (at(T_NOT)) { Token op = *adv(); Node *n = node(N_UNARY, &op); n->op = T_NOT; n->a = parse_not(); return n; }
    return parse_cmp();
}
static Node *parse_and(void) {
    Node *l = parse_not();
    while (at(T_AND)) { Token op = *adv(); Node *r = parse_not(); l = binop(l, &op, r); }
    return l;
}
static Node *parse_or(void) {
    Node *l = parse_and();
    while (at(T_OR)) { Token op = *adv(); Node *r = parse_and(); l = binop(l, &op, r); }
    return l;
}
static Node *parse_expr(void) { return parse_or(); }

static Node *parse_condition(void) {
    Node *e = parse_expr();
    if (at(T_ASSIGN)) perr(cur(), "to compare two values use `==`; a single `=` stores a value", "found `=` where a true/false question was expected");
    return e;
}

/* ---------- blocks and statements ---------- */

static Node *parse_block(const char *what) {          /* NEWLINE INDENT statements DEDENT */
    Node *blk = node(N_BLOCK, cur());
    if (!at(T_NEWLINE))
        perr(cur(), "put the body on the next line, indented by 4 spaces", "I didn't expect %s here - the body of %s goes on its own indented lines", describe(cur()), what);
    adv();
    if (!at(T_INDENT)) {
        error_at(cur(), "indent the lines that belong inside (4 spaces) so Sparks knows where the block starts",
                 "expected an indented block after %s", what);
        return blk;
    }
    adv();
    jmp_buf jb, *prev = cur_jb;
    cur_jb = &jb;
    while (!at(T_DEDENT) && !at(T_EOF)) {
        volatile int before = ppos;
        if (setjmp(jb) == 0) {
            Node *s = parse_statement();
            if (s) push(blk, s);
        } else {
            parser_sync();
            if (ppos == before) adv();
        }
    }
    cur_jb = prev;
    if (at(T_DEDENT)) adv();
    return blk;
}

static void parse_type_into(Node *n) {
    Token *t = cur();
    if (!at(T_IDENT)) perr(t, "types look like `int`, `f32`, `str`, `bool` or a struct name", "expected a type name, but found %s", describe(t));
    n->tname = t->sval; n->ttok = *t; adv();
}

static Node *parse_let(void) {
    Token kw = *adv();
    Node *n = node(N_LET, &kw);
    n->flag = kw.kind == T_LET ? 0 : kw.kind == T_MUT ? 1 : 2;
    Token *nm = cur();
    if (!at(T_IDENT)) {
        const char *h = (nm->kind >= T_LET && nm->kind <= T_NOT) ? "that is a reserved word - pick another name" : "example: let score = 0";
        perr(nm, h, "expected a name after `%s`, but found %s", kw.kind == T_LET ? "let" : kw.kind == T_MUT ? "mut" : "const", describe(nm));
    }
    n->name = nm->sval; n->tok = *nm; adv();
    if (accept(T_COLON)) parse_type_into(n);
    if (!at(T_ASSIGN)) perr(cur(), "give it a starting value, like  let score = 0", "expected `=` after the name `%s`, but found %s", n->name, describe(cur()));
    adv();
    n->a = parse_expr();
    expect_eol(NULL);
    return n;
}

static Node *parse_if(void) {
    Token kw = *adv();
    Node *n = node(N_IF, &kw);
    n->a = parse_condition();
    n->b = parse_block("the `if` line");
    if (at(T_ELSE)) {
        adv();
        if (at(T_IF)) n->c = parse_if();                 /* else if ...  */
        else n->c = parse_block("`else`");
    }
    return n;
}

static Node *parse_loop(void) {
    Token kw = *adv();
    Node *n = node(N_LOOP, &kw);
    if (!at(T_NEWLINE)) n->a = parse_condition();        /* plain `loop` runs forever (until `break`) */
    n->b = parse_block("the `loop` line");
    return n;
}

static Node *parse_for(void) {
    Token kw = *adv();
    Node *n = node(N_FOR, &kw);
    Token *v = cur();
    if (!at(T_IDENT)) perr(v, "example: for i in 0..10", "expected a name for the loop counter after `for`, but found %s", describe(v));
    n->name = v->sval; n->tok = *v; adv();
    if (!at(T_IN)) perr(cur(), "example: for i in 0..10", "expected `in` after `for %s`, but found %s", n->name, describe(cur()));
    adv();
    n->a = parse_expr();
    if (!at(T_DOTDOT)) perr(cur(), "a range looks like 0..10 (it counts 0 up to 9)", "expected `..` to make a range, but found %s", describe(cur()));
    adv();
    n->b = parse_expr();
    n->c = parse_block("the `for` line");
    return n;
}

static Node *parse_simple(void) {                        /* assignment, or an expression on its own */
    Node *e = parse_expr();
    if (at(T_ASSIGN) || at(T_PLUSEQ) || at(T_MINUSEQ) || at(T_STAREQ) || at(T_SLASHEQ)) {
        Token op = *adv();
        if (e->kind != N_IDENT && e->kind != N_FIELD)
            perr(&op, "only a variable (or a field like p.x) can be changed", "you can't store a value into this");
        Node *n = node(N_ASSIGN, &op); n->op = op.kind; n->a = e; n->b = parse_expr();
        expect_eol(NULL);
        return n;
    }
    Node *n = node(N_EXPRSTMT, &e->tok); n->a = e;
    expect_eol(e);
    return n;
}

/* Graphics statements are "soft keywords": words like `draw` and `color` only act as commands when
 * they are followed by their arguments, so you can still use them as names (fn draw() ...). */
static const char *gfx_shapes[] = { "rect", "circle", "line", "text", "pixel", "box", "ring" };
static Node *parse_gfx(void) {
    Token *t = cur();
    if (!t->sval) return NULL;
    const char *w = t->sval;
    int nk = PT->v[ppos + 1].kind;
    int is = 0;
    if (!strcmp(w, "show")) is = nk == T_NEWLINE;
    else if (!strcmp(w, "window") || !strcmp(w, "color") || !strcmp(w, "background"))
        is = nk == T_INT || nk == T_FLOAT || nk == T_STRING || nk == T_IDENT;
    else if (!strcmp(w, "draw")) is = nk == T_IDENT;
    if (!is) return NULL;
    Token kw = *adv();
    Node *n = node(N_GFX, &kw);
    Buf nm = {0}; buf_add(&nm, w);
    if (!strcmp(w, "draw")) {
        Token *sh = cur();
        int ok = 0;
        for (int i = 0; i < 7; i++) if (!strcmp(sh->sval, gfx_shapes[i])) ok = 1;
        if (!ok) {
            const char *s = closest(sh->sval, gfx_shapes, 7); char hb[160];
            snprintf(hb, sizeof hb, s ? "did you mean `draw %s`?" : "you can draw: rect, circle, line, text, pixel, box, ring", s ? s : "");
            perr(sh, hb, "I don't know how to draw a `%s`", sh->sval);
        }
        buf_printf(&nm, " %s", sh->sval); adv();
    }
    n->name = nm.s;
    if (!at(T_NEWLINE)) { push(n, parse_expr()); while (accept(T_COMMA)) push(n, parse_expr()); }
    expect_eol(NULL);
    return n;
}

/* SPASM: indentation-based native assembly and literal instruction bytes. */
static Node *parse_spasm(void) {
    Token kw = *adv();
    Node *n = node(N_SPASM, &kw);
    if (!at(T_NEWLINE)) perr(cur(), "write spasm on its own line", "expected a newline after spasm");
    adv();
    if (!at(T_INDENT)) perr(cur(), "indent asm/hex lines under spasm", "expected an indented SPASM block");
    adv();
    while (!at(T_DEDENT) && !at(T_EOF)) {
        Token *op = cur();
        if (!at(T_IDENT) || (strcmp(op->sval,"asm") && strcmp(op->sval,"hex")))
            perr(op, "use asm \"nop\" or hex \"90\"", "expected asm or hex inside spasm");
        Node *line = node(N_STR, op);
        line->flag = !strcmp(op->sval, "hex");
        adv();
        if (!at(T_STRING)) perr(cur(), "put the instruction in double quotes", "expected a string after asm/hex");
        line->name = cur()->sval;
        adv();
        expect_eol(NULL);
        push(n, line);
    }
    if (at(T_DEDENT)) adv();
    if (!n->n) error_at(&kw, "add at least one asm or hex line", "empty SPASM block");
    return n;
}

static Node *parse_statement(void) {
    Token *t = cur();
    switch (t->kind) {
    case T_LET: case T_MUT: case T_CONST: return parse_let();
    case T_IF:   return parse_if();
    case T_LOOP: return parse_loop();
    case T_FOR:  return parse_for();
    case T_RETURN: {
        Token kw = *adv(); Node *n = node(N_RETURN, &kw);
        if (!at(T_NEWLINE)) n->a = parse_expr();
        expect_eol(NULL);
        return n;
    }
    case T_BREAK: case T_CONTINUE: {
        Token kw = *adv(); Node *n = node(kw.kind == T_BREAK ? N_BREAK : N_CONTINUE, &kw);
        expect_eol(NULL);
        return n;
    }
    case T_PRINT: {
        Token kw = *adv(); Node *n = node(N_PRINT, &kw);
        if (!at(T_NEWLINE)) { push(n, parse_expr()); while (accept(T_COMMA)) push(n, parse_expr()); }
        expect_eol(NULL);
        return n;
    }
    case T_ELSE:
        perr(t, "`else` must line up exactly with the `if` it belongs to", "this `else` has no `if` before it");
    case T_LBRACE: case T_RBRACE:
        perr(t, "Sparks uses indentation instead of braces: indent the lines that belong inside, by 4 spaces", "Sparks doesn't use `{ }` to group code");
    case T_INDENT:
        perr(t, "nothing above opened a block (`if`, `loop`, `for`, `fn`...), so remove the extra spaces", "this line is indented too far");
    case T_FN:
        perr(t, "define functions at the left edge of the file, outside of other code", "a function can't be defined inside another function");
    case T_STRUCT:
        perr(t, "define structs at the left edge of the file", "a struct can't be defined inside a function");
    case T_IMPORT:
        perr(t, "put $import lines at the very top of the file", "$import can't be used inside a function");
    case T_IDENT: { if (t->sval && !strcmp(t->sval, "spasm") && PT->v[ppos+1].kind == T_NEWLINE) return parse_spasm(); Node *g = parse_gfx(); if (g) return g; break; }
    default: break;
    }
    return parse_simple();
}

/* ---------- top-level declarations ---------- */

static void parse_params(Node *fn, Token open) {
    while (!at(T_RPAREN)) {
        Token *t = cur();
        if (!at(T_IDENT)) perr(t, "parameters look like  a  or  a: int", "expected a parameter name, but found %s", describe(t));
        Node *p = node(N_PARAM, t); p->name = t->sval; adv();
        for (int i = 0; i < fn->n; i++)
            if (!strcmp(fn->list[i]->name, p->name)) perr(t, "give each parameter its own name", "two parameters are both called `%s`", p->name);
        if (accept(T_COLON)) parse_type_into(p);
        push(fn, p);
        if (!accept(T_COMMA)) break;
    }
    expect_close(open, T_RPAREN, "`,` or `)`");
}

static Node *parse_fn(void) {
    Token kw = *adv();
    Node *n = node(N_FN, &kw);
    Token *nm = cur();
    if (!at(T_IDENT)) perr(nm, "example: fn greet(name)", "expected a function name after `fn`, but found %s", describe(nm));
    n->name = nm->sval; n->tok = *nm; adv();
    if (!at(T_LPAREN)) perr(cur(), "example: fn greet(name)", "expected `(` after the function name `%s`, but found %s", n->name, describe(cur()));
    Token open = *adv();
    parse_params(n, open);
    if (accept(T_ARROW)) {
        Token *rt = cur();
        if (!at(T_IDENT)) perr(rt, "example: fn size() -> int", "expected a type after `->`, but found %s", describe(rt));
        n->tname = rt->sval; n->ttok = *rt; adv();
    }
    if (at(T_FATARROW)) {                                /* fn square(n) => n * n */
        Token arrow = *adv();
        Node *blk = node(N_BLOCK, &arrow);
        Node *es = node(N_EXPRSTMT, &arrow);
        es->a = parse_expr();
        push(blk, es);
        expect_eol(NULL);
        n->a = blk;
    } else {
        n->a = parse_block("the `fn` line");
    }
    return n;
}

static void parse_struct_fields(Node *n) {
    jmp_buf jb, *prev = cur_jb;
    cur_jb = &jb;
    while (!at(T_DEDENT) && !at(T_EOF)) {
        volatile int before = ppos;
        if (setjmp(jb) == 0) {
            Token *ft = cur();
            if (!at(T_IDENT)) perr(ft, "fields are written like  x: f32", "expected a field name, but found %s", describe(ft));
            Node *p = node(N_PARAM, ft); p->name = ft->sval; adv();
            if (!at(T_COLON)) perr(cur(), "fields are written like  x: f32", "expected `:` and a type after the field name `%s`, but found %s", p->name, describe(cur()));
            adv();
            parse_type_into(p);
            expect_eol(NULL);
            push(n, p);
        } else {
            parser_sync();
            if (ppos == before) adv();
        }
    }
    cur_jb = prev;
    if (at(T_DEDENT)) adv();
}

static Node *parse_struct(void) {
    adv();
    Token *nm = cur();
    if (!at(T_IDENT)) perr(nm, "example: struct Point", "expected a name after `struct`, but found %s", describe(nm));
    Node *n = node(N_STRUCT, nm); n->name = nm->sval; adv();
    if (!at(T_NEWLINE)) perr(cur(), "the fields go on the next lines, indented", "I didn't expect %s here - a struct's fields go on their own lines", describe(cur()));
    adv();
    if (!at(T_INDENT)) {
        error_at(cur(), "list the fields indented below, like  x: f32", "expected an indented list of fields after `struct %s`", n->name);
        return n;
    }
    adv();
    parse_struct_fields(n);
    return n;
}

static Node *parse_decl(void) {
    Token *t = cur();
    switch (t->kind) {
    case T_IMPORT: {
        adv();
        Token *s = cur();
        if (!at(T_STRING)) perr(s, "example: $import \"io\"", "expected the module name in quotes after `$import`, but found %s", describe(s));
        Node *n = node(N_IMPORT, s); n->name = s->sval; adv();
        if (accept(T_PLUS)) {
            Token *backend = cur();
            if (!at(T_STRING)) perr(backend, "write $import \"graphics\" + \"raylib\"", "expected a quoted backend name after +");
            n->tname = backend->sval;
            adv();
        }
        expect_eol(NULL);
        return n;
    }
    case T_FN:     return parse_fn();
    case T_STRUCT: return parse_struct();
    case T_LET: case T_MUT: case T_CONST: return parse_let();
    case T_INDENT:
        perr(t, "top-level code starts at the left edge", "this line is indented, but nothing above opened a block");
    case T_IF: case T_LOOP: case T_FOR: case T_PRINT: case T_RETURN: case T_BREAK: case T_CONTINUE:
        perr(t, "put this inside a function - for example write  fn main()  and indent this line under it",
             "`%s` can't be used outside of a function", tk_name[t->kind]);
    default:
        perr(t, "at the top level you can write: fn, struct, let, mut, const or $import",
             "I didn't expect %s here", describe(t));
    }
    return NULL;
}

/* ---------- files and imports ---------- */

static int mod_on[6] = { 1, 0, 0, 0, 0, 0 };              /* which built-in modules were imported */
enum { M_CORE, M_IO, M_MATH, M_GAME, M_GFX, M_SYS };
static const char *mod_names[6] = { "core", "io", "math", "game", "graphics", "syscalls" };
static int graphics_backend = 0; /* 0 SDL2, 1 raylib */
static const char *lis_root = NULL;
static char lis_pkg[128] = "";
static int opt_tokens = 0;
static long total_tokens = 0;

static void parse_file(const char *path, const Token *from, Node *prog);

static void handle_import(Node *d, Node *prog, int file) {
    const char *name = d->name; size_t L = strlen(name);
    if (d->tname) {
        LisLibrary lib;
        char err[256];
        const char *root = getenv("SPC_LIB_PATH");
        if (!root || !*root) root = "libraries";
        if (lis_resolve(root, name, d->tname, &lib, err, sizeof err) != 0) {
            error_at(&d->tok, "install a LIS backend under libraries/<module>/<backend>/", "LIS: %s + %s: %s", name, d->tname, err);
            return;
        }
        if (!strcmp(name, "graphics")) {
            if (strcmp(d->tname, "raylib")) {
                error_at(&d->tok, "only raylib has a graphics runtime adapter so far", "LIS graphics backend '%s' has no runtime adapter", d->tname);
                return;
            }
            graphics_backend = 1;
            mod_on[M_GFX] = 1;
            return;
        }
        if (lis_pkg[0] && lib.pkg_config[0] && strcmp(lis_pkg, lib.pkg_config)) {
            error_at(&d->tok, "this LIS prototype supports one external pkg-config dependency per program", "conflicting LIS dependencies");
            return;
        }
        if (lib.pkg_config[0]) snprintf(lis_pkg, sizeof lis_pkg, "%s", lib.pkg_config);
        parse_file(lib.source, &d->tok, prog);
        return;
    }
    if (L > 3 && !strcmp(name + L - 3, ".sp")) {         /* another Sparks file, next to this one */
        const char *me = srcs[file].path;
        const char *slash = strrchr(me, PATH_SEP);
        Buf p = {0};
        if (slash) { char *dir = xstrndup(me, slash - me + 1); buf_add(&p, dir); }
        buf_add(&p, name);
        parse_file(BS(p), &d->tok, prog);
        return;
    }
    for (int m = 1; m < 6; m++) if (!strcmp(name, mod_names[m])) { mod_on[m] = 1; return; }
    error_at(&d->tok, "built-in modules are \"io\", \"math\", \"game\", \"graphics\" and \"syscalls\". To use your own file, write its name ending in .sp",
             "I don't know a module called \"%s\"", name);
}

static void parse_toplevel(Node *prog, int file) {
    jmp_buf jb, *prev = cur_jb;
    cur_jb = &jb;
    while (!at(T_EOF)) {
        volatile int before = ppos;
        if (setjmp(jb) == 0) {
            if (at(T_NEWLINE)) { adv(); continue; }
            Node *d = parse_decl();
            if (d) { if (d->kind == N_IMPORT) handle_import(d, prog, file); else push(prog, d); }
        } else {
            parser_sync();
            if (ppos == before) adv();
        }
    }
    cur_jb = prev;
}

static char *seen_files[64];
static int nseen = 0;

static void dump_tokens(Toks *t) {
    for (int i = 0; i < t->n; i++) {
        Token *k = &t->v[i];
        printf("%4d:%-3d %-9s", k->line, k->col, tk_name[k->kind]);
        if (k->kind == T_IDENT || k->kind == T_INT || k->kind == T_FLOAT) printf(" %s", k->sval);
        else if (k->kind == T_STRING) printf(" \"%s\"", k->sval);
        printf("\n");
    }
}

static void parse_file(const char *path, const Token *from, Node *prog) {
    for (int i = 0; i < nseen; i++) if (!strcmp(seen_files[i], path)) return;     /* already loaded */
    if (nseen >= 64 || nsrcs >= 64) die("too many files");
    seen_files[nseen++] = xstrdup(path);
    char *text = read_file(path);
    if (!text) {
        if (from) error_at(from, "check the spelling, and that the file is in the same folder", "I can't open the file `%s`", path);
        else { fprintf(stderr, "spc: can't open `%s`\n", path); exit(1); }
        return;
    }
    int f = nsrcs++;
    srcs[f].path = xstrdup(path); srcs[f].text = text;
    audit("[READ] %s (%zu bytes)", path, strlen(text));
    Toks *toks = xmalloc(sizeof *toks); memset(toks, 0, sizeof *toks);
    lex(f, toks);
    total_tokens += toks->n;
    if (audit_log) for (int i = 0; i < toks->n; i++) {
        Token *t = &toks->v[i];
        audit("[TOKEN] %s:%d:%d %-10s %s", path, t->line, t->col,
              tk_name[t->kind], t->sval ? t->sval : "");
    }
    if (opt_tokens && f == 0) dump_tokens(toks);
    Toks *saved = PT; int savedpos = ppos;
    PT = toks; ppos = 0;
    parse_toplevel(prog, f);
    audit("[PARSE] %s parsed; total top-level declarations: %d", path, prog->n);
    PT = saved; ppos = savedpos;
}

/* =============================================================================
 *  5. CHECKER + CODE GENERATOR
 *
 *  Now the tree is walked once. For every expression we do two jobs at once:
 *    - CHECK it: do the names exist? do the types fit together?
 *    - TRANSLATE it: write the matching piece of C code.
 *  gen_expr() returns the TYPE of the expression and appends its C code to a buffer.
 *
 *  Functions in Sparks have no written-out parameter types:  fn add(a, b)
 *  So we compile a fresh copy of a function for every combination of argument
 *  types it is called with ("monomorphization", the same trick C++ templates use).
 *  add(1, 2) becomes f_add__int_int, add(1.5, 2.5) becomes f_add__f32_f32.
 * ============================================================================= */

enum { TY_UNKNOWN = -1, TY_ERR = 0, TY_VOID, TY_INT, TY_F32, TY_F64, TY_BOOL, TY_STR, TY_STRUCT0 = 16 };
typedef int Ty;

typedef struct {
    char *name; char *cname; Token tok;
    int nf; char *fname[MAX_FIELDS]; Ty ftype[MAX_FIELDS];
} StructDef;
static StructDef structs[128];
static int nstructs = 0;

static int is_struct(Ty t) { return t >= TY_STRUCT0; }
static int is_num(Ty t) { return t == TY_INT || t == TY_F32 || t == TY_F64; }
static int is_float(Ty t) { return t == TY_F32 || t == TY_F64; }
static const char *ty_name(Ty t) {
    switch (t) {
        case TY_INT: return "int"; case TY_F32: return "f32"; case TY_F64: return "f64";
        case TY_BOOL: return "bool"; case TY_STR: return "str"; case TY_VOID: return "nothing";
        case TY_ERR: return "error"; default: break;
    }
    return is_struct(t) ? structs[t - TY_STRUCT0].name : "?";
}
static const char *ty_c(Ty t) {
    switch (t) {
        case TY_INT: return "int"; case TY_F32: return "float"; case TY_F64: return "double";
        case TY_BOOL: return "bool"; case TY_STR: return "const char *"; case TY_VOID: return "void";
        default: break;
    }
    return is_struct(t) ? structs[t - TY_STRUCT0].cname : "int";
}
/* can a value of type `from` be stored where `to` is expected?  (int -> f32 -> f64 is OK, never backwards) */
static int assignable(Ty from, Ty to) {
    if (from == to || from == TY_ERR || to == TY_ERR) return 1;
    if (from == TY_INT && is_float(to)) return 1;
    if (from == TY_F32 && to == TY_F64) return 1;
    return 0;
}
static Ty promote(Ty a, Ty b) {
    if (a == TY_F64 || b == TY_F64) return TY_F64;
    if (a == TY_F32 || b == TY_F32) return TY_F32;
    return TY_INT;
}
static int find_field(Ty st, const char *name) {
    StructDef *sd = &structs[st - TY_STRUCT0];
    for (int i = 0; i < sd->nf; i++) if (!strcmp(sd->fname[i], name)) return i;
    return -1;
}
/* Does a value of this type own memory that must be freed? (text, or a struct holding text) */
static int needs_own(Ty t) {
    if (t == TY_STR) return 1;
    if (is_struct(t)) {
        StructDef *sd = &structs[t - TY_STRUCT0];
        for (int i = 0; i < sd->nf; i++) if (needs_own(sd->ftype[i])) return 1;
    }
    return 0;
}
static const char *c_keywords[] = { "auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else",
    "enum", "extern", "float", "for", "goto", "if", "inline", "int", "long", "register", "restrict", "return", "short",
    "signed", "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned", "void", "volatile", "while",
    "bool", "true", "false", NULL };
static char *csafe(const char *name) {                /* field names that clash with C words get a trailing _ */
    for (int i = 0; c_keywords[i]; i++) if (!strcmp(name, c_keywords[i])) { Buf b = {0}; buf_printf(&b, "%s_", name); return b.s; }
    return xstrdup(name);
}

static Ty resolve_type(const char *name, const Token *tok, int allow_void) {
    if (!strcmp(name, "int") || !strcmp(name, "i32")) return TY_INT;
    if (!strcmp(name, "f32")) return TY_F32;
    if (!strcmp(name, "f64")) return TY_F64;
    if (!strcmp(name, "bool")) return TY_BOOL;
    if (!strcmp(name, "str")) return TY_STR;
    if (allow_void && !strcmp(name, "void")) return TY_VOID;
    for (int i = 0; i < nstructs; i++) if (!strcmp(structs[i].name, name)) return TY_STRUCT0 + i;
    const char *help = NULL; char hb[200];
    if (!strcmp(name, "float")) help = "decimal numbers are `f32` (or `f64` for extra precision)";
    else if (!strcmp(name, "double")) help = "use `f64`";
    else if (!strcmp(name, "string") || !strcmp(name, "String") || !strcmp(name, "char")) help = "text is called `str`";
    else if (!strcmp(name, "boolean") || !strcmp(name, "Bool")) help = "true/false values are called `bool`";
    else if (!strcmp(name, "long") || !strcmp(name, "i64") || !strcmp(name, "Int") || !strcmp(name, "integer")) help = "whole numbers are called `int`";
    else {
        const char *c[140]; int n = 0;
        c[n++] = "int"; c[n++] = "f32"; c[n++] = "f64"; c[n++] = "bool"; c[n++] = "str";
        for (int i = 0; i < nstructs; i++) c[n++] = structs[i].name;
        const char *s = closest(name, c, n);
        if (s) { snprintf(hb, sizeof hb, "did you mean `%s`?", s); help = hb; }
        else help = "the types are int, f32, f64, bool, str - or the name of a struct you defined";
    }
    error_at(tok, help, "I don't know a type called `%s`", name);
    return TY_ERR;
}

static void mismatch(const Token *t, Ty want, Ty got, const char *what) {
    const char *help = NULL;
    if (want == TY_INT && is_float(got)) help = "to drop the decimal part, write  int(value)";
    else if (want == TY_F32 && got == TY_F64) help = "f64 is more precise than f32; convert with  f32(value)";
    else if (want == TY_STR && (is_num(got) || got == TY_BOOL)) help = "turn it into text with  str(value)";
    else if ((is_num(want)) && got == TY_STR) help = "text isn't a number; read a number from the keyboard with input_int(), or convert with int(text)";
    else if (want == TY_BOOL) help = "make a comparison, like  value != 0";
    error_at(t, help, "%s: expected `%s` but found `%s`", what, ty_name(want), ty_name(got));
}

/* ---------- variables and scopes ---------- */

typedef struct { char *name; Ty type; int kind; char *cname; } Var;
enum { V_LET, V_MUT, V_CONST, V_PARAM, V_LOOP };

typedef struct Ctx {
    Var *vars; int nv, cap;           /* all variables visible right now */
    int marks[64]; int nmarks;        /* where each open scope started */
    Ty ret;                           /* what the current function returns (TY_UNKNOWN until we see) */
    Buf *out; int ind;                /* where we write C code, and how deep it is indented */
    int loops;                        /* how many loops we are inside (for `break`) */
    int loop_nv[32];                  /* how many variables existed when each loop started (the Sealer frees back to there) */
    int is_main;
} Ctx;
static Ctx G;                         /* the "global" context: top-level let/mut/const */
static Ctx *C;                        /* the context we are generating code in right now */
static Buf out_structs, out_protos, out_globals, out_funcs, g_init, g_free;
static int uniq = 0;
static int temps = 0;            /* counts temporary texts created: lets the Sealer know a line needs cleanup */
static int sealed_frees = 0;      /* how many frees the Sealer wrote into the program */

static void L(const char *fmt, ...) {                 /* write one line of C */
    Buf *o = C->out;
    for (int i = 0; i < C->ind; i++) buf_add(o, "    ");
    int start = o->len;
    va_list ap; va_start(ap, fmt); buf_vprintf(o, fmt, ap); va_end(ap);
    buf_add(o, "\n");
    if (audit_log) {
        char *line = xstrndup(o->s + start, (size_t)(o->len - start - 1));
        audit("[CODEGEN] %s", line);
        free(line);
    }
}
static void push_scope(void) { if (C->nmarks >= 63) die("blocks are nested too deeply"); C->marks[C->nmarks++] = C->nv; }
static void pop_scope(void) { C->nv = C->marks[--C->nmarks]; }

static Var *find_var(const char *name) {
    for (int i = C->nv - 1; i >= 0; i--) if (!strcmp(C->vars[i].name, name)) return &C->vars[i];
    if (C != &G) for (int i = G.nv - 1; i >= 0; i--) if (!strcmp(G.vars[i].name, name)) return &G.vars[i];
    return NULL;
}
static Var *declare(const Token *t, const char *name, Ty ty, int kind) {
    int lo = C->nmarks ? C->marks[C->nmarks - 1] : 0;
    for (int i = C->nv - 1; i >= lo; i--)
        if (!strcmp(C->vars[i].name, name))
            error_at(t, "pick a different name; to change an existing variable just write  name = value",
                     "`%s` is already defined in this block", name);
    Buf cn = {0};
    if (find_var(name)) buf_printf(&cn, "v_%s__%d", name, ++uniq);   /* shadowing: make the C name unique */
    else buf_printf(&cn, "v_%s", name);
    if (C->nv == C->cap) { C->cap = C->cap ? C->cap * 2 : 16; C->vars = xrealloc(C->vars, C->cap * sizeof(Var)); }
    Var *v = &C->vars[C->nv++];
    v->name = xstrdup(name); v->type = ty; v->kind = kind; v->cname = cn.s;
    return v;
}

/* ---------- functions, instances, built-ins ---------- */

static Node *fns[256];
static int nfns = 0;
static Node *find_fn(const char *name) {
    for (int i = 0; i < nfns; i++) if (!strcmp(fns[i]->name, name)) return fns[i];
    return NULL;
}
typedef struct { Node *fn; Ty args[MAX_PARAMS]; Ty ret; int in_progress; char *cname; } Inst;
static Inst *insts[512];
static int ninsts = 0;
static void gen_instance(Inst *in);

static Inst *get_inst(Node *fn, Ty *key) {
    for (int i = 0; i < ninsts; i++) {
        Inst *in = insts[i];
        if (in->fn != fn) continue;
        int same = 1;
        for (int k = 0; k < fn->n; k++) if (in->args[k] != key[k]) same = 0;
        if (same) return in;
    }
    if (ninsts >= 512) die("too many function copies");
    Inst *in = xmalloc(sizeof *in); memset(in, 0, sizeof *in);
    in->fn = fn;
    Buf nb = {0}; buf_printf(&nb, "f_%s", fn->name);
    for (int k = 0; k < fn->n; k++) { in->args[k] = key[k]; buf_printf(&nb, "__%s", ty_name(key[k])); }
    in->cname = nb.s; in->ret = TY_UNKNOWN;
    insts[ninsts++] = in;
    gen_instance(in);
    return in;
}

enum { R_FLOATLIKE = -10, R_SAMEAS = -11 };
typedef struct { const char *name; int module; int minargs, maxargs; const char *sig; int ret; const char *cfn; } Builtin;
static const Builtin builtins[] = {
    { "len",       M_CORE, 1, 1, "s",  TY_INT,      "sp_len" },
    { "sx_init", M_SYS, 0, 0, "", TY_INT, "sx_init" },
    { "sx_next", M_SYS, 0, 0, "", TY_INT, "sx_next" },
    { "sx_theme_icon", M_SYS, 4, 4, "iiii", TY_INT, "sx_theme_icon" },
    { "sx_file_kind", M_SYS, 1, 1, "i", TY_INT, "sx_file_kind" },
    { "sx_file_action", M_SYS, 2, 2, "is", TY_VOID, "sx_file_action" },
    { "sx_icon_set", M_SYS, 1, 1, "i", TY_VOID, "sx_icon_set" },
    { "sx_val", M_SYS, 1, 1, "i", TY_INT, "sx_val" },
    { "sx_map", M_SYS, 1, 1, "i", TY_VOID, "sx_map" },
    { "sx_raise", M_SYS, 1, 1, "i", TY_VOID, "sx_raise" },
    { "sx_move", M_SYS, 3, 3, "iii", TY_VOID, "sx_move" },
    { "sx_move_relative", M_SYS, 3, 3, "iii", TY_VOID, "sx_move_relative" },
    { "sx_configure", M_SYS, 1, 1, "i", TY_VOID, "sx_configure" },
    { "sx_draw", M_SYS, 0, 0, "", TY_VOID, "sx_draw" },
    { "sx_popup", M_SYS, 1, 1, "i", TY_VOID, "sx_popup" },
    { "sx_menu_show", M_SYS, 1, 1, "i", TY_VOID, "sx_menu_show" },
    { "sx_spawn", M_SYS, 1, 1, "s", TY_VOID, "sx_spawn" },
    { "sx_file_at", M_SYS, 2, 2, "ii", TY_INT, "sx_file_at" },
    { "sx_files_open", M_SYS, 1, 1, "i", TY_VOID, "sx_files_open" },
    { "sx_close", M_SYS, 1, 1, "i", TY_VOID, "sx_close" },
    { "sx_stop", M_SYS, 0, 0, "", TY_VOID, "sx_stop" },
    { "sx_wallpaper", M_SYS, 1, 1, "s", TY_INT, "sx_wallpaper" },
    { "sx_background", M_SYS, 0, 0, "", TY_VOID, "sx_background" },
    { "sx_rect", M_SYS, 6, 6, "iiiiii", TY_VOID, "sx_rect" },
    { "sx_outline", M_SYS, 6, 6, "iiiiii", TY_VOID, "sx_outline" },
    { "sx_text", M_SYS, 5, 5, "iiisi", TY_VOID, "sx_text" },
    { "sx_file_count_get", M_SYS, 0, 0, "", TY_INT, "sx_file_count_get" },
    { "sx_file_name", M_SYS, 1, 1, "i", TY_STR, "sx_file_name" },
    { "sx_decorate", M_SYS, 1, 1, "i", TY_VOID, "sx_decorate" },
    { "sx_remove_decor", M_SYS, 1, 1, "i", TY_VOID, "sx_remove_decor" },
    { "sx_title_count", M_SYS, 0, 0, "", TY_INT, "sx_title_count" },
    { "sx_title_bar", M_SYS, 1, 1, "i", TY_INT, "sx_title_bar" },
    { "sx_title_width", M_SYS, 1, 1, "i", TY_INT, "sx_title_width" },
    { "sx_title_maximized", M_SYS, 1, 1, "i", TY_INT, "sx_title_maximized" },
    { "sx_title_name", M_SYS, 1, 1, "i", TY_STR, "sx_title_name" },
    { "sx_title_client", M_SYS, 1, 1, "i", TY_INT, "sx_title_client" },
    { "sx_title_width_for_bar", M_SYS, 1, 1, "i", TY_INT, "sx_title_width_for_bar" },
    { "sx_maximize", M_SYS, 1, 1, "i", TY_VOID, "sx_maximize" },

    { "input",     M_IO,   0, 1, "s",  TY_STR,      "sp_input" },
    { "input_int", M_IO,   0, 1, "s",  TY_INT,      "sp_input_int" },
    { "sqrt",      M_MATH, 1, 1, "n",  R_FLOATLIKE, "sqrt" },
    { "sin",       M_MATH, 1, 1, "n",  R_FLOATLIKE, "sin" },
    { "cos",       M_MATH, 1, 1, "n",  R_FLOATLIKE, "cos" },
    { "tan",       M_MATH, 1, 1, "n",  R_FLOATLIKE, "tan" },
    { "floor",     M_MATH, 1, 1, "n",  R_FLOATLIKE, "floor" },
    { "ceil",      M_MATH, 1, 1, "n",  R_FLOATLIKE, "ceil" },
    { "round",     M_MATH, 1, 1, "n",  R_FLOATLIKE, "round" },
    { "pow",       M_MATH, 2, 2, "nn", R_FLOATLIKE, "pow" },
    { "atan2",     M_MATH, 2, 2, "nn", R_FLOATLIKE, "atan2" },
    { "exp",       M_MATH, 1, 1, "n",  R_FLOATLIKE, "exp" },
    { "log",       M_MATH, 1, 1, "n",  R_FLOATLIKE, "log" },
    { "dist",      M_MATH, 4, 4, "nnnn", R_FLOATLIKE, "sp_dist" },
    { "abs",       M_MATH, 1, 1, "n",  R_SAMEAS,    "abs" },
    { "min",       M_MATH, 2, 2, "nn", R_SAMEAS,    "min" },
    { "max",       M_MATH, 2, 2, "nn", R_SAMEAS,    "max" },
    { "rand",      M_GAME, 2, 2, "ii", TY_INT,      "sp_rand" },
    { "sleep",     M_GAME, 1, 1, "i",  TY_VOID,     "sp_sleep" },
    { "clear",     M_GAME, 0, 0, "",   TY_VOID,     "sp_clear" },
    { "time_ms",   M_GAME, 0, 0, "",   TY_INT,      "sp_time_ms" },
    { "is_open",   M_GFX,  0, 0, "",   TY_BOOL,     "sp_g_is_open" },
    { "key_down",  M_GFX,  1, 1, "s",  TY_BOOL,     "sp_g_key_down" },
    { "mouse_x",   M_GFX,  0, 0, "",   TY_INT,      "sp_g_mouse_x" },
    { "mouse_y",   M_GFX,  0, 0, "",   TY_INT,      "sp_g_mouse_y" },
    { "mouse_down", M_GFX, 0, 0, "",   TY_BOOL,     "sp_g_mouse_down" },
    { "screen_w",  M_GFX,  0, 0, "",   TY_INT,      "sp_g_screen_w" },
    { "screen_h",  M_GFX,  0, 0, "",   TY_INT,      "sp_g_screen_h" },
    { "getpid",    M_SYS,  0, 0, "",   TY_INT,      "sp_sys_getpid" },
    { "getuid",    M_SYS,  0, 0, "",   TY_INT,      "sp_sys_getuid" },
    { "time",      M_SYS,  0, 0, "",   TY_INT,      "sp_sys_time" },
    { "getenv",    M_SYS,  1, 1, "s",  TY_STR,      "sp_sys_getenv" },
    { "getcwd",    M_SYS,  0, 0, "",   TY_STR,      "sp_sys_getcwd" },
    { "chdir",     M_SYS,  1, 1, "s",  TY_INT,      "sp_sys_chdir" },
    { "open",      M_SYS,  2, 2, "ss", TY_INT,      "sp_sys_open" },
    { "close",     M_SYS,  1, 1, "i",  TY_INT,      "sp_sys_close" },
    { "read",      M_SYS,  2, 2, "ii", TY_STR,      "sp_sys_read" },
    { "write",     M_SYS,  2, 2, "is", TY_INT,      "sp_sys_write" },
    { "unlink",    M_SYS,  1, 1, "s",  TY_INT,      "sp_sys_unlink" },
    { "mkdir",     M_SYS,  1, 1, "s",  TY_INT,      "sp_sys_mkdir" },
    { "system",    M_SYS,  1, 1, "s",  TY_INT,      "sp_sys_system" },
    { "exit",      M_SYS,  1, 1, "i",  TY_VOID,     "sp_sys_exit" },
    { "net_connect", M_SYS, 2, 2, "si", TY_INT, "sp_net_connect" },
    { "net_listen", M_SYS, 1, 1, "i", TY_INT, "sp_net_listen" },
    { "net_accept", M_SYS, 1, 1, "i", TY_INT, "sp_net_accept" },
    { "net_send", M_SYS, 2, 2, "is", TY_INT, "sp_net_send" },
    { "arg_count", M_SYS, 0, 0, "", TY_INT, "sp_arg_count" },
    { "arg_get", M_SYS, 1, 1, "i", TY_STR, "sp_arg_get" },
    { "http_request", M_SYS, 4, 4, "siss", TY_STR, "sp_http_request" },
    { "install_copy", M_SYS, 2, 2, "ss", TY_INT, "sp_install_copy" },
    { "net_recv", M_SYS, 2, 2, "ii", TY_STR, "sp_net_recv" },
    { "net_close", M_SYS, 1, 1, "i", TY_INT, "sp_net_close" },
    { "net_send_hex", M_SYS, 2, 2, "is", TY_INT, "sp_net_send_hex" },
    { "net_recv_hex", M_SYS, 2, 2, "ii", TY_STR, "sp_net_recv_hex" },
    { "da_check", M_SYS, 1, 1, "s", TY_BOOL, "sp_da_check" },
    { "da_delete", M_SYS, 1, 1, "s", TY_BOOL, "sp_da_delete" },
    { "da_incoming", M_SYS, 1, 1, "s", TY_STR, "sp_da_incoming" },
    { "sys_errno", M_SYS, 0, 0, "", TY_INT, "sp_sys_errno" },
    { "sys_error", M_SYS, 0, 0, "", TY_STR, "sp_sys_error" },
    { "log_event", M_SYS, 1, 1, "s", TY_VOID, "sp_log_event" },

};
#define NBUILTINS ((int)(sizeof builtins / sizeof builtins[0]))
static const Builtin *find_builtin(const char *name) {
    for (int i = 0; i < NBUILTINS; i++) if (!strcmp(builtins[i].name, name)) return &builtins[i];
    return NULL;
}

/* ---------- helpers for expressions ---------- */

static void c_escape(Buf *b, const char *s) {          /* turn text into a C string literal */
    buf_add(b, "\"");
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"') buf_add(b, "\\\"");
        else if (c == '\\') buf_add(b, "\\\\");
        else if (c == '\n') buf_add(b, "\\n");
        else if (c == '\t') buf_add(b, "\\t");
        else if (c < 32 || c == 127) buf_printf(b, "\\%03o", c);
        else { char t[2] = { (char)c, 0 }; buf_add(b, t); }
    }
    buf_add(b, "\"");
}
static void to_text(Buf *dst, Ty t, const char *expr) {        /* wrap a value so it becomes a C string */
    switch (t) {
        case TY_INT:  temps++; buf_printf(dst, "sp_str_int(%s)", expr); break;
        case TY_F32:  temps++; buf_printf(dst, "sp_str_f32(%s)", expr); break;
        case TY_F64:  temps++; buf_printf(dst, "sp_str_f64(%s)", expr); break;
        case TY_BOOL: buf_printf(dst, "sp_str_bool(%s)", expr); break;
        default:      buf_add(dst, expr); break;
    }
}

static void undefined_name(Node *e) {
    const char *c[300]; int n = 0;
    for (int i = 0; i < C->nv && n < 280; i++) c[n++] = C->vars[i].name;
    if (C != &G) for (int i = 0; i < G.nv && n < 280; i++) c[n++] = G.vars[i].name;
    const char *s = closest(e->name, c, n);
    char hb[200];
    if (s) snprintf(hb, sizeof hb, "did you mean `%s`?", s);
    else snprintf(hb, sizeof hb, "create it first with  let %s = ...  (use `mut` if it will change later)", e->name);
    error_at(&e->tok, hb, "I don't know what `%s` is", e->name);
}

static Ty gen_expr(Node *e, Buf *out);


/* C does not promise which side of  f() + g()  runs first. Sparks does: left to right.
 * When two or more parts of an expression contain calls, we evaluate them in order into temporaries. */
static int has_call(Node *e) {
    if (!e) return 0;
    if (e->kind == N_CALL) return 1;
    if (has_call(e->a) || has_call(e->b) || has_call(e->c)) return 1;
    for (int i = 0; i < e->n; i++) if (has_call(e->list[i])) return 1;
    return 0;
}
static void order_args(Node **nodes, int n, Buf *bufs, Ty *types, Buf *decls) {
    int calls = 0;
    for (int i = 0; i < n; i++) if (has_call(nodes[i]) && types[i] != TY_VOID) calls++;
    if (calls < 2) return;
    int id = ++uniq;
    for (int i = 0; i < n; i++) {
        if (!has_call(nodes[i]) || types[i] == TY_VOID) continue;
        buf_printf(decls, "%s sp_o%d_%d = %s; ", ty_c(types[i]), id, i, BS(bufs[i]));
        Buf nb = {0}; buf_printf(&nb, "sp_o%d_%d", id, i);
        bufs[i] = nb;
    }
}
static void emit_wrapped(Buf *out, Buf *decls, Buf *res) {
    if (decls->len) buf_printf(out, "({ %s%s; })", BS(*decls), BS(*res));
    else buf_add(out, BS(*res));
}

static Ty gen_binary_core(Node *e, Buf *out, Buf lb, Buf rb, Ty lt, Ty rt) {
    int op = e->op;
    if (lt == TY_ERR || rt == TY_ERR) return TY_ERR;
    if (lt == TY_VOID || rt == TY_VOID) {
        error_at(&e->tok, "a function that doesn't `return` a value can't be used in a calculation", "one side of `%s` has no value", tk_name[op]);
        return TY_ERR;
    }
    const char *cop = tk_name[op];
    switch (op) {
    case T_PLUS: case T_MINUS: case T_STAR: case T_SLASH: case T_PERCENT: {
        if (op == T_PLUS && (lt == TY_STR || rt == TY_STR)) {             /* joining text */
            if (is_struct(lt) || is_struct(rt)) {
                error_at(&e->tok, "join the fields instead, like  p.x", "can't join a whole struct into text");
                return TY_ERR;
            }
            Buf a = {0}, b = {0};
            to_text(&a, lt, BS(lb)); to_text(&b, rt, BS(rb));
            temps++;
            buf_printf(out, "sp_cat(%s, %s)", BS(a), BS(b));
            return TY_STR;
        }
        if (!is_num(lt) || !is_num(rt)) {
            const char *h = (lt == TY_STR || rt == TY_STR) ? "text can only be joined with +  (use str(x) to turn a number into text)" : NULL;
            error_at(&e->tok, h, "can't use `%s` between `%s` and `%s`", cop, ty_name(lt), ty_name(rt));
            return TY_ERR;
        }
        if (op == T_PERCENT && (lt != TY_INT || rt != TY_INT)) {
            error_at(&e->tok, "`%` (the remainder) only works on whole numbers", "can't use `%%` on decimal numbers");
            return TY_ERR;
        }
        Ty res = promote(lt, rt);
        if ((op == T_SLASH || op == T_PERCENT) && res == TY_INT)
            buf_printf(out, "%s(%s, %s, %d)", op == T_SLASH ? "sp_idiv" : "sp_imod", BS(lb), BS(rb), e->tok.line);
        else
            buf_printf(out, "(%s %s %s)", BS(lb), cop, BS(rb));
        return res;
    }
    case T_LT: case T_LE: case T_GT: case T_GE:
        if (!is_num(lt) || !is_num(rt)) {
            error_at(&e->tok, "only numbers can be compared with < > <= >=", "can't use `%s` between `%s` and `%s`", cop, ty_name(lt), ty_name(rt));
            return TY_ERR;
        }
        buf_printf(out, "(%s %s %s)", BS(lb), cop, BS(rb));
        return TY_BOOL;
    case T_EQ: case T_NE:
        if ((is_num(lt) && is_num(rt)) || (lt == TY_BOOL && rt == TY_BOOL)) buf_printf(out, "(%s %s %s)", BS(lb), cop, BS(rb));
        else if (lt == TY_STR && rt == TY_STR) buf_printf(out, "(strcmp(%s, %s) %s 0)", BS(lb), BS(rb), cop);
        else {
            error_at(&e->tok, is_struct(lt) ? "compare the fields instead, like  a.x == b.x" : "both sides must be the same kind of value",
                     "can't compare `%s` with `%s`", ty_name(lt), ty_name(rt));
            return TY_ERR;
        }
        return TY_BOOL;
    case T_AND: case T_OR:
        if (lt != TY_BOOL || rt != TY_BOOL) {
            error_at(&e->tok, "`and` / `or` join two true/false questions, like  x > 1 and x < 9",
                     "`%s` needs true/false on both sides, but got `%s` and `%s`", tk_name[op], ty_name(lt), ty_name(rt));
            return TY_ERR;
        }
        buf_printf(out, "(%s %s %s)", BS(lb), op == T_AND ? "&&" : "||", BS(rb));
        return TY_BOOL;
    }
    return TY_ERR;
}

static Ty gen_binary(Node *e, Buf *out) {
    Buf lb = {0}, rb = {0};
    Ty lt = gen_expr(e->a, &lb), rt = gen_expr(e->b, &rb);
    if (lt == TY_ERR || rt == TY_ERR) return TY_ERR;
    Buf decls = {0}, res = {0};
    if (e->op != T_AND && e->op != T_OR && lt != TY_VOID && rt != TY_VOID) {   /* and/or already run left to right */
        Node *ns[2] = { e->a, e->b }; Buf bs[2] = { lb, rb }; Ty ts[2] = { lt, rt };
        order_args(ns, 2, bs, ts, &decls);
        lb = bs[0]; rb = bs[1];
    }
    Ty r = gen_binary_core(e, &res, lb, rb, lt, rt);
    if (r == TY_ERR) return r;
    emit_wrapped(out, &decls, &res);
    return r;
}

static Ty gen_cast(Node *e, Buf *out) {
    const char *name = e->name;
    if (e->n != 1) { error_at(&e->tok, NULL, "`%s(...)` takes exactly 1 value, but you gave %d", name, e->n); return TY_ERR; }
    Buf ab = {0};
    Ty t = gen_expr(e->list[0], &ab);
    if (t == TY_ERR) return TY_ERR;
    if (t == TY_VOID || is_struct(t)) { error_at(&e->list[0]->tok, NULL, "can't convert `%s` with `%s(...)`", ty_name(t), name); return TY_ERR; }
    if (!strcmp(name, "str")) { to_text(out, t, BS(ab)); return TY_STR; }
    Ty to = !strcmp(name, "int") ? TY_INT : !strcmp(name, "f32") ? TY_F32 : TY_F64;
    if (t == TY_STR) buf_printf(out, to == TY_INT ? "atoi(%s)" : "((%s)atof(%s))", to == TY_INT ? BS(ab) : ty_c(to), BS(ab));
    else buf_printf(out, "((%s)(%s))", ty_c(to), BS(ab));
    return to;
}

static Ty gen_builtin(Node *e, const Builtin *b, Buf *out) {
    if (e->n < b->minargs || e->n > b->maxargs) {
        if (b->minargs == b->maxargs) error_at(&e->tok, NULL, "`%s` needs %d value%s but you gave %d", b->name, b->minargs, b->minargs == 1 ? "" : "s", e->n);
        else error_at(&e->tok, NULL, "`%s` takes %d or %d values but you gave %d", b->name, b->minargs, b->maxargs, e->n);
        return TY_ERR;
    }
    Buf ab[16]; Ty at[16]; int bad = 0;
    memset(ab, 0, sizeof ab);
    for (int i = 0; i < e->n; i++) {
        Node *arg = e->list[i];
        at[i] = gen_expr(arg, &ab[i]);
        char what[100]; snprintf(what, sizeof what, "`%s` got the wrong kind of value", b->name);
        if (at[i] == TY_ERR) bad = 1;
        else if (b->sig[i] == 'i' && at[i] != TY_INT) { mismatch(&arg->tok, TY_INT, at[i], what); bad = 1; }
        else if (b->sig[i] == 's' && at[i] != TY_STR) { mismatch(&arg->tok, TY_STR, at[i], what); bad = 1; }
        else if (b->sig[i] == 'n' && !is_num(at[i])) {
            error_at(&arg->tok, NULL, "`%s` needs a number here, but found `%s`", b->name, ty_name(at[i])); bad = 1;
        }
    }
    if (bad) return TY_ERR;
    Ty rt = b->ret;
    if (rt == R_FLOATLIKE) { rt = TY_F32; for (int i = 0; i < e->n; i++) if (at[i] == TY_F64) rt = TY_F64; }
    else if (rt == R_SAMEAS) rt = e->n > 1 ? promote(at[0], at[1]) : at[0];
    if (rt == TY_STR) temps++;
    const char *cf = b->cfn;
    if (!strcmp(b->name, "abs")) cf = rt == TY_INT ? "sp_abs_i" : "fabs";
    else if (!strcmp(b->name, "min")) cf = rt == TY_INT ? "sp_min_i" : "sp_min_f";
    else if (!strcmp(b->name, "max")) cf = rt == TY_INT ? "sp_max_i" : "sp_max_f";
    Buf decls = {0}, res = {0};
    order_args(e->list, e->n, ab, at, &decls);
    buf_printf(&res, "%s(", cf);
    if (e->n == 0 && b->maxargs > 0) buf_add(&res, "\"\"");
    for (int i = 0; i < e->n; i++) { if (i) buf_add(&res, ", "); buf_add(&res, BS(ab[i])); }
    buf_add(&res, ")");
    emit_wrapped(out, &decls, &res);
    return rt;
}

static Ty gen_user_call(Node *e, Node *fn, Buf *out) {
    if (e->n != fn->n) {
        Buf sig = {0};
        for (int i = 0; i < fn->n; i++) buf_printf(&sig, "%s%s", i ? ", " : "", fn->list[i]->name);
        char hb[300]; snprintf(hb, sizeof hb, "it is written  %s(%s)", fn->name, BS(sig));
        error_at(&e->tok, hb, "`%s` needs %d value%s but you gave %d", fn->name, fn->n, fn->n == 1 ? "" : "s", e->n);
        return TY_ERR;
    }
    Buf ab[MAX_PARAMS]; Ty at[MAX_PARAMS], key[MAX_PARAMS]; int bad = 0;
    memset(ab, 0, sizeof ab);
    for (int i = 0; i < e->n; i++) {
        at[i] = gen_expr(e->list[i], &ab[i]);
        if (at[i] == TY_ERR) bad = 1;
        else if (at[i] == TY_VOID) { error_at(&e->list[i]->tok, "that function doesn't `return` a value", "this has no value to hand over"); bad = 1; }
    }
    if (bad) return TY_ERR;
    for (int i = 0; i < fn->n; i++) {
        Node *p = fn->list[i];
        if (p->tname) {
            Ty pt = resolve_type(p->tname, &p->ttok, 0);
            if (pt == TY_ERR) return TY_ERR;
            char what[160]; snprintf(what, sizeof what, "parameter `%s` of `%s` wants a different kind of value", p->name, fn->name);
            if (!assignable(at[i], pt)) { mismatch(&e->list[i]->tok, pt, at[i], what); return TY_ERR; }
            key[i] = pt;
        } else key[i] = at[i];
    }
    Inst *in = get_inst(fn, key);
    if (in->in_progress && in->ret == TY_UNKNOWN) {
        char hb[200]; snprintf(hb, sizeof hb, "say what it gives back, like  fn %s(...) -> int", fn->name);
        error_at(&e->tok, hb, "`%s` calls itself, so I need to be told what it gives back", fn->name);
        return TY_ERR;
    }
    if (needs_own(in->ret)) temps++;
    Buf decls = {0}, res = {0};
    order_args(e->list, e->n, ab, at, &decls);
    buf_printf(&res, "%s(", in->cname);
    for (int i = 0; i < e->n; i++) { if (i) buf_add(&res, ", "); buf_add(&res, BS(ab[i])); }
    buf_add(&res, ")");
    emit_wrapped(out, &decls, &res);
    return in->ret == TY_UNKNOWN ? TY_ERR : in->ret;
}

static Ty gen_call(Node *e, Buf *out) {
    const char *name = e->name;
    Node *fn = find_fn(name);
    if (fn) return gen_user_call(e, fn, out);
    if (!strcmp(name, "int") || !strcmp(name, "f32") || !strcmp(name, "f64") || !strcmp(name, "str")) return gen_cast(e, out);
    const Builtin *b = find_builtin(name);
    if (b) {
        if (!mod_on[b->module]) {
            char hb[120]; snprintf(hb, sizeof hb, "add  $import \"%s\"  at the top of your file", mod_names[b->module]);
            error_at(&e->tok, hb, "`%s` lives in the \"%s\" module, which isn't imported yet", name, mod_names[b->module]);
            return TY_ERR;
        }
        return gen_builtin(e, b, out);
    }
    if (!strcmp(name, "print")) { error_at(&e->tok, "no parentheses needed:  print \"hello\"", "`print` is a statement, not a function"); return TY_ERR; }
    if (find_var(name)) { error_at(&e->tok, NULL, "`%s` is a variable, not a function - you can't call it with ( )", name); return TY_ERR; }
    const char *c[400]; int n = 0;
    for (int i = 0; i < nfns && n < 250; i++) c[n++] = fns[i]->name;
    for (int i = 0; i < NBUILTINS; i++) if (mod_on[builtins[i].module]) c[n++] = builtins[i].name;
    c[n++] = "int"; c[n++] = "f32"; c[n++] = "f64"; c[n++] = "str";
    const char *s = closest(name, c, n);
    if (closest(name, (const char *[]){ "print" }, 1)) { error_at(&e->tok, "no parentheses needed:  print \"hello\"", "`%s` isn't a Sparks word - did you mean `print`?", name); return TY_ERR; }
    char hb[200]; const char *help = NULL;
    if (s) { snprintf(hb, sizeof hb, "did you mean `%s`?", s); help = hb; }
    else help = "define it with  fn name(...)  or check the spelling";
    error_at(&e->tok, help, "I don't know a function called `%s`", name);
    return TY_ERR;
}

static Ty gen_expr(Node *e, Buf *out) {
    switch (e->kind) {
    case N_INT:   buf_printf(out, "%lld", e->ival); return TY_INT;
    case N_FLOAT: buf_add(out, e->name); return TY_F32;           /* written as a C double; it fits f32 or f64 */
    case N_BOOL:  buf_add(out, e->ival ? "true" : "false"); return TY_BOOL;
    case N_STR:   c_escape(out, e->name); return TY_STR;
    case N_IDENT: {
        Var *v = find_var(e->name);
        if (v) { buf_add(out, v->cname); return v->type; }
        if (!strcmp(e->name, "PI")) {
            if (mod_on[M_MATH]) { buf_add(out, "3.14159265358979323846"); return TY_F32; }
            error_at(&e->tok, "add  $import \"math\"  at the top of your file", "`PI` lives in the \"math\" module, which isn't imported yet");
            return TY_ERR;
        }
        if (find_fn(e->name)) { error_at(&e->tok, "to run it, add parentheses:  name(...)", "`%s` is a function, not a value", e->name); return TY_ERR; }
        undefined_name(e);
        return TY_ERR;
    }
    case N_UNARY: {
        Buf ab = {0};
        Ty t = gen_expr(e->a, &ab);
        if (t == TY_ERR) return TY_ERR;
        if (e->op == T_MINUS) {
            if (!is_num(t)) { error_at(&e->tok, NULL, "can't put `-` in front of a `%s`", ty_name(t)); return TY_ERR; }
            buf_printf(out, "(-%s)", BS(ab));
            return t;
        }
        if (t != TY_BOOL) { error_at(&e->tok, "`not` flips true to false, like  not done", "`not` needs a true/false value, but found `%s`", ty_name(t)); return TY_ERR; }
        buf_printf(out, "(!%s)", BS(ab));
        return TY_BOOL;
    }
    case N_BINARY: return gen_binary(e, out);
    case N_CALL:   return gen_call(e, out);
    case N_FIELD: {
        Buf ab = {0};
        Ty t = gen_expr(e->a, &ab);
        if (t == TY_ERR) return TY_ERR;
        if (!is_struct(t)) { error_at(&e->tok, "only structs have fields", "this is a `%s`, it has no `.%s`", ty_name(t), e->name); return TY_ERR; }
        int fi = find_field(t, e->name);
        if (fi < 0) {
            StructDef *sd = &structs[t - TY_STRUCT0];
            const char *s = closest(e->name, (const char **)sd->fname, sd->nf);
            char hb[200]; snprintf(hb, sizeof hb, s ? "did you mean `%s`?" : "this struct has no field with that name", s ? s : "");
            error_at(&e->tok, hb, "`%s` has no field called `%s`", sd->name, e->name);
            return TY_ERR;
        }
        buf_printf(out, "%s.%s", BS(ab), csafe(structs[t - TY_STRUCT0].fname[fi]));
        return structs[t - TY_STRUCT0].ftype[fi];
    }
    case N_STRUCTLIT: {
        int si = -1;
        for (int i = 0; i < nstructs; i++) if (!strcmp(structs[i].name, e->name)) si = i;
        if (si < 0) {
            const char *c[130]; int n = 0;
            for (int i = 0; i < nstructs; i++) c[n++] = structs[i].name;
            const char *s = closest(e->name, c, n); char hb[200];
            snprintf(hb, sizeof hb, s ? "did you mean `%s`?" : "define it first with  struct %s", s ? s : e->name);
            error_at(&e->tok, hb, "I don't know a struct called `%s`", e->name);
            return TY_ERR;
        }
        StructDef *sd = &structs[si];
        int given[MAX_FIELDS]; memset(given, 0, sizeof given);
        Buf fb = {0}; int bad = 0;
        Buf vbs[MAX_FIELDS]; Ty vts[MAX_FIELDS]; Node *vnodes[MAX_FIELDS]; int vidx[MAX_FIELDS], nvals = 0;
        memset(vbs, 0, sizeof vbs);
        for (int i = 0; i < e->n; i++) {
            Node *fi = e->list[i];
            int idx = find_field(TY_STRUCT0 + si, fi->name);
            if (idx < 0) {
                const char *s = closest(fi->name, (const char **)sd->fname, sd->nf); char hb[200];
                snprintf(hb, sizeof hb, s ? "did you mean `%s`?" : "check the struct's definition for its field names", s ? s : "");
                error_at(&fi->tok, hb, "`%s` has no field called `%s`", sd->name, fi->name);
                bad = 1; continue;
            }
            if (given[idx]) { error_at(&fi->tok, NULL, "the field `%s` is given twice", fi->name); bad = 1; continue; }
            given[idx] = 1;
            Buf vb = {0};
            Ty vt = gen_expr(fi->a, &vb);
            if (vt == TY_ERR) { bad = 1; continue; }
            if (vt == TY_VOID) { error_at(&fi->a->tok, NULL, "this has no value to store in `%s`", fi->name); bad = 1; continue; }
            if (!assignable(vt, sd->ftype[idx])) {
                char what[120]; snprintf(what, sizeof what, "the field `%s` wants a different kind of value", fi->name);
                mismatch(&fi->a->tok, sd->ftype[idx], vt, what); bad = 1; continue;
            }
            vbs[nvals] = vb; vts[nvals] = vt; vnodes[nvals] = fi->a; vidx[nvals] = idx; nvals++;
        }
        for (int i = 0; i < sd->nf; i++) if (!given[i]) {
            char hb[120]; snprintf(hb, sizeof hb, "add  %s: <value>", sd->fname[i]);
            error_at(&e->tok, hb, "`%s { ... }` is missing the field `%s`", sd->name, sd->fname[i]);
            bad = 1;
        }
        if (bad) return TY_ERR;
        Buf decls = {0}, res = {0};
        order_args(vnodes, nvals, vbs, vts, &decls);
        for (int i = 0; i < nvals; i++) {
            if (fb.len) buf_add(&fb, ", ");
            buf_printf(&fb, ".%s = %s", csafe(sd->fname[vidx[i]]), BS(vbs[i]));
        }
        buf_printf(&res, "(%s){ %s }", sd->cname, BS(fb));
        emit_wrapped(out, &decls, &res);
        return TY_STRUCT0 + si;
    }
    default: break;
    }
    return TY_ERR;
}

/* ---------- statements ---------- */

static int gen_block(Node *b, int scope);

static int is_const_expr(Node *e) {                   /* known while compiling? */
    switch (e->kind) {
        case N_INT: case N_FLOAT: case N_STR: case N_BOOL: return 1;
        case N_IDENT: { Var *v = find_var(e->name); return (v && v->kind == V_CONST) || !strcmp(e->name, "PI"); }
        case N_UNARY: return is_const_expr(e->a);
        case N_BINARY: return is_const_expr(e->a) && is_const_expr(e->b);
        default: return 0;
    }
}

static int has_break(Node *blk) {                     /* does this block contain a `break` for its own loop? */
    if (!blk) return 0;
    for (int i = 0; i < blk->n; i++) {
        Node *s = blk->list[i];
        if (s->kind == N_BREAK) return 1;
        if (s->kind == N_IF) {
            for (Node *x = s; x; ) {
                if (has_break(x->b)) return 1;
                if (x->c && x->c->kind == N_IF) x = x->c;
                else { if (has_break(x->c)) return 1; x = NULL; }
            }
        }
    }
    return 0;
}

static void check_cond(Node *c, Buf *out, const char *what) {
    Ty t = gen_expr(c, out);
    if (t == TY_ERR || t == TY_BOOL) return;
    const char *help = is_num(t) ? "ask a question, like  x != 0  or  x > 5" : NULL;
    error_at(&c->tok, help, "`%s` needs a true/false question, but this is a `%s`", what, ty_name(t));
}

/* =============================================================================
 *  THE SEALER
 *
 *  Leaks happen when memory is made and nobody frees it. The Sealer is a small
 *  pass inside the code generator that works out, at compile time, who OWNS
 *  every piece of text, and writes the free() calls into your program:
 *
 *   - Text made in the middle of a line (a join, a number turned into text...)
 *     is a TEMPORARY. The line is wrapped so it is freed when the line is done.
 *   - A variable (or struct field, parameter, global) OWNS a private copy.
 *     The Sealer frees it where the variable goes out of scope: end of block,
 *     `return`, `break`, `continue`. Look for the word "sealed" in the generated C.
 *   - Assigning to a variable frees the old value after the new one is copied.
 *
 *  Nothing runs at runtime to hunt for garbage: it is all decided right here.
 * ============================================================================= */

static int owned_var(const Var *v) { return v->kind != V_LOOP && v->type != TY_ERR && needs_own(v->type); }

static void emit_free_var(const Var *v) {
    if (is_struct(v->type)) L("%s_free(&%s); /* sealed */", structs[v->type - TY_STRUCT0].cname, v->cname);
    else L("sp_free(%s); /* sealed */", v->cname);
    sealed_frees++;
    audit("[SEAL] free owned variable %s (generated name %s)", v->name, v->cname);
}
static void emit_frees(int from) {                   /* free every owned variable declared since index `from` */
    for (int i = C->nv - 1; i >= from; i--) if (owned_var(&C->vars[i])) emit_free_var(&C->vars[i]);
}

/* One line of C. If the line made temporaries, wrap it so they are freed right after it. */
static void L_tmp(int used, const char *fmt, ...) {
    Buf b = {0};
    va_list ap; va_start(ap, fmt); buf_vprintf(&b, fmt, ap); va_end(ap);
    if (used) { audit("[SEAL] release temporary values after statement"); L("{ size_t sp_m = sp_tmp_mark(); %s sp_tmp_release(sp_m); } /* sealed */", BS(b)); }
    else L("%s", BS(b));
}

/* "store the value `val` into `dst`" for a given type: copies owned data and frees what was there before */
static void emit_store(int used, Ty t, const char *dst, const char *val, int first) {
    if (!needs_own(t)) { L_tmp(used, "%s = %s;", dst, val); return; }
    if (t == TY_STR) {
        if (first) L_tmp(used, "%s = sp_adopt(%s);", dst, val);
        else L_tmp(used, "{ const char *sp_n = sp_adopt(%s); sp_free(%s); %s = sp_n; }", val, dst, dst);
    } else {
        const char *cn = structs[t - TY_STRUCT0].cname;
        if (first) L_tmp(used, "%s = %s_copy(%s);", dst, cn, val);
        else L_tmp(used, "{ %s sp_n = %s_copy(%s); %s_free(&%s); %s = sp_n; }", cn, cn, val, cn, dst, dst);
    }
    if (!first) { sealed_frees++; audit("[SEAL] replace owned value in %s, releasing previous allocation", dst); }
}

static void gen_let(Node *n) {
    int kind = n->flag == 0 ? V_LET : n->flag == 1 ? V_MUT : V_CONST;
    Ty want = TY_UNKNOWN;
    if (n->tname) want = resolve_type(n->tname, &n->ttok, 0);
    int t0 = temps;
    Buf ib = {0};
    Ty t = gen_expr(n->a, &ib);                       /* generate BEFORE declaring: `let x = x + 1` sees the old x */
    int used = temps != t0;
    if (t == TY_VOID) {
        error_at(&n->a->tok, "that function doesn't `return` a value, so there is nothing to store", "this has no value");
        t = TY_ERR;
    }
    if (kind == V_CONST && t != TY_ERR && !is_const_expr(n->a))
        error_at(&n->a->tok, "use plain numbers, text, true/false, or other `const`s (maths on them is fine)",
                 "a `const` must be known while compiling, but this isn't");
    if (want == TY_ERR) t = TY_ERR;
    else if (want != TY_UNKNOWN && t != TY_ERR) {
        if (!assignable(t, want)) { mismatch(&n->a->tok, want, t, "the value doesn't match the type you wrote"); t = TY_ERR; }
        else t = want;
    }
    Var *v = declare(&n->tok, n->name, t, kind);
    if (t == TY_ERR) return;
    const char *cn = v->cname;
    int own = needs_own(t);
    if (C == &G) {                                    /* top level: declare now, set the value when the program starts */
        buf_printf(&out_globals, "static %s %s;\n", ty_c(t), cn);
        if (own) {
            if (is_struct(t)) buf_printf(&g_free, "    %s_free(&%s); /* sealed */\n", structs[t - TY_STRUCT0].cname, cn);
            else buf_printf(&g_free, "    sp_free(%s); /* sealed */\n", cn);
            sealed_frees++;
        }
        emit_store(used, t, cn, BS(ib), 1);
    } else if (own) {
        L("%s %s = %s;", ty_c(t), cn, is_struct(t) ? "{0}" : "NULL");
        emit_store(used, t, cn, BS(ib), 1);
    } else if (used) {
        L("%s %s;", ty_c(t), cn);
        L_tmp(1, "%s = %s;", cn, BS(ib));
    } else L("%s %s = %s;", ty_c(t), cn, BS(ib));
}

static void gen_assign(Node *n) {
    Node *root = n->a;
    while (root->kind == N_FIELD) root = root->a;
    int t0 = temps;
    Buf tb = {0};
    Ty tt = gen_expr(n->a, &tb);
    if (root->kind != N_IDENT) { error_at(&n->tok, "only a variable (or a field of one) can be changed", "can't store a value here"); return; }
    Var *v = find_var(root->name);
    if (v && v->kind != V_MUT && v->type != TY_ERR) {
        char hb[240]; const char *h = NULL;
        switch (v->kind) {
            case V_LET:   snprintf(hb, sizeof hb, "`let` variables never change. Declare it with `mut` instead:  mut %s = ...", v->name); h = hb; break;
            case V_CONST: h = "a `const` is fixed forever"; break;
            case V_PARAM: snprintf(hb, sizeof hb, "parameters are read-only copies. Make your own copy:  mut my_%s = %s", v->name, v->name); h = hb; break;
            default:      h = "the `for` loop controls this variable. Use a separate `mut` variable for your own counter"; break;
        }
        error_at(&root->tok, h, "`%s` can't be changed", v->name);
    }
    Buf vb = {0}; Ty vt;
    if (n->op == T_ASSIGN) vt = gen_expr(n->b, &vb);
    else {                                            /* x += 1   means   x = x + 1 */
        Node *bn = node(N_BINARY, &n->tok);
        bn->op = n->op == T_PLUSEQ ? T_PLUS : n->op == T_MINUSEQ ? T_MINUS : n->op == T_STAREQ ? T_STAR : T_SLASH;
        bn->a = n->a; bn->b = n->b;
        vt = gen_expr(bn, &vb);
    }
    if (tt == TY_ERR || vt == TY_ERR) return;
    if (vt == TY_VOID) { error_at(&n->b->tok, "that function doesn't `return` a value", "this has no value to store"); return; }
    if (!assignable(vt, tt)) { mismatch(&n->b->tok, tt, vt, "can't store this value there"); return; }
    emit_store(temps != t0, tt, BS(tb), BS(vb), 0);
}

static void emit_return(const Token *tok, Ty t, const char *expr) {
    if (t == TY_ERR) return;
    if (t == TY_VOID) { error_at(tok, NULL, "this doesn't give back a value, so there is nothing to return"); return; }
    if (C->ret == TY_UNKNOWN) C->ret = t;
    else if (!assignable(t, C->ret)) { mismatch(tok, C->ret, t, "this function gives back a different kind of value elsewhere"); return; }
    int own = needs_own(t), any = 0;
    for (int i = 0; i < C->nv; i++) if (owned_var(&C->vars[i])) any = 1;
    if (!own && !any) { L("return %s;", expr); return; }
    /* Work out the result FIRST (it may use local variables), then free the locals, then return. */
    L("{");
    C->ind++;
    if (t == TY_STR) L("const char *sp_r = sp_tmp_dup(%s);", expr);
    else if (own) L("%s sp_r = %s_tmp(%s);", ty_c(t), structs[t - TY_STRUCT0].cname, expr);
    else L("%s sp_r = %s;", ty_c(C->ret), expr);
    emit_frees(0);
    L("return sp_r;");
    C->ind--;
    L("}");
}

static void gen_return(Node *n) {
    if (C->is_main && n->a) { error_at(&n->tok, "just let `main` finish", "`main` can't give back a value"); return; }
    if (!n->a) {
        if (C->ret == TY_UNKNOWN) C->ret = TY_VOID;
        else if (C->ret != TY_VOID && C->ret != TY_ERR)
            error_at(&n->tok, "write  return value", "this function gives back a `%s`, so `return` needs a value", ty_name(C->ret));
        emit_frees(0);
        L("return;");
        return;
    }
    Buf eb = {0};
    Ty t = gen_expr(n->a, &eb);
    emit_return(&n->a->tok, t, BS(eb));
}

static int gen_exprstmt(Node *n) {
    int t0 = temps;
    Buf eb = {0};
    Ty t = gen_expr(n->a, &eb);
    if (t == TY_ERR) return 0;
    if (n->flag && t != TY_VOID && C->ret != TY_VOID) {     /* last line of a function = its result */
        emit_return(&n->a->tok, t, BS(eb));
        return 1;
    }
    if (n->a->kind == N_CALL && !strcmp(n->a->name, "exit") && !find_fn("exit") && mod_on[M_SYS] && n->a->n == 1 && t == TY_VOID) {
        /* exit(code): the Sealer frees this function's variables, the globals and the temporaries first */
        const char *e = BS(eb); int len = (int)strlen(e);
        L("{");
        C->ind++;
        L("int sp_code = %.*s;", len - 13, e + 12);
        emit_frees(0);
        L("sp_free_globals(); sp_tmp_release(0);");
        L("sp_sys_exit(sp_code);");
        C->ind--;
        L("}");
        return 1;
    }
    if (n->a->kind == N_CALL) L_tmp(temps != t0, "%s;", BS(eb));
    else warn_at(&n->a->tok, "to keep a value, store it:  let name = ...", "this value is calculated but never used");
    return 0;
}

static void gen_print(Node *n) {
    int t0 = temps, bad = 0, calls = 0;
    if (n->n > 32) { error_at(&n->tok, NULL, "print can show at most 32 things at once"); return; }
    Buf pf[32], pa[32];
    memset(pf, 0, sizeof pf); memset(pa, 0, sizeof pa);
    for (int i = 0; i < n->n; i++) {
        Buf ab = {0};
        Ty t = gen_expr(n->list[i], &ab);
        if (has_call(n->list[i])) calls++;
        if (t == TY_ERR) { bad = 1; continue; }
        switch (t) {
            case TY_INT:  buf_add(&pf[i], "%d");    buf_printf(&pa[i], "%s", BS(ab)); break;
            case TY_F32:  buf_add(&pf[i], "%g");    buf_printf(&pa[i], "(double)(%s)", BS(ab)); break;
            case TY_F64:  buf_add(&pf[i], "%.15g"); buf_printf(&pa[i], "(double)(%s)", BS(ab)); break;
            case TY_BOOL: buf_add(&pf[i], "%s");    buf_printf(&pa[i], "(%s) ? \"true\" : \"false\"", BS(ab)); break;
            case TY_STR:  buf_add(&pf[i], "%s");    buf_printf(&pa[i], "%s", BS(ab)); break;
            case TY_VOID: error_at(&n->list[i]->tok, "that function doesn't `return` a value", "there is nothing to print here"); bad = 1; break;
            default:
                error_at(&n->list[i]->tok, "print its fields one by one, like  print p.x", "can't print a whole `%s` at once", ty_name(t));
                bad = 1; break;
        }
    }
    if (bad) return;
    Buf line = {0};
    if (calls >= 2) {          /* several calls: one printf per value, so they run left to right */
        for (int i = 0; i < n->n; i++) buf_printf(&line, "printf(\"%s%s\", %s); ", i ? " " : "", BS(pf[i]), BS(pa[i]));
        buf_add(&line, "printf(\"\\n\");");
    } else {
        Buf fmt = {0}, args = {0};
        for (int i = 0; i < n->n; i++) { if (i) buf_add(&fmt, " "); buf_add(&fmt, BS(pf[i])); buf_printf(&args, ", %s", BS(pa[i])); }
        buf_printf(&line, "printf(\"%s\\n\"%s);", BS(fmt), BS(args));
    }
    L_tmp(temps != t0, "%s", BS(line));
}

/* ---- graphics statements:  window / color / background / draw ... / show ---- */
typedef struct { const char *name; int minargs, maxargs; const char *sig; const char *cfn; const char *usage; } GfxCmd;
static const GfxCmd gfx_cmds[] = {
    { "window",      2, 3, "nns",  "sp_g_window", "window width, height, \"title\"" },
    { "show",        0, 0, "",     "sp_g_show",   "show" },
    { "draw rect",   4, 4, "nnnn", "sp_g_rect",   "draw rect x, y, width, height" },
    { "draw box",    4, 4, "nnnn", "sp_g_box",    "draw box x, y, width, height" },
    { "draw circle", 3, 3, "nnn",  "sp_g_circle", "draw circle x, y, radius" },
    { "draw ring",   3, 3, "nnn",  "sp_g_ring",   "draw ring x, y, radius" },
    { "draw line",   4, 4, "nnnn", "sp_g_line",   "draw line x1, y1, x2, y2" },
    { "draw pixel",  2, 2, "nn",   "sp_g_pixel",  "draw pixel x, y" },
    { "draw text",   3, 4, "nnan", "sp_g_text",   "draw text x, y, \"words\"   (optional 4th value = size, default 2)" },
};

static void gen_gfx(Node *n) {
    const char *w = n->name;
    if (!mod_on[M_GFX]) {
        error_at(&n->tok, "add  $import \"graphics\"  at the top of your file", "`%s` needs the graphics module, which isn't imported yet", w);
        return;
    }
    int t0 = temps;
    Buf ab[16]; Ty at[16]; int bad = 0;
    memset(ab, 0, sizeof ab);
    int special = !strcmp(w, "color") || !strcmp(w, "background");
    const GfxCmd *cmd = NULL;
    for (size_t i = 0; i < sizeof gfx_cmds / sizeof gfx_cmds[0]; i++) if (!strcmp(gfx_cmds[i].name, w)) cmd = &gfx_cmds[i];
    int lo = special ? 1 : cmd->minargs, hi = special ? 3 : cmd->maxargs;
    const char *usage = special ? (!strcmp(w, "color") ? "color 255, 0, 0     or     color \"red\"" : "background 0, 0, 40     or     background \"black\"") : cmd->usage;
    if (n->n < lo || n->n > hi || (special && n->n == 2)) {
        error_at(&n->tok, usage, "`%s` is used with the wrong number of values (you gave %d)", w, n->n);
        return;
    }
    for (int i = 0; i < n->n && i < 4; i++) {
        at[i] = gen_expr(n->list[i], &ab[i]);
        if (at[i] == TY_ERR) { bad = 1; continue; }
        char c = special ? (n->n == 1 ? 's' : 'n') : cmd->sig[i];
        if (c == 'n' && !is_num(at[i])) { error_at(&n->list[i]->tok, usage, "`%s` needs a number here, but found `%s`", w, ty_name(at[i])); bad = 1; }
        else if (c == 's' && at[i] != TY_STR) { mismatch(&n->list[i]->tok, TY_STR, at[i], "wrong kind of value"); bad = 1; }
        else if (c == 'a' && (at[i] == TY_VOID || is_struct(at[i]))) { error_at(&n->list[i]->tok, usage, "can't draw this as text"); bad = 1; }
    }
    if (bad) return;
    Buf args = {0};
    if (special) {
        Buf set = {0};
        if (n->n == 1) buf_printf(&set, "sp_g_color_name(%s)", BS(ab[0]));
        else buf_printf(&set, "sp_g_color((int)(%s), (int)(%s), (int)(%s))", BS(ab[0]), BS(ab[1]), BS(ab[2]));
        if (!strcmp(w, "color")) L_tmp(temps != t0, "%s;", BS(set));
        else L_tmp(temps != t0, "{ unsigned sp_keep = sp_gcol; %s; sp_g_background(); sp_gcol = sp_keep; }", BS(set));
        return;
    }
    for (int i = 0; i < n->n; i++) {
        if (i) buf_add(&args, ", ");
        char c = cmd->sig[i];
        if (c == 'n') buf_printf(&args, "(int)(%s)", BS(ab[i]));
        else if (c == 'a') to_text(&args, at[i], BS(ab[i]));
        else buf_add(&args, BS(ab[i]));
    }
    if (!strcmp(w, "window") && n->n == 2) buf_add(&args, ", \"Sparks\"");
    if (!strcmp(w, "draw text") && n->n == 3) buf_add(&args, ", 2");
    L_tmp(temps != t0, "%s(%s);", cmd->cfn, BS(args));
}

/* `if (cond) {`  - if the condition makes temporaries, compute it first inside a cleanup wrapper */
static void emit_cond_line(Node *c, const char *what, int is_elseif, int *extra) {
    Buf cb = {0};
    int t0 = temps;
    check_cond(c, &cb, what);
    if (temps == t0) { L(is_elseif ? "} else if (%s) {" : "if (%s) {", BS(cb)); return; }
    if (is_elseif) { L("} else {"); C->ind++; (*extra)++; }
    int id = ++uniq;
    L("bool sp_c%d;", id);
    L("{ size_t sp_m = sp_tmp_mark(); sp_c%d = %s; sp_tmp_release(sp_m); } /* sealed */", id, BS(cb));
    L("if (sp_c%d) {", id);
}

static int gen_if(Node *n) {
    int extra = 0, has_else = 0;
    emit_cond_line(n->a, "if", 0, &extra);
    C->ind++; int all = gen_block(n->b, 1); C->ind--;
    for (Node *e = n->c; e; ) {
        if (e->kind == N_IF) {
            emit_cond_line(e->a, "else if", 1, &extra);
            C->ind++; all &= gen_block(e->b, 1); C->ind--;
            e = e->c;
        } else {
            L("} else {");
            C->ind++; all &= gen_block(e, 1); C->ind--;
            has_else = 1; e = NULL;
        }
    }
    L("}");
    while (extra-- > 0) { C->ind--; L("}"); }
    return all && has_else;
}

/* SPASM is emitted into native machine code by GCC/Clang's assembler. */
static void gen_spasm(Node *n) {
    for (int i=0; i<n->n; i++) {
        Node *line=n->list[i];
        Buf ins={0};
        if (line->flag) {
            const char *h=line->name;
            int hi=-1, count=0;
            for (; *h; h++) {
                unsigned char c=(unsigned char)*h;
                if (c==' ' || c=='\t' || c==',' || c=='_') continue;
                int v=(c>='0'&&c<='9')?c-'0':(c>='a'&&c<='f')?c-'a'+10:(c>='A'&&c<='F')?c-'A'+10:-1;
                if (v<0) { error_at(&line->tok, "use hexadecimal pairs such as 90 or 0F 1F 00", "invalid hexadecimal instruction bytes"); return; }
                if (hi<0) hi=v;
                else { buf_printf(&ins, "%s0x%02X", count++ ? "," : ".byte ", hi*16+v); hi=-1; }
            }
            if (hi>=0 || !count) { error_at(&line->tok, "use complete byte pairs", "hex instruction bytes must have an even number of digits"); return; }
        } else buf_add(&ins,line->name);
        Buf esc={0};
        for (const char *q=BS(ins); *q; q++) {
            if (*q=='\\' || *q=='"') buf_add(&esc,"\\");
            if (*q=='\n') buf_add(&esc,"\\n");
            else { char c[2]={*q,0}; buf_add(&esc,c); }
        }
        L("__asm__ __volatile__(\"%s\" ::: \"memory\");", BS(esc));
    }
}

/* Returns 1 if the statement never "falls through" to the next one (it returns, or loops forever). */
static int gen_stmt(Node *n) {
    switch (n->kind) {
    case N_LET:      gen_let(n); return 0;
    case N_ASSIGN:   gen_assign(n); return 0;
    case N_EXPRSTMT: return gen_exprstmt(n);
    case N_PRINT:    gen_print(n); return 0;
    case N_GFX:      gen_gfx(n); return 0;
    case N_SPASM:    gen_spasm(n); return 0;
    case N_IF:       return gen_if(n);
    case N_RETURN:   gen_return(n); return 1;
    case N_BREAK:
    case N_CONTINUE:
        if (!C->loops) error_at(&n->tok, "use it inside a `loop` or `for` block", "`%s` only makes sense inside a loop", n->kind == N_BREAK ? "break" : "continue");
        else { emit_frees(C->loop_nv[C->loops - 1]); L(n->kind == N_BREAK ? "break;" : "continue;"); }
        return 0;
    case N_LOOP: {
        Buf cb = {0}; int used = 0;
        if (n->a) { int t0 = temps; check_cond(n->a, &cb, "loop"); used = temps != t0; }
        if (!n->a) L("while (1) {");
        else if (!used) L("while (%s) {", BS(cb));
        else {
            int id = ++uniq;
            L("while (1) {");
            C->ind++;
            L("bool sp_c%d;", id);
            L("{ size_t sp_m = sp_tmp_mark(); sp_c%d = %s; sp_tmp_release(sp_m); } /* sealed */", id, BS(cb));
            L("if (!sp_c%d) break;", id);
            C->ind--;
        }
        C->ind++;
        if (C->loops >= 31) die("loops are nested too deeply");
        C->loop_nv[C->loops++] = C->nv;
        gen_block(n->b, 1);
        C->loops--; C->ind--;
        L("}");
        return !n->a && !has_break(n->b);
    }
    case N_FOR: {
        Buf lo = {0}, hi = {0};
        int t0 = temps;
        Ty lt = gen_expr(n->a, &lo), ht = gen_expr(n->b, &hi);
        int used = temps != t0;
        if (lt != TY_ERR && lt != TY_INT) mismatch(&n->a->tok, TY_INT, lt, "a `for` range needs whole numbers");
        if (ht != TY_ERR && ht != TY_INT) mismatch(&n->b->tok, TY_INT, ht, "a `for` range needs whole numbers");
        int id = ++uniq;
        if (used) {                                   /* the bounds make temporaries: compute them once, up front */
            L("int sp_lo%d, sp_hi%d;", id, id);
            L("{ size_t sp_m = sp_tmp_mark(); sp_lo%d = %s; sp_hi%d = %s; sp_tmp_release(sp_m); } /* sealed */", id, BS(lo), id, BS(hi));
            Buf nl = {0}, nh = {0};
            buf_printf(&nl, "sp_lo%d", id); buf_printf(&nh, "sp_hi%d", id);
            lo = nl; hi = nh;
        }
        push_scope();
        Var *v = declare(&n->tok, n->name, TY_INT, V_LOOP);
        char *cn = v->cname;
        L("for (int %s = %s, sp_end%d = %s; %s < sp_end%d; %s++) {", cn, BS(lo), id, BS(hi), cn, id, cn);
        C->ind++;
        if (C->loops >= 31) die("loops are nested too deeply");
        C->loop_nv[C->loops++] = C->nv;
        int term = gen_block(n->c, 0);
        if (!term) emit_frees(C->marks[C->nmarks - 1]);
        C->loops--; C->ind--;
        L("}");
        pop_scope();
        return 0;
    }
    default: break;
    }
    return 0;
}

static int gen_block(Node *b, int scope) {
    if (scope) push_scope();
    int term = 0, warned = 0;
    for (int i = 0; i < b->n; i++) {
        if (term && !warned) { warn_at(&b->list[i]->tok, "remove it, or move it before the `return`", "this code can never run"); warned = 1; }
        term = gen_stmt(b->list[i]);
    }
    if (scope) {
        if (!term) emit_frees(C->marks[C->nmarks - 1]);   /* the block ends: seal everything it created */
        pop_scope();
    }
    return term;
}

/* ---------- functions ---------- */

static void mark_tail(Node *blk) {                    /* the last expression of a function becomes `return expr` */
    if (!blk || blk->n == 0) return;
    Node *last = blk->list[blk->n - 1];
    if (last->kind == N_EXPRSTMT) { last->flag = 1; return; }
    if (last->kind != N_IF) return;
    Node *x = last;
    while (x->c && x->c->kind == N_IF) x = x->c;
    if (!x->c) return;                                /* an `if` without `else` can't produce a value */
    for (x = last; x; ) {
        mark_tail(x->b);
        if (x->c && x->c->kind == N_IF) x = x->c;
        else { mark_tail(x->c); x = NULL; }
    }
}

static void gen_instance(Inst *in) {
    Node *fn = in->fn;
    Ctx ctx; memset(&ctx, 0, sizeof ctx);
    Buf body = {0};
    ctx.out = &body; ctx.ind = 1; ctx.ret = TY_UNKNOWN;
    ctx.is_main = !strcmp(fn->name, "main");
    Ctx *saved = C; C = &ctx;
    int saved_temps = temps;
    in->in_progress = 1;
    if (fn->tname) { ctx.ret = resolve_type(fn->tname, &fn->ttok, 1); in->ret = ctx.ret; }
    if (ctx.is_main && (fn->n || fn->tname))
        error_at(&fn->tok, "write it as  fn main()", "`main` can't take values or give one back");
    for (int i = 0; i < fn->n; i++) declare(&fn->list[i]->tok, fn->list[i]->name, in->args[i], V_PARAM);
    for (int i = 0; i < fn->n; i++) {                 /* the function keeps its own copy of text/structs it is given */
        Var *pv = &ctx.vars[i];
        if (owned_var(pv)) {
            if (is_struct(pv->type)) L("%s = %s_copy(%s);", pv->cname, structs[pv->type - TY_STRUCT0].cname, pv->cname);
            else L("%s = sp_dup(%s);", pv->cname, pv->cname);
        }
    }
    if (!ctx.is_main) mark_tail(fn->a);
    int term = gen_block(fn->a, 0);
    if (!term) emit_frees(0);                         /* falling off the end: seal parameters and locals */
    Ty ret = ctx.ret == TY_UNKNOWN ? TY_VOID : ctx.ret;
    if (!ctx.is_main && ret != TY_VOID && ret != TY_ERR && !term)
        error_at(&fn->tok, "end the function with a value, and make sure every `if` branch has an `else`",
                 "`%s` can finish without giving back a value on some path", fn->name);
    in->ret = ret; in->in_progress = 0;
    Buf sig = {0};
    for (int i = 0; i < fn->n; i++) buf_printf(&sig, "%s%s %s", i ? ", " : "", ty_c(in->args[i]), ctx.vars[i].cname);
    if (!fn->n) buf_add(&sig, "void");
    buf_printf(&out_protos, "static %s %s(%s);\n", ty_c(ret), in->cname, BS(sig));
    buf_printf(&out_funcs, "static %s %s(%s) {\n%s}\n\n", ty_c(ret), in->cname, BS(sig), BS(body));
    temps = saved_temps;
    C = saved;
}

/* ---------- the whole program ---------- */

static void declare_struct(Node *d) {
    for (int i = 0; i < nstructs; i++)
        if (!strcmp(structs[i].name, d->name)) { error_at(&d->tok, NULL, "a struct called `%s` already exists", d->name); return; }
    if (!isupper((unsigned char)d->name[0]))
        error_at(&d->tok, "struct names start with a capital letter, like  Vector2", "`%s` should start with a capital letter", d->name);
    if (nstructs >= 128) die("too many structs");
    StructDef sd; memset(&sd, 0, sizeof sd);
    sd.name = d->name; sd.tok = d->tok;
    Buf cn = {0}; buf_printf(&cn, "s_%s", d->name); sd.cname = cn.s;
    Buf body = {0};
    for (int i = 0; i < d->n; i++) {
        Node *f = d->list[i];
        for (int k = 0; k < sd.nf; k++) if (!strcmp(sd.fname[k], f->name)) { error_at(&f->tok, NULL, "the field `%s` is defined twice", f->name); }
        Ty t = resolve_type(f->tname, &f->ttok, 0);
        if (t == TY_ERR) continue;
        if (sd.nf >= MAX_FIELDS) { error_at(&f->tok, NULL, "a struct can have at most %d fields", MAX_FIELDS); break; }
        sd.fname[sd.nf] = f->name; sd.ftype[sd.nf] = t; sd.nf++;
        buf_printf(&body, "    %s %s;\n", ty_c(t), csafe(f->name));
    }
    if (sd.nf == 0) { error_at(&d->tok, "add fields like  x: f32", "struct `%s` needs at least one field", d->name); return; }
    structs[nstructs++] = sd;
    buf_printf(&out_structs, "typedef struct {\n%s} %s;\n\n", BS(body), sd.cname);
    if (needs_own(TY_STRUCT0 + nstructs - 1)) {       /* the Sealer's helpers for structs that hold text */
        Buf cp = {0}, tp = {0}, fr = {0};
        for (int i = 0; i < sd.nf; i++) {
            if (!needs_own(sd.ftype[i])) continue;
            char *f = csafe(sd.fname[i]);
            if (sd.ftype[i] == TY_STR) {
                buf_printf(&cp, "    v.%s = sp_dup(v.%s);\n", f, f);
                buf_printf(&tp, "    v.%s = sp_tmp_dup(v.%s);\n", f, f);
                buf_printf(&fr, "    sp_free(v->%s);\n", f);
            } else {
                const char *fc = structs[sd.ftype[i] - TY_STRUCT0].cname;
                buf_printf(&cp, "    v.%s = %s_copy(v.%s);\n", f, fc, f);
                buf_printf(&tp, "    v.%s = %s_tmp(v.%s);\n", f, fc, f);
                buf_printf(&fr, "    %s_free(&v->%s);\n", fc, f);
            }
        }
        buf_printf(&out_structs, "static %s %s_copy(%s v) {\n%s    return v;\n}\n", sd.cname, sd.cname, sd.cname, BS(cp));
        buf_printf(&out_structs, "static %s %s_tmp(%s v) {\n%s    return v;\n}\n", sd.cname, sd.cname, sd.cname, BS(tp));
        buf_printf(&out_structs, "static void %s_free(%s *v) {\n%s}\n\n", sd.cname, sd.cname, BS(fr));
    }
}

static void register_fn(Node *d) {
    Node *old = find_fn(d->name);
    if (old) { error_at(&d->tok, "give each function its own name", "a function called `%s` already exists (line %d)", d->name, old->tok.line); return; }
    if (d->n > MAX_PARAMS) { error_at(&d->tok, NULL, "a function can take at most %d values", MAX_PARAMS); return; }
    if (nfns >= 256) die("too many functions");
    fns[nfns++] = d;
}

static int has_inst(Node *fn) {
    for (int i = 0; i < ninsts; i++) if (insts[i]->fn == fn) return 1;
    return 0;
}

static void compile_program(Node *prog) {
    for (int i = 0; i < prog->n; i++) {                       /* pass 1: know all structs and function names */
        Node *d = prog->list[i];
        if (d->kind == N_STRUCT) declare_struct(d);
        else if (d->kind == N_FN) register_fn(d);
    }
    G.out = &g_init; G.ind = 1; C = &G;                       /* pass 2: top-level variables, in order */
    for (int i = 0; i < prog->n; i++) if (prog->list[i]->kind == N_LET) gen_let(prog->list[i]);

    Node *m = find_fn("main");                                /* pass 3: start from main; it pulls in what it calls */
    if (!m) {
        error_at(NULL, "every Sparks program starts here:\n         fn main()\n             print \"Hello!\"", "this program has no `fn main()`");
    } else {
        Ty key[MAX_PARAMS];
        get_inst(m, key);
    }
    for (int i = 0; i < nfns; i++) {                          /* pass 4: functions nobody called */
        Node *fn = fns[i];
        if (has_inst(fn)) continue;
        Ty key[MAX_PARAMS]; int ok = 1;
        for (int k = 0; k < fn->n; k++) {
            if (!fn->list[k]->tname) { ok = 0; break; }
            key[k] = resolve_type(fn->list[k]->tname, &fn->list[k]->ttok, 0);
            if (key[k] == TY_ERR) { ok = 0; break; }
        }
        if (ok) get_inst(fn, key);
        else warn_at(&fn->tok, "call it from `main` (or write the parameter types, like  a: int) so I can check what's inside",
                     "`%s` is never called, so I couldn't check its code", fn->name);
    }
}

/* =============================================================================
 *  6. THE RUNTIME  (small helper functions copied into every program)
 * ============================================================================= */


/* ---- the runtime, stored as text inside the compiler (source: rt/base.c, rt/gfx.c) ---- */
static const char RUNTIME[] =
"#define _POSIX_C_SOURCE 200809L\n"
"#include <stdio.h>\n"
"#include <stdlib.h>\n"
#include <stdint.h>
"#include <string.h>\n"
"#include <stdbool.h>\n"
"#include <math.h>\n"
"#include <time.h>\n"
"#ifdef _WIN32\n"
"#include <windows.h>\n"
"#endif\n"
"\n"
"/* ---- Sparks runtime: small helpers the program above uses ---- */\n"
"\n"
"/* ---- Memory: the SEALER does all the freeing, at compile time ----\n"
" * Text made while a line runs (joins, number->text, input...) is a TEMPORARY: it is registered here\n"
" * and freed as soon as that line is finished. Variables own private copies (sp_dup), and the\n"
" * compiler writes the matching sp_free(...) where each variable goes out of scope\n"
" * (look for the \"sealed\" comments in the generated C). No collector runs while your program does. */\n"
"static void **sp_tmps = NULL;\n"
"static size_t sp_ntmp = 0, sp_ctmp = 0;\n"
"static void sp_oom(void) { fputs(\"Out of memory\\n\", stderr); exit(1); }\n"
"static char *sp_new(size_t n) {                      /* a temporary: freed at the end of the line */\n"
"    char *p = malloc(n);\n"
"    if (!p) sp_oom();\n"
"    if (sp_ntmp == sp_ctmp) {\n"
"        sp_ctmp = sp_ctmp ? sp_ctmp * 2 : 64;\n"
"        sp_tmps = realloc(sp_tmps, sp_ctmp * sizeof *sp_tmps);\n"
"        if (!sp_tmps) sp_oom();\n"
"    }\n"
"    sp_tmps[sp_ntmp++] = p;\n"
"    return p;\n"
"}\n"
"static size_t sp_tmp_mark(void) { return sp_ntmp; }\n"
"static void sp_tmp_release(size_t mark) { while (sp_ntmp > mark) free(sp_tmps[--sp_ntmp]); }\n"
"static const char *sp_dup(const char *s) {           /* a private copy that a variable owns */\n"
"    size_t n = strlen(s) + 1; char *p = malloc(n);\n"
"    if (!p) sp_oom();\n"
"    memcpy(p, s, n); return p;\n"
"}\n"
"static const char *sp_tmp_dup(const char *s) {       /* a temporary copy (used for return values) */\n"
"    size_t n = strlen(s) + 1; char *p = sp_new(n);\n"
"    memcpy(p, s, n); return p;\n"
"}\n"
"static const char *sp_adopt(const char *s) {         /* take ownership of a fresh temporary without copying it */\n"
"    if (sp_ntmp > 0 && (const char *)sp_tmps[sp_ntmp - 1] == s) { sp_ntmp--; return s; }\n"
"    return sp_dup(s);\n"
"}\n"
"static void sp_free(const char *s) { free((void *)s); }\n"
"\n"
"/* ---- text helpers ---- */\n"
"static const char *sp_cat(const char *a, const char *b) {\n"
"    size_t la = strlen(a), lb = strlen(b);\n"
"    char *r = sp_new(la + lb + 1);\n"
"    memcpy(r, a, la); memcpy(r + la, b, lb + 1);\n"
"    return r;\n"
"}\n"
"static const char *sp_str_int(int v) { char *r = sp_new(16); snprintf(r, 16, \"%d\", v); return r; }\n"
"static const char *sp_str_f32(double v) { char *r = sp_new(32); snprintf(r, 32, \"%g\", v); return r; }\n"
"static const char *sp_str_f64(double v) { char *r = sp_new(40); snprintf(r, 40, \"%.15g\", v); return r; }\n"
"static const char *sp_str_bool(bool v) { return v ? \"true\" : \"false\"; }\n"
"static int sp_len(const char *s) { return (int)strlen(s); }\n"
"\n"
"/* ---- maths ---- */\n"
"static int sp_idiv(int a, int b, int line) {\n"
"    if (b == 0) { fprintf(stderr, \"Runtime error on line %d: can't divide by zero\\n\", line); exit(1); }\n"
"    return a / b;\n"
"}\n"
"static int sp_imod(int a, int b, int line) {\n"
"    if (b == 0) { fprintf(stderr, \"Runtime error on line %d: can't divide by zero\\n\", line); exit(1); }\n"
"    return a % b;\n"
"}\n"
"static int sp_abs_i(int a) { return a < 0 ? -a : a; }\n"
"static int sp_min_i(int a, int b) { return a < b ? a : b; }\n"
"static int sp_max_i(int a, int b) { return a > b ? a : b; }\n"
"static double sp_min_f(double a, double b) { return a < b ? a : b; }\n"
"static double sp_max_f(double a, double b) { return a > b ? a : b; }\n"
"static double sp_dist(double x1, double y1, double x2, double y2) { return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)); }\n"
"\n"
"/* ---- keyboard ---- */\n"
"static const char *sp_input(const char *prompt) {\n"
"    char buf[4096];\n"
"    fputs(prompt, stdout); fflush(stdout);\n"
"    if (!fgets(buf, sizeof buf, stdin)) { fputs(\"\\n(no more input - stopping the program)\\n\", stdout); exit(0); }\n"
"    size_t n = strlen(buf);\n"
"    while (n > 0 && (buf[n-1] == '\\n' || buf[n-1] == '\\r')) buf[--n] = 0;\n"
"    char *r = sp_new(n + 1); memcpy(r, buf, n + 1);\n"
"    return r;\n"
"}\n"
"static int sp_input_int(const char *prompt) {\n"
"    for (;;) {\n"
"        const char *s = sp_input(prompt);\n"
"        char *end; long v = strtol(s, &end, 10);\n"
"        while (*end == ' ') end++;\n"
"        if (end != s && *end == 0) return (int)v;\n"
"        puts(\"Please type a whole number.\");\n"
"    }\n"
"}\n"
"\n"
"/* ---- games ---- */\n"
"static int sp_rand(int lo, int hi) {\n"
"    if (lo > hi) { int t = lo; lo = hi; hi = t; }\n"
"    return lo + rand() % (hi - lo + 1);\n"
"}\n"
"static long sp_now_raw(void) {\n"
"#ifdef _WIN32\n"
"    return (long)GetTickCount();\n"
"#else\n"
"    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);\n"
"    return ts.tv_sec * 1000L + ts.tv_nsec / 1000000L;\n"
"#endif\n"
"}\n"
"static long sp_t0 = 0;\n"
"static int sp_time_ms(void) { return (int)(sp_now_raw() - sp_t0); }\n"
"static void sp_sleep(int ms) {\n"
"    fflush(stdout);\n"
"#ifdef _WIN32\n"
"    Sleep(ms);\n"
"#else\n"
"    struct timespec ts; ts.tv_sec = ms / 1000; ts.tv_nsec = (long)(ms % 1000) * 1000000L;\n"
"    nanosleep(&ts, NULL);\n"
"#endif\n"
"}\n"
"static void sp_clear(void) {\n"
"#ifdef _WIN32\n"
"    system(\"cls\");\n"
"#else\n"
"    fputs(\"\\033[2J\\033[H\", stdout);\n"
"#endif\n"
"    fflush(stdout);\n"
"}\n"
"static void sp_rt_init(void) {\n"
"    srand((unsigned)time(NULL)); sp_t0 = sp_now_raw();\n"
"}\n"
"\n";

static const char RUNTIME_GFX[] =
"/* ---- Sparks graphics ----\n"
" * Everything you draw goes into a block of pixels in memory (sp_gpix).\n"
" * `show` sends that block to the screen (SDL2 window) - or to an image file in headless mode. */\n"
"static int sp_gw = 0, sp_gh = 0;\n"
"static unsigned *sp_gpix = NULL;\n"
"static unsigned sp_gcol = 0xFFFFFFu;\n"
"static int sp_gquit = 0, sp_gframes = 0, sp_gmx = 0, sp_gmy = 0, sp_gmdown = 0;\n"
"\n"
"static void sp_g_need(void) {\n"
"    if (!sp_gpix) { fputs(\"Runtime error: open a window first, like:  window 640, 480, \\\"My game\\\"\\n\", stderr); exit(1); }\n"
"}\n"
"static void sp_g_pixel(int x, int y) {\n"
"    sp_g_need();\n"
"    if ((unsigned)x < (unsigned)sp_gw && (unsigned)y < (unsigned)sp_gh) sp_gpix[y * sp_gw + x] = sp_gcol;\n"
"}\n"
"static void sp_g_hspan(int x0, int x1, int y) {\n"
"    if (y < 0 || y >= sp_gh) return;\n"
"    if (x0 < 0) x0 = 0;\n"
"    if (x1 >= sp_gw) x1 = sp_gw - 1;\n"
"    for (int x = x0; x <= x1; x++) sp_gpix[y * sp_gw + x] = sp_gcol;\n"
"}\n"
"static void sp_g_rect(int x, int y, int w, int h) {\n"
"    sp_g_need();\n"
"    for (int j = 0; j < h; j++) sp_g_hspan(x, x + w - 1, y + j);\n"
"}\n"
"static void sp_g_circle(int cx, int cy, int r) {\n"
"    sp_g_need();\n"
"    for (int dy = -r; dy <= r; dy++) {\n"
"        int dx = (int)(sqrt((double)(r * r - dy * dy)) + 0.5);\n"
"        sp_g_hspan(cx - dx, cx + dx, cy + dy);\n"
"    }\n"
"}\n"
"static void sp_g_line(int x0, int y0, int x1, int y1) {\n"
"    sp_g_need();\n"
"    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;\n"
"    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;\n"
"    int err = dx + dy;\n"
"    for (;;) {\n"
"        sp_g_pixel(x0, y0);\n"
"        if (x0 == x1 && y0 == y1) break;\n"
"        int e2 = 2 * err;\n"
"        if (e2 >= dy) { err += dy; x0 += sx; }\n"
"        if (e2 <= dx) { err += dx; y0 += sy; }\n"
"    }\n"
"}\n"
"static void sp_g_box(int x, int y, int w, int h) {\n"
"    sp_g_line(x, y, x + w - 1, y); sp_g_line(x, y + h - 1, x + w - 1, y + h - 1);\n"
"    sp_g_line(x, y, x, y + h - 1); sp_g_line(x + w - 1, y, x + w - 1, y + h - 1);\n"
"}\n"
"static void sp_g_ring(int cx, int cy, int r) {\n"
"    sp_g_need();\n"
"    int x = r, y = 0, err = 1 - r;\n"
"    while (x >= y) {\n"
"        sp_g_pixel(cx + x, cy + y); sp_g_pixel(cx + y, cy + x); sp_g_pixel(cx - y, cy + x); sp_g_pixel(cx - x, cy + y);\n"
"        sp_g_pixel(cx - x, cy - y); sp_g_pixel(cx - y, cy - x); sp_g_pixel(cx + y, cy - x); sp_g_pixel(cx + x, cy - y);\n"
"        y++;\n"
"        if (err < 0) err += 2 * y + 1; else { x--; err += 2 * (y - x) + 1; }\n"
"    }\n"
"}\n"
"\n"
"/* classic 5x7 font, characters 32..126, one byte per column (bit 0 = top row) */\n"
"static const unsigned char sp_font[95][5] = {\n"
"{0,0,0,0,0},{0,0,0x5F,0,0},{0,7,0,7,0},{0x14,0x7F,0x14,0x7F,0x14},{0x24,0x2A,0x7F,0x2A,0x12},\n"
"{0x23,0x13,8,0x64,0x62},{0x36,0x49,0x56,0x20,0x50},{0,8,7,3,0},{0,0x1C,0x22,0x41,0},{0,0x41,0x22,0x1C,0},\n"
"{0x2A,0x1C,0x7F,0x1C,0x2A},{8,8,0x3E,8,8},{0,0x80,0x70,0x30,0},{8,8,8,8,8},{0,0,0x60,0x60,0},\n"
"{0x20,0x10,8,4,2},{0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},{0x72,0x49,0x49,0x49,0x46},{0x21,0x41,0x49,0x4D,0x33},\n"
"{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x31},{0x41,0x21,0x11,9,7},{0x36,0x49,0x49,0x49,0x36},\n"
"{0x46,0x49,0x49,0x29,0x1E},{0,0,0x14,0,0},{0,0x40,0x34,0,0},{0,8,0x14,0x22,0x41},{0x14,0x14,0x14,0x14,0x14},\n"
"{0,0x41,0x22,0x14,8},{2,1,0x59,9,6},{0x3E,0x41,0x5D,0x59,0x4E},{0x7C,0x12,0x11,0x12,0x7C},{0x7F,0x49,0x49,0x49,0x36},\n"
"{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x41,0x3E},{0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},{0x3E,0x41,0x41,0x51,0x73},\n"
"{0x7F,8,8,8,0x7F},{0,0x41,0x7F,0x41,0},{0x20,0x40,0x41,0x3F,1},{0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},\n"
"{0x7F,2,0x1C,2,0x7F},{0x7F,4,8,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},{0x7F,9,9,9,6},{0x3E,0x41,0x51,0x21,0x5E},\n"
"{0x7F,9,0x19,0x29,0x46},{0x26,0x49,0x49,0x49,0x32},{3,1,0x7F,1,3},{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},\n"
"{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,8,0x14,0x63},{3,4,0x78,4,3},{0x61,0x59,0x49,0x4D,0x43},{0,0x7F,0x41,0x41,0x41},\n"
"{2,4,8,0x10,0x20},{0,0x41,0x41,0x41,0x7F},{4,2,1,2,4},{0x40,0x40,0x40,0x40,0x40},{0,3,7,8,0},\n"
"{0x20,0x54,0x54,0x78,0x40},{0x7F,0x28,0x44,0x44,0x38},{0x38,0x44,0x44,0x44,0x28},{0x38,0x44,0x44,0x28,0x7F},{0x38,0x54,0x54,0x54,0x18},\n"
"{0,8,0x7E,9,2},{0x18,0xA4,0xA4,0x9C,0x78},{0x7F,8,4,4,0x78},{0,0x44,0x7D,0x40,0},{0x20,0x40,0x40,0x3D,0},\n"
"{0x7F,0x10,0x28,0x44,0},{0,0x41,0x7F,0x40,0},{0x7C,4,0x78,4,0x78},{0x7C,8,4,4,0x78},{0x38,0x44,0x44,0x44,0x38},\n"
"{0xFC,0x18,0x24,0x24,0x18},{0x18,0x24,0x24,0x18,0xFC},{0x7C,8,4,4,8},{0x48,0x54,0x54,0x54,0x24},{4,4,0x3F,0x44,0x24},\n"
"{0x3C,0x40,0x40,0x20,0x7C},{0x1C,0x20,0x40,0x20,0x1C},{0x3C,0x40,0x30,0x40,0x3C},{0x44,0x28,0x10,0x28,0x44},{0x4C,0x90,0x90,0x90,0x7C},\n"
"{0x44,0x64,0x54,0x4C,0x44},{0,8,0x36,0x41,0},{0,0,0x77,0,0},{0,0x41,0x36,8,0},{2,1,2,4,2}\n"
"};\n"
"static void sp_g_text(int x, int y, const char *s, int scale) {\n"
"    sp_g_need();\n"
"    if (scale < 1) scale = 1;\n"
"    for (; *s; s++, x += 6 * scale) {\n"
"        unsigned char c = (unsigned char)*s;\n"
"        if (c < 32 || c > 126) c = '?';\n"
"        for (int col = 0; col < 5; col++)\n"
"            for (int row = 0; row < 8; row++)\n"
"                if (sp_font[c - 32][col] & (1 << row)) sp_g_rect(x + col * scale, y + row * scale, scale, scale);\n"
"    }\n"
"}\n"
"static void sp_g_color(int r, int g, int b) {\n"
"    if (r < 0) r = 0; if (r > 255) r = 255;\n"
"    if (g < 0) g = 0; if (g > 255) g = 255;\n"
"    if (b < 0) b = 0; if (b > 255) b = 255;\n"
"    sp_gcol = ((unsigned)r << 16) | ((unsigned)g << 8) | (unsigned)b;\n"
"}\n"
"static void sp_g_color_name(const char *n) {\n"
"    static const struct { const char *name; int r, g, b; } t[] = {\n"
"        {\"red\",230,40,40},{\"green\",40,200,70},{\"blue\",50,90,230},{\"yellow\",250,220,40},{\"orange\",250,140,30},\n"
"        {\"purple\",150,70,210},{\"pink\",250,130,190},{\"white\",255,255,255},{\"black\",0,0,0},{\"gray\",128,128,128},\n"
"        {\"cyan\",40,210,230},{\"brown\",140,90,50} };\n"
"    for (size_t i = 0; i < sizeof t / sizeof t[0]; i++)\n"
"        if (!strcmp(n, t[i].name)) { sp_g_color(t[i].r, t[i].g, t[i].b); return; }\n"
"    fprintf(stderr, \"Runtime error: I don't know the color \\\"%s\\\". Try red, green, blue, yellow, orange, purple, pink, white, black, gray, cyan or brown.\\n\", n);\n"
"    exit(1);\n"
"}\n"
"static void sp_g_background(void) {\n"
"    sp_g_need();\n"
"    for (int i = 0; i < sp_gw * sp_gh; i++) sp_gpix[i] = sp_gcol;\n"
"}\n"
"\n"
"#ifdef SP_USE_RAYLIB\n"
"#include <raylib.h>\n"
"static Texture2D sp_ray_tex;\n"
"static void sp_g_backend_close(void) { UnloadTexture(sp_ray_tex); CloseWindow(); }\n"
"static void sp_g_backend_open(const char *title) {\n"
"    InitWindow(sp_gw, sp_gh, title);\n"
"    if (!IsWindowReady()) { fputs(\"raylib window failed\\n\", stderr); exit(1); }\n"
"    Image img = GenImageColor(sp_gw, sp_gh, BLACK);\n"
"    sp_ray_tex = LoadTextureFromImage(img); UnloadImage(img);\n"
"    SetTargetFPS(60); atexit(sp_g_backend_close);\n"
"}\n"
"static void sp_g_backend_present(void) {\n"
"    Color *pixels = malloc((size_t)sp_gw * sp_gh * sizeof(Color));\n"
"    if (!pixels) exit(1);\n"
"    for (int i=0; i<sp_gw*sp_gh; ++i) { unsigned c=sp_gpix[i]; pixels[i]=(Color){(c>>16)&255,(c>>8)&255,c&255,255}; }\n"
"    UpdateTexture(sp_ray_tex, pixels); free(pixels);\n"
"    BeginDrawing(); DrawTexture(sp_ray_tex, 0, 0, WHITE); EndDrawing();\n"
"    if (WindowShouldClose()) sp_gquit=1;\n"
"    Vector2 m=GetMousePosition(); sp_gmx=(int)m.x; sp_gmy=(int)m.y; sp_gmdown=IsMouseButtonDown(MOUSE_BUTTON_LEFT);\n"
"}\n"
"static int sp_g_key_down(const char *name) {\n"
"    int key=0; if (!strcmp(name,\"left\")) key=KEY_LEFT; else if (!strcmp(name,\"right\")) key=KEY_RIGHT;\n"
"    else if (!strcmp(name,\"up\")) key=KEY_UP; else if (!strcmp(name,\"down\")) key=KEY_DOWN;\n"
"    else if (!strcmp(name,\"space\")) key=KEY_SPACE; else if (!strcmp(name,\"enter\")) key=KEY_ENTER;\n"
"    else if (strlen(name)==1 && name[0]>='a' && name[0]<='z') key=KEY_A+name[0]-'a';\n"
"    return key ? IsKeyDown(key) : 0;\n"
"}\n"
"#elif defined(SP_USE_SDL)\n"
"/* ---- window backend: SDL2 ---- */\n"
"#define SDL_MAIN_HANDLED\n"
"#include <SDL.h>\n"
"static SDL_Window *sp_win = NULL; static SDL_Renderer *sp_ren = NULL; static SDL_Texture *sp_tex = NULL;\n"
"static Uint32 sp_frame_start = 0;\n"
"static void sp_g_backend_close(void) {\n"
"    if (sp_tex) SDL_DestroyTexture(sp_tex);\n"
"    if (sp_ren) SDL_DestroyRenderer(sp_ren);\n"
"    if (sp_win) SDL_DestroyWindow(sp_win);\n"
"    SDL_Quit();\n"
"}\n"
"static void sp_g_backend_open(const char *title) {\n"
"    SDL_SetMainReady();\n"
"    if (SDL_Init(SDL_INIT_VIDEO) != 0) { fprintf(stderr, \"Runtime error: can't start graphics: %s\\n\", SDL_GetError()); exit(1); }\n"
"    sp_win = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, sp_gw, sp_gh, 0);\n"
"    if (sp_win) sp_ren = SDL_CreateRenderer(sp_win, -1, 0);\n"
"    if (sp_ren) sp_tex = SDL_CreateTexture(sp_ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, sp_gw, sp_gh);\n"
"    if (!sp_tex) { fprintf(stderr, \"Runtime error: can't open the window: %s\\n\", SDL_GetError()); exit(1); }\n"
"    atexit(sp_g_backend_close);\n"
"    sp_frame_start = SDL_GetTicks();\n"
"}\n"
"static void sp_g_backend_present(void) {\n"
"    SDL_UpdateTexture(sp_tex, NULL, sp_gpix, sp_gw * 4);\n"
"    SDL_RenderClear(sp_ren); SDL_RenderCopy(sp_ren, sp_tex, NULL, NULL); SDL_RenderPresent(sp_ren);\n"
"    SDL_Event ev;\n"
"    while (SDL_PollEvent(&ev)) if (ev.type == SDL_QUIT) sp_gquit = 1;\n"
"    int x, y; Uint32 b = SDL_GetMouseState(&x, &y);\n"
"    sp_gmx = x; sp_gmy = y; sp_gmdown = (b & SDL_BUTTON(1)) != 0;\n"
"    Uint32 used = SDL_GetTicks() - sp_frame_start;       /* keep to about 60 frames per second */\n"
"    if (used < 16) SDL_Delay(16 - used);\n"
"    sp_frame_start = SDL_GetTicks();\n"
"}\n"
"static int sp_g_key_down(const char *name) {\n"
"    sp_g_need();\n"
"    if (!strcmp(name, \"enter\")) name = \"Return\";\n"
"    if (!strcmp(name, \"esc\")) name = \"Escape\";\n"
"    SDL_Scancode sc = SDL_GetScancodeFromName(name);\n"
"    if (sc == SDL_SCANCODE_UNKNOWN) { fprintf(stderr, \"Runtime error: I don't know the key \\\"%s\\\". Try \\\"left\\\", \\\"right\\\", \\\"up\\\", \\\"down\\\", \\\"space\\\", \\\"enter\\\", \\\"a\\\"...\\\"z\\\".\\n\", name); exit(1); }\n"
"    return SDL_GetKeyboardState(NULL)[sc] != 0;\n"
"}\n"
"#else\n"
"/* ---- headless backend: no window; the last picture is saved as an image file ---- */\n"
"static void sp_g_save(void) {\n"
"    const char *path = getenv(\"SP_SNAPSHOT\");\n"
"    FILE *f = fopen(path ? path : \"sparks_frame.ppm\", \"wb\");\n"
"    if (!f) return;\n"
"    fprintf(f, \"P6\\n%d %d\\n255\\n\", sp_gw, sp_gh);\n"
"    for (int i = 0; i < sp_gw * sp_gh; i++) { unsigned c = sp_gpix[i]; fputc((c >> 16) & 255, f); fputc((c >> 8) & 255, f); fputc(c & 255, f); }\n"
"    fclose(f);\n"
"    fprintf(stderr, \"(headless mode: no window was opened; the last picture was saved to %s)\\n\", path ? path : \"sparks_frame.ppm\");\n"
"}\n"
"static void sp_g_backend_open(const char *title) { (void)title; atexit(sp_g_save); }\n"
"static void sp_g_backend_present(void) {\n"
"    const char *n = getenv(\"SP_FRAMES\");\n"
"    if (sp_gframes >= (n ? atoi(n) : 60)) sp_gquit = 1;\n"
"}\n"
"static int sp_g_key_down(const char *name) { (void)name; sp_g_need(); return 0; }\n"
"#endif\n"
"\n"
"static void sp_g_window(int w, int h, const char *title) {\n"
"    if (w < 1 || h < 1 || w > 4000 || h > 4000) { fputs(\"Runtime error: window size must be between 1 and 4000\\n\", stderr); exit(1); }\n"
"    if (sp_gpix) { fputs(\"Runtime error: the window is already open\\n\", stderr); exit(1); }\n"
"    sp_gw = w; sp_gh = h;\n"
"    sp_gpix = calloc((size_t)w * h, sizeof *sp_gpix);\n"
"    if (!sp_gpix) { fputs(\"Out of memory\\n\", stderr); exit(1); }\n"
"    sp_g_backend_open(title);\n"
"}\n"
"static void sp_g_show(void) {\n"
"    sp_g_need();\n"
"    sp_gframes++;\n"
"    sp_g_backend_present();\n"
"}\n"
"static int sp_g_is_open(void) { return sp_gpix != NULL && !sp_gquit; }\n"
"static int sp_g_mouse_x(void) { return sp_gmx; }\n"
"static int sp_g_mouse_y(void) { return sp_gmy; }\n"
"static int sp_g_mouse_down(void) { return sp_gmdown; }\n"
"static int sp_g_screen_w(void) { return sp_gw; }\n"
"static int sp_g_screen_h(void) { return sp_gh; }\n"
"\n";

static const char RUNTIME_INSTALL[] = "\n/* Small primitives for Sparks-native package managers. */\nstatic int sp_argc = 0;\nstatic char **sp_argv = NULL;\nstatic int sp_arg_count(void) { return sp_argc > 0 ? sp_argc - 1 : 0; }\nstatic const char *sp_arg_get(int index) {\n    return index >= 0 && index < sp_arg_count() ? sp_argv[index + 1] : \"\";\n}\n/* Installs a verified local regular file. Never runs package scripts. */\nstatic int sp_install_copy(const char *src, const char *dst) {\n    struct stat st;\n    if (stat(src, &st) || !S_ISREG(st.st_mode)) return -1;\n    int in = open(src, O_RDONLY);\n    if (in < 0) return -1;\n    int out = open(dst, O_WRONLY | O_CREAT | O_EXCL, st.st_mode & 0777);\n    if (out < 0) { close(in); return -1; }\n    char buf[8192]; ssize_t n; int ok = 0;\n    while ((n = read(in, buf, sizeof buf)) > 0) {\n        ssize_t off = 0;\n        while (off < n) {\n            ssize_t w = write(out, buf + off, (size_t)(n - off));\n            if (w <= 0) { ok = -1; break; }\n            off += w;\n        }\n        if (ok) break;\n    }\n    if (n < 0) ok = -1;\n    if (close(out)) ok = -1;\n    close(in);\n    if (ok) unlink(dst);\n    return ok;\n}\n/* HTTP/1.0 request, plain TCP only. Response includes headers. */\nstatic char *sp_http_request(const char *host, int port, const char *method, const char *path) {\n    if (strpbrk(host, \"\\r\\n\") || strpbrk(path, \"\\r\\n\") || strpbrk(method, \"\\r\\n\")) return sp_tmp_dup(\"\");\n    int fd = sp_net_connect(host, port);\n    if (fd < 0) return sp_tmp_dup(\"\");\n    size_t size = strlen(host) + strlen(method) + strlen(path) + 128;\n    char *req = malloc(size);\n    if (!req) { sp_net_close(fd); return sp_tmp_dup(\"\"); }\n    snprintf(req, size, \"%s %s HTTP/1.0\\r\\nHost: %s\\r\\nConnection: close\\r\\n\\r\\n\", method, path, host);\n    int sent = sp_net_send(fd, req); free(req);\n    if (sent < 0) { sp_net_close(fd); return sp_tmp_dup(\"\"); }\n    size_t cap = 8192, used = 0; char *result = malloc(cap);\n    if (!result) { sp_net_close(fd); return sp_tmp_dup(\"\"); }\n    char chunk[4096]; ssize_t n;\n    while ((n = recv(fd, chunk, sizeof chunk, 0)) > 0) {\n        if (used + (size_t)n > 16 * 1024 * 1024) break;\n        if (used + (size_t)n + 1 > cap) {\n            cap = (used + (size_t)n + 1) * 2;\n            char *next = realloc(result, cap);\n            if (!next) break;\n            result = next;\n        }\n        memcpy(result + used, chunk, (size_t)n); used += (size_t)n;\n    }\n    sp_net_close(fd); result[used] = 0;\n    char *ret = sp_tmp_dup(result); free(result); return ret;\n}\n";

static const char RUNTIME_NET[] =
"\n"
"/* POSIX/BSD socket API. Uses libc, not architecture-dependent syscall numbers. */\n"
"#ifndef _WIN32\n"
"#include <sys/socket.h>\n"
"#include <netinet/in.h>\n"
"#include <arpa/inet.h>\n"
"#include <netdb.h>\n"
"#include <sys/select.h>\n"
"#endif\n"
"static void sp_log_event(const char *message) {\n"
"    FILE *f = fopen(\"sparks-events.log\", \"a\");\n"
"    if (!f) return;\n"
"    time_t now = time(NULL);\n"
"    fprintf(f, \"%lld %s\\n\", (long long)now, message ? message : \"\");\n"
"    fclose(f);\n"
"}\n"
"static int sp_sys_errno(void) { return errno; }\n"
"static char *sp_sys_error(void) { return (char *)sp_tmp_dup(strerror(errno)); }\n"
"static int sp_net_connect(const char *host, int port) {\n"
"#ifdef _WIN32\n"
"    (void)host; (void)port; errno = ENOSYS; return -1;\n"
"#else\n"
"    if (port < 1 || port > 65535) { errno = EINVAL; return -1; }\n"
"    struct addrinfo hints = {0}, *res = NULL, *it;\n"
"    hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM;\n"
"    char service[16]; snprintf(service, sizeof service, \"%d\", port);\n"
"    int rc = getaddrinfo(host, service, &hints, &res);\n"
"    if (rc) { errno = EINVAL; sp_log_event(\"net_connect DNS failure\"); return -1; }\n"
"    int fd = -1;\n"
"    for (it = res; it; it = it->ai_next) {\n"
"        fd = socket(it->ai_family, it->ai_socktype, it->ai_protocol);\n"
"        if (fd < 0) continue;\n"
"        if (connect(fd, it->ai_addr, it->ai_addrlen) == 0) break;\n"
"        close(fd); fd = -1;\n"
"    }\n"
"    freeaddrinfo(res); sp_log_event(fd < 0 ? \"net_connect failed\" : \"net_connect success\"); return fd;\n"
"#endif\n"
"}\n"
"static int sp_net_listen(int port) {\n"
"#ifdef _WIN32\n"
"    (void)port; errno = ENOSYS; return -1;\n"
"#else\n"
"    if (port < 1 || port > 65535) { errno = EINVAL; return -1; }\n"
"    int fd = socket(AF_INET, SOCK_STREAM, 0); if (fd < 0) return -1;\n"
"    int yes = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);\n"
"    struct sockaddr_in addr = {0}; addr.sin_family = AF_INET;\n"
"    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK); addr.sin_port = htons((unsigned short)port);\n"
"    if (bind(fd, (struct sockaddr *)&addr, sizeof addr) || listen(fd, 16)) {\n"
"        int err = errno; close(fd); errno = err; sp_log_event(\"net_listen failed\"); return -1;\n"
"    }\n"
"    sp_log_event(\"net_listen success\"); return fd;\n"
"#endif\n"
"}\n"
"static int sp_net_accept(int fd) {\n"
"#ifdef _WIN32\n"
"    (void)fd; errno = ENOSYS; return -1;\n"
"#else\n"
"    int client = accept(fd, NULL, NULL);\n"
"    sp_log_event(client < 0 ? \"net_accept failed\" : \"net_accept success\"); return client;\n"
"#endif\n"
"}\n"
"static int sp_net_send(int fd, const char *data) {\n"
"#ifdef _WIN32\n"
"    (void)fd; (void)data; errno = ENOSYS; return -1;\n"
"#else\n"
"    size_t n = strlen(data), done = 0;\n"
"    while (done < n) {\n"
"        ssize_t k = send(fd, data + done, n - done, 0);\n"
"        if (k < 0 && errno == EINTR) continue;\n"
"        if (k <= 0) { sp_log_event(\"net_send failed\"); return -1; }\n"
"        done += (size_t)k;\n"
"    }\n"
"    sp_log_event(\"net_send success\"); return (int)done;\n"
"#endif\n"
"}\n"
"static char *sp_net_recv(int fd, int limit) {\n"
"    if (limit < 0 || limit > 1048576) { errno = EINVAL; return sp_dup(\"\"); }\n"
"    char *buf = sp_new((size_t)limit + 1);\n"
"#ifdef _WIN32\n"
"    (void)fd; errno = ENOSYS; buf[0] = 0;\n"
"#else\n"
"    ssize_t n;\n"
"    do { n = recv(fd, buf, (size_t)limit, 0); } while (n < 0 && errno == EINTR);\n"
"    if (n < 0) n = 0;\n"
"    buf[n] = 0;\n"
"#endif\n"
"    sp_log_event(\"net_recv\"); return buf;\n"
"}\n"
"static int sp_net_close(int fd) {\n"
"#ifdef _WIN32\n"
"    (void)fd; errno = ENOSYS; return -1;\n"
"#else\n"
"    int rc = close(fd); sp_log_event(\"net_close\"); return rc;\n"
"#endif\n"
"}\n"
"static int sp_hexval(char c) {\n"
"    if (c >= '0' && c <= '9') return c - '0';\n"
"    if (c >= 'a' && c <= 'f') return c - 'a' + 10;\n"
"    if (c >= 'A' && c <= 'F') return c - 'A' + 10;\n"
"    return -1;\n"
"}\n"
"static int sp_net_send_hex(int fd, const char *hex) {\n"
"#ifdef _WIN32\n"
"    (void)fd; (void)hex; errno = ENOSYS; return -1;\n"
"#else\n"
"    size_t n = strlen(hex); if (n % 2) { errno = EINVAL; return -1; }\n"
"    unsigned char *bytes = malloc(n / 2 + 1); if (!bytes) { errno = ENOMEM; return -1; }\n"
"    for (size_t i = 0; i < n; i += 2) {\n"
"        int a = sp_hexval(hex[i]), b = sp_hexval(hex[i+1]);\n"
"        if (a < 0 || b < 0) { free(bytes); errno = EINVAL; return -1; }\n"
"        bytes[i/2] = (unsigned char)(a * 16 + b);\n"
"    }\n"
"    size_t done = 0;\n"
"    while (done < n/2) {\n"
"        ssize_t k = send(fd, bytes + done, n/2 - done, 0);\n"
"        if (k < 0 && errno == EINTR) continue;\n"
"        if (k <= 0) { free(bytes); sp_log_event(\"net_send_hex failed\"); return -1; }\n"
"        done += (size_t)k;\n"
"    }\n"
"    free(bytes); sp_log_event(\"net_send_hex success\"); return (int)done;\n"
"#endif\n"
"}\n"
"static char *sp_net_recv_hex(int fd, int limit) {\n"
"    if (limit < 0 || limit > 1048576) { errno = EINVAL; return sp_dup(\"\"); }\n"
"    unsigned char *bytes = malloc((size_t)limit + 1); if (!bytes) sp_oom();\n"
"#ifdef _WIN32\n"
"    (void)fd; errno = ENOSYS; ssize_t n = 0;\n"
"#else\n"
"    ssize_t n;\n"
"    do { n = recv(fd, bytes, (size_t)limit, 0); } while (n < 0 && errno == EINTR);\n"
"    if (n < 0) n = 0;\n"
"#endif\n"
"    char *out = sp_new((size_t)n * 2 + 1);\n"
"    static const char h[] = \"0123456789abcdef\";\n"
"    for (ssize_t i = 0; i < n; i++) { out[i*2] = h[bytes[i] >> 4]; out[i*2+1] = h[bytes[i] & 15]; }\n"
"    out[n*2] = 0; free(bytes); sp_log_event(\"net_recv_hex\"); return out;\n"
"}\n"
"/* da operators use a filename or hex=filename; hex validates expected file bytes. */\n"
"static int sp_da_match(const char *spec) {\n"
"    const char *eq = strchr(spec, '='); const char *path = eq ? eq + 1 : spec;\n"
"    if (!*path) { errno = EINVAL; return 0; }\n"
"    FILE *f = fopen(path, \"rb\"); if (!f) return 0;\n"
"    if (!eq) { fclose(f); return 1; }\n"
"    size_t n = (size_t)(eq - spec);\n"
"    if (n % 2) { fclose(f); errno = EINVAL; return 0; }\n"
"    for (size_t i = 0; i < n; i += 2) {\n"
"        int a = sp_hexval(spec[i]), b = sp_hexval(spec[i+1]);\n"
"        int ch = fgetc(f);\n"
"        if (a < 0 || b < 0 || ch != a*16+b) { fclose(f); return 0; }\n"
"    }\n"
"    int eof = fgetc(f); fclose(f); return eof == EOF;\n"
"}\n"
"static bool sp_da_check(const char *spec) { int ok = sp_da_match(spec); sp_log_event(ok ? \"da? matched\" : \"da? failed\"); return ok != 0; }\n"
"static bool sp_da_delete(const char *spec) {\n"
"    if (!sp_da_match(spec)) { sp_log_event(\"da! refused: no match\"); return false; }\n"
"    const char *eq = strchr(spec, '='); const char *path = eq ? eq + 1 : spec;\n"
"    int ok = remove(path) == 0; sp_log_event(ok ? \"da! deleted\" : \"da! failed\"); return ok != 0;\n"
"}\n"
"static char *sp_da_incoming(const char *spec) {\n"
"    const char *eq = strchr(spec, '='); const char *path = eq ? eq + 1 : spec;\n"
"    FILE *f = fopen(path, \"rb\"); if (!f) { sp_log_event(\"da@ open failed\"); return sp_dup(\"\"); }\n"
"    char *buf = sp_new(1048577); size_t n = fread(buf, 1, 1048576, f);\n"
"    fclose(f);\n"
"    /* Return hexadecimal text so embedded zero bytes are preserved. */\n"
"    char *hex = sp_new(n * 2 + 1); static const char h[] = \"0123456789abcdef\";\n"
"    for (size_t i = 0; i < n; i++) { hex[2*i] = h[(unsigned char)buf[i] >> 4]; hex[2*i+1] = h[(unsigned char)buf[i] & 15]; }\n"
"    hex[2*n] = 0; sp_log_event(\"da@ inspected file\"); return hex;\n"
"}\n"
;

static const char RUNTIME_SYS[] =
"/* ---- syscalls: thin wrappers around the operating system's own calls ---- */\n"
"#include <errno.h>\n"
"#include <fcntl.h>\n"
"#ifdef _WIN32\n"
"#include <io.h>\n"
"#include <direct.h>\n"
"#include <process.h>\n"
"#define SP_WRITE _write\n"
"#define SP_READ _read\n"
"#define SP_OPEN _open\n"
"#define SP_CLOSE _close\n"
"#define SP_UNLINK _unlink\n"
"#define SP_GETCWD _getcwd\n"
"#define SP_CHDIR _chdir\n"
"#ifndef O_BINARY\n"
"#define O_BINARY 0x8000\n"
"#endif\n"
"#else\n"
"#include <unistd.h>\n"
"#include <sys/stat.h>\n"
"#include <sys/types.h>\n"
"#define SP_WRITE write\n"
"#define SP_READ read\n"
"#define SP_OPEN open\n"
"#define SP_CLOSE close\n"
"#define SP_UNLINK unlink\n"
"#define SP_GETCWD getcwd\n"
"#define SP_CHDIR chdir\n"
"#ifndef O_BINARY\n"
"#define O_BINARY 0\n"
"#endif\n"
"#endif\n"
"static int sp_sys_getpid(void) {\n"
"#ifdef _WIN32\n"
"    return _getpid();\n"
"#else\n"
"    return (int)getpid();\n"
"#endif\n"
"}\n"
"static int sp_sys_getuid(void) {\n"
"#ifdef _WIN32\n"
"    return 0;\n"
"#else\n"
"    return (int)getuid();\n"
"#endif\n"
"}\n"
"static int sp_sys_time(void) { return (int)time(NULL); }\n"
"static const char *sp_sys_getenv(const char *name) { const char *v = getenv(name); return v ? v : \"\"; }\n"
"static const char *sp_sys_getcwd(void) {\n"
"    char *p = sp_new(4096);\n"
"    if (!SP_GETCWD(p, 4096)) p[0] = 0;\n"
"    return p;\n"
"}\n"
"static int sp_sys_chdir(const char *path) { return SP_CHDIR(path); }\n"
"static int sp_sys_open(const char *path, const char *mode) {\n"
"    int flags;\n"
"    if (!strcmp(mode, \"r\")) flags = O_RDONLY;\n"
"    else if (!strcmp(mode, \"w\")) flags = O_WRONLY | O_CREAT | O_TRUNC;\n"
"    else if (!strcmp(mode, \"a\")) flags = O_WRONLY | O_CREAT | O_APPEND;\n"
"    else if (!strcmp(mode, \"rw\")) flags = O_RDWR | O_CREAT;\n"
"    else { fprintf(stderr, \"Runtime error: open() mode must be \\\"r\\\", \\\"w\\\", \\\"a\\\" or \\\"rw\\\", not \\\"%s\\\"\\n\", mode); exit(1); }\n"
"    return SP_OPEN(path, flags | O_BINARY, 0644);\n"
"}\n"
"static int sp_sys_close(int fd) { return SP_CLOSE(fd); }\n"
"static int sp_sys_write(int fd, const char *text) {\n"
"    if (fd == 1) fflush(stdout);\n"
"    if (fd == 2) fflush(stderr);\n"
"    return (int)SP_WRITE(fd, text, (unsigned)strlen(text));\n"
"}\n"
"static const char *sp_sys_read(int fd, int max) {\n"
"    if (max < 1) max = 1;\n"
"    if (max > (1 << 20)) max = 1 << 20;\n"
"    char *p = sp_new((size_t)max + 1);\n"
"    int r = (int)SP_READ(fd, p, (unsigned)max);\n"
"    if (r < 0) r = 0;\n"
"    p[r] = 0;\n"
"    return p;\n"
"}\n"
"static int sp_sys_unlink(const char *path) { return SP_UNLINK(path); }\n"
"static int sp_sys_mkdir(const char *path) {\n"
"#ifdef _WIN32\n"
"    return _mkdir(path);\n"
"#else\n"
"    return mkdir(path, 0755);\n"
"#endif\n"
"}\n"
"static int sp_sys_system(const char *cmd) { fflush(stdout); return system(cmd); }\n"
"static void sp_sys_exit(int code) { fflush(stdout); exit(code); }\n"
"\n";
static void build_c(Buf *out, const char *src_path) {
    buf_printf(out, "/* Generated by spc %s from %s.\n * This is the C code your Sparks program turned into. Have a look around!\n */\n", VERSION, src_path);
    buf_add(out, RUNTIME);
    if (mod_on[M_GFX]) buf_add(out, RUNTIME_GFX);
    if (mod_on[M_SYS]) { buf_add(out, RUNTIME_SYS); buf_add(out, RUNTIME_NET); buf_add(out, RUNTIME_INSTALL); }
    buf_add(out, "/* ---- your structs ---- */\n");
    buf_add(out, BS(out_structs));
    buf_add(out, "/* ---- function prototypes ---- */\nstatic void sp_free_globals(void);\n");
    buf_add(out, BS(out_protos));
    buf_add(out, "\n/* ---- your global variables ---- */\n");
    buf_add(out, BS(out_globals));
    buf_add(out, "\n/* ---- your functions ---- */\n");
    buf_add(out, BS(out_funcs));
    buf_add(out, "/* ---- program start: set the global variables, then run main ---- */\n");
    buf_printf(out, "static void sp_init_globals(void) {\n%s}\n\n", BS(g_init));
    buf_printf(out, "static void sp_free_globals(void) {\n%s}\n\n", BS(g_free));
    buf_add(out, "int main(int argc, char **argv) {\n    sp_rt_init();\n    /* arguments are available to imported syscalls programs */\n" );
    if (mod_on[M_SYS]) buf_add(out, "    sp_argc = argc; sp_argv = argv;\n");
    buf_add(out, "    sp_init_globals();\n    f_main();\n    sp_free_globals();\n    sp_tmp_release(0);\n    return 0;\n}\n");

}

/* =============================================================================
 *  7. THE DRIVER  (reads the command line and runs the 5 stages)
 * ============================================================================= */

/* Compiler flags that make the finished program small (-Os, strip symbols, drop unused code).
 * `--fast` uses -O2 instead (a little bigger, a little faster). */
#if defined(__APPLE__)
#define SIZE_FLAGS "-Os -Wl,-dead_strip -Wl,-x"
#elif defined(_WIN32)
#define SIZE_FLAGS "-Os -s -ffunction-sections -fdata-sections -Wl,--gc-sections"
#else
#define SIZE_FLAGS "-Os -s -ffunction-sections -fdata-sections -Wl,--gc-sections -fno-asynchronous-unwind-tables -fno-ident -Wl,--build-id=none"
#endif
static int opt_log = 0;
static int opt_fast = 0;
static const char *opt_out = NULL;
static int opt_run = 0, opt_ast = 0, opt_emit_c = 0, opt_keep = 0, opt_verbose = 0, opt_headless = 0;

static void usage(void) {
    puts("spc " VERSION " - the Sparks compiler\n\n"
         "Usage: spc <file.sp> [options]\n\n"
         "  --pack-firmware <raw.bin> --target <cpu-board> -o <image.bin> [--max-size <bytes>] [--n]\n"
         "                 package raw firmware (ELF only with --tu); never flashes\n"
         "  --img --boot    compile spasm asm/hex into an x86 BIOS disk image\n"
         "  --img-size 32M  set disk image size\n"
         "  --img-unlimited  auto-size image to contents (sector aligned)\n"
         "  --img-append FILE  append raw data after stage 2, sector aligned\n"
         "  li[0x90, ...]  literal bytes in --img programs (inside or outside spasm)\n"
         "  --n            skip optional firmware preflight; structural/file checks remain\n"
         "  -o <name>     name of the program to make (default: the file name without .sp)\n"
         "  -r, --run     compile, then run the program straight away\n"
         "  -v            explain each compiler stage as it happens\n"
         "  --L           save a detailed .txt audit and display it when finished\n"
         "  --tokens      show the lexer's tokens, then stop\n"
         "  --ast         show the parser's syntax tree, then stop\n"
         "  --emit-c      print the generated C code, then stop\n"
         "  --fast        optimise for speed instead of size (default: smallest program)\n"
         "  --headless    graphics without a window: saves the last picture as sparks_frame.ppm\n"
         "  -k, --keep-c  keep the generated C file next to the program\n"
         "  -h, --help    show this help\n\n"
         "spc needs a C compiler (cc, gcc or clang). Set SPC_CC to choose another.");
}

/* POSIX hardened process launcher: no shell expansion of source/output names. */
#ifndef _WIN32
static int launch(const char *exe, char *const argv[]) {
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) { execvp(exe, argv); _exit(127); }
    int st;
    while (waitpid(pid, &st, 0) < 0) { if (errno == EINTR) continue; return -1; }
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}
static int split_flags(char *s, char **args, int cap) {
    int n = 0;
    char *saveptr = NULL;
    for (char *p = strtok_r(s, " \t\r\n", &saveptr); p; p = strtok_r(NULL, " \t\r\n", &saveptr)) {
        if (n >= cap) return -1;
        /* Do not interpret shell syntax, substitutions, or quoted arguments. */
        if (strpbrk(p, "'\"`$\\")) return -1;
        args[n++] = p;
    }
    return n;
}
static char *capture_argv(const char *exe, const char *a, const char *b, const char *c) {
    int fds[2]; if (pipe(fds)) return NULL;
    pid_t pid = fork();
    if (pid < 0) { close(fds[0]); close(fds[1]); return NULL; }
    if (pid == 0) {
        close(fds[0]); dup2(fds[1], STDOUT_FILENO); close(fds[1]);
        int devnull = open("/dev/null", O_WRONLY);
        if (devnull >= 0) { dup2(devnull, STDERR_FILENO); close(devnull); }
        char *av[] = {(char *)exe, (char *)a, (char *)b, (char *)c, NULL};
        execvp(exe, av); _exit(127);
    }
    close(fds[1]); char out[1500]; ssize_t n = read(fds[0], out, sizeof(out)-1);
    close(fds[0]); int st;
    while (waitpid(pid, &st, 0) < 0) { if (errno == EINTR) continue; return NULL; }
    if (n <= 0 || !WIFEXITED(st) || WEXITSTATUS(st)) return NULL;
    out[n] = 0;
    for (char *q=out; *q; q++) if (*q=='\n' || *q=='\r') *q=' ';
    return xstrdup(out);
}
#else
static char *capture_argv(const char *exe, const char *a, const char *b, const char *c) { (void)exe; (void)a; (void)b; (void)c; return NULL; }
#endif
static const char *find_cc(void) {
    const char *env = getenv("SPC_CC");
    const char *cands[] = { env && *env ? env : "cc", "cc", "gcc", "clang" };
    for (int i = 0; i < 4; i++) {
#ifndef _WIN32
        char *av[] = {(char *)cands[i], "--version", NULL};
        int fd = open(NULL_DEV, O_WRONLY);
        pid_t pid = fork();
        if (pid < 0) { if (fd >= 0) close(fd); continue; }
        if (pid == 0) {
            if (fd >= 0) { dup2(fd, STDOUT_FILENO); dup2(fd, STDERR_FILENO); close(fd); }
            execvp(cands[i], av); _exit(127);
        }
        if (fd >= 0) close(fd);
        int st; if (waitpid(pid, &st, 0) > 0 && WIFEXITED(st) && WEXITSTATUS(st) == 0) return cands[i];
#else
        if (strpbrk(cands[i], " \"'&|;`$")) continue;
        char cmd[300]; snprintf(cmd, sizeof cmd, "%s --version > %s 2>&1", cands[i], NULL_DEV);
        if (system(cmd) == 0) return cands[i];
#endif
    }
    return NULL;
}

static void stage(int n, const char *fmt, ...) {
    if (!opt_verbose) return;
    va_list ap; va_start(ap, fmt);
    printf("[%d/5] ", n); vprintf(fmt, ap); printf("\n");
    va_end(ap);
}

static void fail_if_errors(void) {
    if (n_errors == 0) return;
    fprintf(stderr, "Found %d error%s. No program was made - fix %s and try again.\n",
            n_errors, n_errors == 1 ? "" : "s", n_errors == 1 ? "it" : "them");
    exit(1);
}

/* Firmware packaging: never writes to devices or executes firmware. */
static unsigned fw_crc32(const unsigned char *p, size_t n) {
    unsigned c = 0xffffffffu;
    for (size_t i=0;i<n;i++) { c ^= p[i]; for(int j=0;j<8;j++) c=(c>>1)^((0u-(c&1u))&0xedb88320u); }
    return ~c;
}
static unsigned long long fw_u(const unsigned char *p, int n, int little) {
    unsigned long long v=0;
    for(int i=0;i<n;i++) { int k=little ? n-1-i : i; v=(v<<8)|p[k]; }
    return v;
}
/* Validate ELF container boundaries, not trustworthiness or boot compatibility. */
static int fw_valid_elf(const unsigned char *d, size_t n) {
    if(n<52 || memcmp(d,"\177ELF",4) || (d[4]!=1 && d[4]!=2) ||
       (d[5]!=1 && d[5]!=2) || d[6]!=1) return 0;
    int bits=d[4],le=d[5]==1;
    size_t eh=bits==1?52:64, phmin=bits==1?32:56;
    if(n<eh) return 0;
    unsigned long long type=fw_u(d+16,2,le);
    if(type!=2 && type!=3) return 0; /* ET_EXEC / ET_DYN */
    unsigned long long ehsz=fw_u(d+(bits==1?40:52),2,le);
    unsigned long long pho=fw_u(d+(bits==1?28:32),bits==1?4:8,le);
    unsigned long long phsz=fw_u(d+(bits==1?42:54),2,le);
    unsigned long long phnum=fw_u(d+(bits==1?44:56),2,le);
    if(ehsz!=eh || phsz<phmin || phnum==0 || phnum==65535 || pho>n ||
       phnum>(n-pho)/phsz) return 0;
    int load=0;
    for(unsigned long long i=0;i<phnum;i++) {
        const unsigned char *h=d+pho+i*phsz;
        unsigned long long t=fw_u(h,4,le);
        if(t==1) {
            unsigned long long off=fw_u(h+(bits==1?4:8),bits==1?4:8,le);
            unsigned long long sz=fw_u(h+(bits==1?16:32),bits==1?4:8,le);
            unsigned long long mem=fw_u(h+(bits==1?20:40),bits==1?4:8,le);
            if(off>n || sz>n-off || sz>mem) return 0;
            load=1;
        }
    }
    return load;
}
/* Conservative payload screening: byte patterns are indicators, not proof of behavior. */
static int fw_screen(const unsigned char *d, size_t n, int tux) {
    size_t zero=0, ff=0;
    for(size_t i=0;i<n;i++) { zero += d[i]==0; ff += d[i]==255; }
    fprintf(stderr,"spc: firmware preflight: %zu bytes, %s format\n",n,tux?"ELF":"raw");
    if(!tux) {
        if(n<16) { fprintf(stderr,"spc: safety: raw payload too short to assess (minimum 16 bytes)\n"); return 0; }
        if(zero==n || ff==n) { fprintf(stderr,"spc: safety: payload is entirely padding bytes\n"); return 0; }
        if(n>=512 && d[510]==0x55 && d[511]==0xAA)
            fprintf(stderr,"spc: preflight: legacy boot-sector signature detected (not proof of bootability)\n");
        else fprintf(stderr,"spc: preflight: no legacy boot-sector signature; target-specific boot format not verified\n");
    }
    fprintf(stderr,"spc: preflight: instruction effects, device writes, and corruption risk CANNOT be verified from this payload alone\n");
    return 1;
}
static int firmware_pack(const char *in, const char *out, const char *target, size_t limit, int tux, int skip_screen) {
#ifndef _WIN32
    if (!in || !out || !target || !*target || strlen(target)>80 || !strcmp(in,out)) { fprintf(stderr,"spc: firmware requires input, distinct output, and target\n"); return 2; }
    for(const char *p=target;*p;p++) if(!isalnum((unsigned char)*p) && *p!='-' && *p!='_' && *p!='.') { fprintf(stderr,"spc: invalid target\n");return 2; }
    if (out[0]=='/' && (!strncmp(out,"/dev/",5) || !strncmp(out,"/sys/",5) || !strncmp(out,"/proc/",6))) { fprintf(stderr,"spc: refusing device/system output\n");return 2; }
    struct stat st;
    if (lstat(in,&st) || !S_ISREG(st.st_mode) || st.st_size<=0 || (unsigned long long)st.st_size>limit) { fprintf(stderr,"spc: input must be a nonempty regular file within size limit\n");return 2; }
    if (!lstat(out,&st)) { fprintf(stderr,"spc: output already exists; refusing overwrite\n");return 2; }
    if (errno!=ENOENT) { perror("spc: output check");return 2; }
    int fd=open(in,O_RDONLY|O_NOFOLLOW|O_CLOEXEC); if(fd<0){perror("spc: input");return 2;}
    if(fstat(fd,&st) || !S_ISREG(st.st_mode) || st.st_size<=0 || (unsigned long long)st.st_size>limit) {close(fd);return 2;}
    size_t len=(size_t)st.st_size; unsigned char *data=malloc(len); if(!data){close(fd);return 2;}
    size_t got=0;while(got<len){ssize_t r=read(fd,data+got,len-got);if(r<0 && errno==EINTR)continue;if(r<=0)break;got+=(size_t)r;} close(fd);
    if(got!=len){fprintf(stderr,"spc: incomplete firmware input\n");free(data);return 2;}
    if(len>=4 && !memcmp(data,"\177ELF",4)) {
        if(!tux) {fprintf(stderr,"spc: ELF requires explicit --tu (Tux/distro mode)\n");free(data);return 2;}
        if(!fw_valid_elf(data,len)) {fprintf(stderr,"spc: malformed or unsupported ELF executable\n");free(data);return 2;}
    } else if(len>=2 && !memcmp(data,"MZ",2)) {
        fprintf(stderr,"spc: PE executables are not supported\n");free(data);return 2;
    } else if(tux) {
        fprintf(stderr,"spc: --tu requires an ELF executable\n");free(data);return 2;
    }
    if(!skip_screen && !fw_screen(data,len,tux)) { free(data); return 2; }
    if(skip_screen) fprintf(stderr,"spc: WARNING: --n bypassed optional firmware preflight (format and file safety checks remain)\n");
    unsigned crc=fw_crc32(data,len);
    int ofd=open(out,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    if(ofd<0){perror("spc: firmware output");free(data);return 2;}
    size_t sent=0;int bad=0;while(sent<len){ssize_t w=write(ofd,data+sent,len-sent);if(w<0&&errno==EINTR)continue;if(w<=0){bad=1;break;}sent+=(size_t)w;}
    if(fsync(ofd))bad=1;if(close(ofd))bad=1;
    if(bad){unlink(out);fprintf(stderr,"spc: firmware output write failed\n");free(data);return 2;}
    char manifest[1300];if(snprintf(manifest,sizeof manifest,"%s.manifest.txt",out)>=(int)sizeof manifest){unlink(out);free(data);return 2;}
    int mfd=open(manifest,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
    if(mfd<0){unlink(out);perror("spc: manifest");free(data);return 2;}
    char content[512];int cn=snprintf(content,sizeof content,"SPC firmware payload manifest v1\ntarget=%s\nsize=%zu\ncrc32=%08X\nformat=%s\nauto_flash=no\nverified_boot=no\n",target,len,crc,tux?"elf":"raw");
    int mw=write(mfd,content,(size_t)cn)==cn; if(fsync(mfd))mw=0;if(close(mfd))mw=0;
    if(!mw){unlink(manifest);unlink(out);free(data);return 2;}
    printf("Firmware image created: %s (%zu bytes, CRC32 %08X)\nManifest: %s\nNo flashing performed.\n",out,len,crc,manifest);
    free(data);return 0;
#else
    (void)in;(void)out;(void)target;(void)limit;(void)tux;(void)skip_screen;
    fprintf(stderr,"spc: firmware pack currently requires POSIX\n");return 2;
#endif
}


/* Scurs waving Easter egg: frames from scurs.txt. */
static const char *const scurs_frame_0[] = {
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                     ///       \n",
    "                  :+           ..    ***         \n",
    "                 -*#+:       :=*-    ***          \n",
    "                -#%%###*+++*##%%=              \n",
    "          ..:-=#%%%%%%%###%%%%%%#-             \n",
    "          .-#%%%%%%%%%%%%%%%%%%%%#*:           \n",
    "            +#%%%%%%%%%%%%%%%%%%%%###+=-:      \n",
    "              #%%%%%%%*#%%%%%%%%%%%%%##*:      \n",
    "              #%%%%%%+%%%=%#+%%+%%%%%%+        \n",
    "              *%%%%%%+---#%%=+++%%%%%*+        \n",
    "              #%%%%%%%@@@@@@@@%%%%%%%*         \n",
    "             +#@@@@@@@@@@@@@@@%%%%%%%+.        \n",
    "            :*%%%%@@@@@@@@@@@@@%%%%%%*:        \n",
    "                  %%@@@@@@@@@@@@%%%%%%=        \n",
    "                   #%@@@@@@@@@@@%##  =-:       \n",
    "                    %@@@@@@@@@@%#              \n",
    "                    %%%%    %%%#+              \n",
    "                   =#          =-              \n",
    "                                               \n",
};
static const char *const scurs_frame_1[] = {
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                               \n",
    "                                        \\\\\\       \n",
    "                  :+           ..       ***       \n",
    "                 -*#+:       :=*-       ***      \n",
    "                -#%%###*+++*##%%=              \n",
    "          ..:-=#%%%%%%%###%%%%%%#-             \n",
    "          .-#%%%%%%%%%%%%%%%%%%%%#*:           \n",
    "            +#%%%%%%%%%%%%%%%%%%%%###+=-:      \n",
    "              #%%%%%%%*#%%%%%%%%%%%%%##*:      \n",
    "              #%%%%%%+%%%=%#+%%+%%%%%%+        \n",
    "              *%%%%%%+---#%%=+++%%%%%*+        \n",
    "              #%%%%%%%@@@@@@@@%%%%%%%*         \n",
    "             +#@@@@@@@@@@@@@@@%%%%%%%+.        \n",
    "            :*%%%%@@@@@@@@@@@@@%%%%%%*:        \n",
    "                  %%@@@@@@@@@@@@%%%%%%=        \n",
    "                   #%@@@@@@@@@@@%##  =-:       \n",
    "                    %@@@@@@@@@@%#              \n",
    "                    %%%%    %%%#+              \n",
    "                   =#          =-              \n",
    "                                               \n",
};
static void scurs_pause(void) {
#ifndef _WIN32
    struct timespec ts = {0, 220000000L};
    while (nanosleep(&ts, &ts) != 0 && errno == EINTR) {}
#else
    Sleep(220);
#endif
}
static int scurs_wave(void) {
    const char *const *frames[] = {scurs_frame_0, scurs_frame_1};
    const size_t counts[] = {sizeof(scurs_frame_0)/sizeof(scurs_frame_0[0]), sizeof(scurs_frame_1)/sizeof(scurs_frame_1[0])};
    int tty = ISATTY(1);
    if (tty) fputs("\033[?25l", stdout);
    for (int i = 0; i < (tty ? 8 : 2); ++i) {
        int f = i % 2;
        if (tty) fputs("\033[H\033[2J", stdout);
        for (size_t j = 0; j < counts[f]; ++j) fputs(frames[f][j], stdout);
        fflush(stdout);
        if (tty) scurs_pause();
    }
    if (tty) fputs("\033[?25h", stdout);
    fflush(stdout);
    return 0;
}


/* Experimental x86 BIOS image backend: translates top-level spasm asm strings
 * into GNU as 16-bit assembly. It never writes to block devices. */
#ifndef _WIN32
static int run_child(const char *program, char *const args[]) {
    pid_t pid=fork(); if(pid<0){perror("fork");return -1;}
    if(pid==0){execvp(program,args);perror(program);_exit(127);}
    int status=0; if(waitpid(pid,&status,0)<0)return -1;
    return WIFEXITED(status)?WEXITSTATUS(status):-1;
}
static int build_bios_img(const char *input,const char *output, unsigned long long image_size, int unlimited, const char *append) {
    FILE *in=fopen(input,"rb"); if(!in){perror(input);return 2;}
    char stem[]="/tmp/spc-img-XXXXXX";
    int fd=mkstemp(stem);if(fd<0){perror("mkstemp");fclose(in);return 2;}
    FILE *out=fdopen(fd,"w");if(!out){close(fd);unlink(stem);fclose(in);return 2;}
    fprintf(out,".intel_syntax noprefix\n.code16\n.global _start\n_start:\n");
    /* Generic SPASM string reader: recognize escaped delimiters correctly.
       Do not treat a quote preceded by a backslash as the end of a string. */
    char *line=NULL; size_t cap=0; ssize_t n;
    int inside=0, lines=0, failed=0, lineno=0;
    size_t block_indent=0;
    while((n=getline(&line,&cap,in))!=-1){
        lineno++;
        char *q=line;
        while(*q==' '||*q=='\t')q++;
        size_t indent=(size_t)(q-line);
        if(*q=='\n'||*q=='\r'||*q=='#')continue;
        if(inside && indent<=block_indent)inside=0;
        if(!inside && !strncmp(q,"li[",3))inside=2;
        if(!inside){
            if(!strncmp(q,"spasm",5) && (q[5]=='\n'||q[5]=='\r'||q[5]==' '||q[5]=='\t')){
                inside=1;block_indent=indent;
            }
            continue;
        }
        /* li[...] emits exact bytes at the current location.  Works both
         * inside and outside spasm blocks, with no application-specific code. */
        if(!strncmp(q,"li[",3)){
            const char *v=q+3; int count=0;
            while(1){
                while(*v==' '||*v=='\t')v++;
                if(*v==']'){v++;break;}
                if(!*v||*v=='\n'||*v=='\r'){failed=1;break;}
                char *end=NULL;errno=0;
                unsigned long value=strtoul(v,&end,0);
                if(errno||end==v||value>255){failed=1;break;}
                fprintf(out,".byte 0x%02lx\n",value);count++;
                v=end;
                while(*v==' '||*v=='\t')v++;
                if(*v==','){v++;continue;}
                if(*v==']'){v++;break;}
                failed=1;break;
            }
            while(*v==' '||*v=='\t')v++;
            if(*v&&*v!='\r'&&*v!='\n'&&*v!='#')failed=1;
            if(!count)failed=1;
            if(failed){fprintf(stderr,"%s:%d: invalid li bytes (expected li[0x90, 0x00, ...])\n",input,lineno);break;}
            lines++;if(inside==2)inside=0;continue;
        }
        int is_asm=0;
        if(!strncmp(q,"asm",3) && (q[3]==' '||q[3]=='\t')){q+=3;is_asm=1;}
        else if(!strncmp(q,"hex",3) && (q[3]==' '||q[3]=='\t')){q+=3;}
        else {fprintf(stderr,"%s:%d: expected asm or hex inside spasm\n",input,lineno);failed=1;break;}
        while(*q==' '||*q=='\t')q++;
        if(*q!='"'){fprintf(stderr,"%s:%d: expected quoted string\n",input,lineno);failed=1;break;}
        q++;
        size_t decoded_cap=(size_t)n+1, used=0;
        char *decoded=malloc(decoded_cap);
        if(!decoded){perror("malloc");failed=1;break;}
        int closed=0;
        while(*q && *q!='\n' && *q!='\r'){
            if(*q=='"'){q++;closed=1;break;}
            if(*q=='\\'){
                q++;
                if(*q=='"'||*q=='\\')decoded[used++]=*q++;
                else if(*q=='n'){decoded[used++]='\n';q++;}
                else if(*q=='t'){decoded[used++]='\t';q++;}
                else {fprintf(stderr,"%s:%d: unsupported string escape\n",input,lineno);failed=1;break;}
            } else decoded[used++]=*q++;
        }
        decoded[used]=0;
        while(*q==' '||*q=='\t')q++;
        if(!closed || (*q && *q!='\r' && *q!='\n' && *q!='#'))failed=1;
        if(!failed){
            if(is_asm){
                /* Assembly may contain its own quoted strings, including .asciz. */
                if(memchr(decoded,'\n',used)||memchr(decoded,'\r',used)){
                    fprintf(stderr,"%s:%d: assembly must be one line\n",input,lineno);failed=1;
                }else{fprintf(out,"%s\n",decoded);lines++;}
            }else{
                size_t i=0;
                while(i<used){
                    while(i<used && (decoded[i]==' '||decoded[i]=='\t'))i++;
                    if(i==used)break;
                    if(i+1>=used||!isxdigit((unsigned char)decoded[i])||!isxdigit((unsigned char)decoded[i+1])){failed=1;break;}
                    fprintf(out,".byte 0x%c%c\n",decoded[i],decoded[i+1]);i+=2;
                    if(i<used && decoded[i]!=' ' && decoded[i]!='\t'){failed=1;break;}
                }
                lines++;
            }
        }
        free(decoded);
        if(failed){fprintf(stderr,"%s:%d: invalid spasm string or hex bytes\n",input,lineno);break;}
    }
    free(line);fclose(in);if(fclose(out))failed=1;
    if(failed||!lines){fprintf(stderr,"spc --img: expected valid spasm asm/hex lines\n");unlink(stem);return 2;}
    char obj[256],payload[256],loader[256],loaderobj[256],loaderbin[256];
    snprintf(obj,sizeof obj,"%s.o",stem);
    snprintf(payload,sizeof payload,"%s.payload",stem);
    snprintf(loader,sizeof loader,"%s.loader",stem);
    snprintf(loaderobj,sizeof loaderobj,"%s.loader.o",stem);
    snprintf(loaderbin,sizeof loaderbin,"%s.loader.bin",stem);
    char *asargs[]={"as","--32","-o",obj,stem,NULL};
    int rc=run_child("as",asargs);
    if(!rc){char *args[]={"ld","-m","elf_i386","--oformat","binary","-Ttext","0x7e00","-e","_start","-o",payload,obj,NULL};rc=run_child("ld",args);}
    struct stat st;
    if(!rc && (stat(payload,&st)||st.st_size<=0||st.st_size>8192)){
        fprintf(stderr,"spc --img: payload must be 1..8192 bytes (16 floppy sectors)\n");rc=2;
    }
    if(!rc){
        FILE *f=fopen(loader,"w");if(!f){perror("loader");rc=2;}else{
            fputs(".intel_syntax noprefix\n.code16\n.global _start\n_start:\n"
                  "cli\nxor ax,ax\nmov ds,ax\nmov es,ax\nmov ss,ax\nmov sp,0x7c00\nsti\n"
                  "mov [drive],dl\nmov si,3\nretry:\nmov ah,2\nmov al,16\n"
                  "xor ch,ch\nmov cl,2\nxor dh,dh\nmov dl,[drive]\nmov bx,0x7e00\n"
                  "int 0x13\njnc loaded\nxor ah,ah\nmov dl,[drive]\nint 0x13\n"
                  "dec si\njnz retry\nfail:\ncli\nhlt\njmp fail\n"
                  "loaded:\njmp 0x0000:0x7e00\ndrive: .byte 0\n"
                  ".org 510\n.word 0xaa55\n",f);
            if(fclose(f))rc=2;
        }
    }
    if(!rc){char *args[]={"as","--32","-o",loaderobj,loader,NULL};rc=run_child("as",args);}
    if(!rc){char *args[]={"ld","-m","elf_i386","--oformat","binary","-Ttext","0x7c00","-e","_start","-o",loaderbin,loaderobj,NULL};rc=run_child("ld",args);}
    if(!rc){
        struct stat dstst;
        if(!stat(output,&dstst) && !S_ISREG(dstst.st_mode)){
            fprintf(stderr,"spc --img: output must be a regular file\n");rc=2;
        }
    }
    if(!rc){
        FILE *o=fopen(output,"wb"),*b=fopen(loaderbin,"rb"),*p=fopen(payload,"rb");
        FILE *extra=append?fopen(append,"rb"):NULL;
        if(!o||!b||!p||(append&&!extra)){perror("spc --img files");rc=2;}
        else{
            unsigned char buf[65536];size_t k;
            unsigned long long total=0;
            while((k=fread(buf,1,sizeof buf,b))>0){if(fwrite(buf,1,k,o)!=k){rc=2;break;}total+=k;}
            if(total!=512)rc=2;
            while(!rc&&(k=fread(buf,1,sizeof buf,p))>0){if(fwrite(buf,1,k,o)!=k){rc=2;break;}total+=k;}
            /* Raw disk payload starts at the next sector boundary. */
            if(!rc&&extra){
                unsigned char zero[512]={0};
                size_t pad=(512-(size_t)(total%512))%512;
                if(pad&&fwrite(zero,1,pad,o)!=pad)rc=2;
                total+=pad;
                while(!rc&&(k=fread(buf,1,sizeof buf,extra))>0){
                    if(fwrite(buf,1,k,o)!=k){rc=2;break;}total+=k;
                }
                if(ferror(extra))rc=2;
            }
            if(!unlimited){
                if(image_size<total){fprintf(stderr,"spc --img: image-size smaller than payload\n");rc=2;}
                else if(image_size>(unsigned long long)INT64_MAX){rc=2;}
                else if(!rc){
                    if(fflush(o)||ftruncate(fileno(o),(off_t)image_size))rc=2;
                }
            }else{
                unsigned long long rounded=(total+511ULL)&~511ULL;
                if(rounded>(unsigned long long)INT64_MAX||fflush(o)||ftruncate(fileno(o),(off_t)rounded))rc=2;
            }
        }
        if(extra)fclose(extra);
        if(b)fclose(b);if(p)fclose(p);if(o&&fclose(o))rc=2;
    }
    unlink(stem);unlink(obj);unlink(payload);unlink(loader);unlink(loaderobj);unlink(loaderbin);
    if(rc){unlink(output);fprintf(stderr,"spc --img: failed to generate BIOS image\n");return 2;}
    printf("spc: wrote BIOS disk image %s (16-sector stage-2 loader)\n",output);return 0;
}
#endif

int main(int argc, char **argv) {
    if (argc == 2 && !strcmp(argv[1], "hi")) return scurs_wave();
    if (argc == 2 && !strcmp(argv[1], "jaksxr")) {
    puts("@@@@@@@@@@@@@@@@@@@@@@@@@               @@@@@@@@@@@@@@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@@@@@@@@@                         @@@@@@@@@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@@@@@@                               @@@@@@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@@@                                     @@@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@  @                                      @@@@@@@@@@@@");
    puts("@@@@@@@@@@    *@@@@                                    @@@@@@@@@@");
    puts("@@@@@@@@@       @@@@@@      @@@@     +@@       @@@      @@@@@@@@@");
    puts("@@@@@@@          @@@@@@@  @@@@@@  @@@@@@    @@@@@@@       @@@@@@@");
    puts("@@@@@@           @@@@@@@@@@@@@@@@@@@@@@@@ @@@@@@@@@        @@@@@@");
    puts("@@@@@         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@@");
    puts("@@@@        @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@");
    puts("@@@@      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@");
    puts("@@@     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@          @@@");
    puts("@@@   @@@@@@@@@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@         @@@");
    puts("@@@           @@@@@@@@@@@@@@@@        @@@@@@@@@@@@@@@         @@@");
    puts("@@              @@@@@@@@@    @        @@@@@@@@@@@@@@@         =@@");
    puts("@@             @@@@@@@@@-               @@@@@@@@@@@@@          @@");
    puts("@@:           @@@@@@@@@                   @@@@@@@@*           @@@");
    puts("@@@          @@@@ @@@@@=    @     ::      @@@@@@@@@@@         @@@");
    puts("@@@         @@@@  @@@@@+                  @@@@@@@@@@@@@@      @@@");
    puts("@@@+        @@@  @@@@@@@                  @@@@@@     @@@@@@  *@@@");
    puts("@@@@       @@    @@@@@@=                  @@@@@@@@           @@@@");
    puts("@@@@@            @@@@@@   @@@@@@@@@@@@@   @@+#@@@@@         @@@@@");
    puts("@@@@@@          @@@@@ @@                  @@@  @@@@        @@@@@@");
    puts("@@@@@@.         @@@  @@@@@               @@@@     @.      #@@@@@@");
    puts("@@@@@@@@        @    @@@  @@@@@     @@@@@@@@             @@@@@@@@");
    puts("@@@@@@@@@            @    @          @    #@            @@@@@@@@@");
    puts("@@@@@@@@@@@           @@@+@          @ *#             @@@@@@@@@@@");
    puts("@@@@@@@@@@@@@       @@@@@@@          @@@@@@@%       @@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@@@@   @@@@@@@@@          @@@@@@@@@    @@@@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=      @@@@@@@@  @@@@@@@@@@@@@@@@@@");
    puts("@@@@@@@@@@@@@@@@@@@@@##@@@@@@@@@@@@@@@@@@@##@@@@@@@@@@@@@@@@@@@@@");
        return 0;
    }
    if (argc>1 && !strcmp(argv[1],"--pack-firmware")) {
        const char *raw=NULL,*target=NULL,*output=NULL;size_t limit=16u*1024u*1024u;int tux=0,skip_screen=0;
        if(argc>2)raw=argv[2];
        for(int i=3;i<argc;i++) {
            if(!strcmp(argv[i],"--tu")) tux=1;
            else if(!strcmp(argv[i],"--n")) skip_screen=1;
            else if(!strcmp(argv[i],"--target") && i+1<argc) target=argv[++i];
            else if(!strcmp(argv[i],"-o") && i+1<argc) output=argv[++i];
            else if(!strcmp(argv[i],"--max-size") && i+1<argc) {
                char *end=NULL;errno=0;unsigned long long n=strtoull(argv[++i],&end,10);
                if(errno || !end || *end || n==0 || n>67108864ULL) {fprintf(stderr,"spc: invalid max size (1..67108864)\n");return 2;}
                limit=(size_t)n;
            } else {fprintf(stderr,"spc: invalid firmware option\n");return 2;}
        }
        return firmware_pack(raw,output,target,limit,tux,skip_screen);
    }
    /* Image mode deliberately bypasses the hosted C code generator. */
    int want_img=0;
    for(int j=1;j<argc;j++)if(!strcmp(argv[j],"--img"))want_img=1;
    if(want_img){
#ifndef _WIN32
        const char *src=NULL,*dst=NULL,*append=NULL;
        unsigned long long image_size=1474560ULL;
        int unlimited=0,explicit_size=0;
        for(int j=1;j<argc;j++){
            if(!strcmp(argv[j],"--img")||!strcmp(argv[j],"--boot")||!strcmp(argv[j],"--n"))continue;
            if(!strcmp(argv[j],"--img-unlimited")){unlimited=1;continue;}
            if(!strcmp(argv[j],"--img-size")&&j+1<argc){
                char *end=NULL;errno=0;
                const char *arg=argv[++j];
                unsigned long long n=strtoull(arg,&end,10);
                if(errno||end==arg||!n||(*end&&end[1])||(*end&&*end!='K'&&*end!='M'&&*end!='G')){
                    fprintf(stderr,"spc --img: invalid size (use e.g. 32M)\n");return 2;
                }
                unsigned long long mult=*end=='K'?1024ULL:*end=='M'?1048576ULL:*end=='G'?1073741824ULL:1ULL;
                if(n>INT64_MAX/mult){fprintf(stderr,"spc --img: size too large\n");return 2;}
                image_size=n*mult;explicit_size=1;continue;
            }
            if(!strcmp(argv[j],"--img-append")&&j+1<argc){append=argv[++j];continue;}
            if(!strcmp(argv[j],"-o")&&j+1<argc){dst=argv[++j];continue;}
            if(argv[j][0]=='-'||src){fprintf(stderr,"spc --img: invalid argument\n");return 2;}
            src=argv[j];
        }
        if(unlimited&&explicit_size){fprintf(stderr,"spc --img: choose --img-size OR --img-unlimited\n");return 2;}
        if(!src){fprintf(stderr,"Usage: spc file.sp --img [--img-unlimited | --img-size 32M] [--img-append data.bin] [-o file.img]\n");return 2;}
        char name[1024];if(!dst){snprintf(name,sizeof name,"%s",src);char *dot=strrchr(name,'.');if(dot&& !strcmp(dot,".sp"))*dot=0;
            if(strlen(name)+5>=sizeof name)return 2;strcat(name,".img");dst=name;}
        return build_bios_img(src,dst,image_size,unlimited,append);
#else
        fprintf(stderr,"spc --img currently requires Linux and GNU binutils\n");return 2;
#endif
    }
    const char *input = NULL;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(); return 0; }
        else if (!strcmp(a, "-o") && i + 1 < argc) opt_out = argv[++i];
        else if (!strcmp(a, "-r") || !strcmp(a, "--run")) opt_run = 1;
        else if (!strcmp(a, "-v")) opt_verbose = 1;
        else if (!strcmp(a, "--L")) opt_log = 1;
        else if (!strcmp(a, "--tokens")) opt_tokens = 1;
        else if (!strcmp(a, "--ast")) opt_ast = 1;
        else if (!strcmp(a, "--emit-c")) opt_emit_c = 1;
        else if (!strcmp(a, "--headless")) opt_headless = 1;
        else if (!strcmp(a, "--img") || !strcmp(a,"--n")) { fprintf(stderr,"spc: %s currently requires --pack-firmware; compiling .sp directly to firmware is not implemented\n",a); return 2; }
        else if (!strcmp(a, "--fast")) opt_fast = 1;
        else if (!strcmp(a, "-k") || !strcmp(a, "--keep-c")) opt_keep = 1;
        else if (a[0] == '-') { fprintf(stderr, "spc: unknown option `%s` (try --help)\n", a); return 2; }
        else if (!input) input = a;
        else { fprintf(stderr, "spc: only one source file at a time (use $import for the rest)\n"); return 2; }
    }
    if (!input) { usage(); return 2; }
#ifndef _WIN32
    use_color = ISATTY(2) && !getenv("NO_COLOR");
#endif

    if (opt_log) {
        snprintf(audit_path, sizeof audit_path, "%s.spc-log.txt", opt_out ? opt_out : input);
        audit_log = fopen(audit_path, "wb");
        if (!audit_log) { perror("spc: cannot create audit log"); return 2; }
        atexit(audit_finish);
        audit("[START] Sparks compiler %s, input=%s", VERSION, input);
    }
    Node *prog = node(N_PROGRAM, NULL);
    stage(1, "Lexing + 2/5 parsing %s ...", input);
    parse_file(input, NULL, prog);
    if (opt_tokens) return 0;
    if (opt_verbose) { printf("      %ld tokens, %d top-level declarations\n", total_tokens, prog->n); }
    fail_if_errors();
    if (opt_ast) { dump_node(prog, 0); return 0; }

    stage(3, "Checking names and types, and writing C code ...");
    compile_program(prog);
    audit("[CHECK] Semantic analysis complete: %d errors, %d warnings", n_errors, n_warnings);
    fail_if_errors();

    Buf c = {0};
    build_c(&c, input);
    audit("[GENERATE] C source length %d bytes; explicit sealed frees %d", c.len, sealed_frees);
    if (opt_emit_c) { fputs(BS(c), stdout); return 0; }

    /* decide the output names */
    char exe[1024];
    if (opt_out) snprintf(exe, sizeof exe, "%s", opt_out);
    else {
        snprintf(exe, sizeof exe, "%s", input);
        char *dot = strrchr(exe, '.'), *sl = strrchr(exe, PATH_SEP);
        if (dot && (!sl || dot > sl) && !strcmp(dot, ".sp")) *dot = 0; else strcat(exe, ".out");
        strcat(exe, EXE_SUFFIX);
    }
    char cfile[1100];
    FILE *f = NULL;
#ifndef _WIN32
    if (opt_keep) {
        if (snprintf(cfile, sizeof cfile, "%s.c", exe) >= (int)sizeof cfile) die("output path too long");
        int fd = open(cfile, O_WRONLY | O_CREAT | O_TRUNC | O_NOFOLLOW, 0600);
        if (fd >= 0) f = fdopen(fd, "wb");
        if (!f && fd >= 0) close(fd);
    } else {
        const char *tmp = getenv("TMPDIR"); if (!tmp || !*tmp) tmp = "/tmp";
        if (snprintf(cfile, sizeof cfile, "%s/spc-XXXXXX", tmp) >= (int)sizeof cfile) die("temp path too long");
        int fd = mkstemp(cfile);
        if (fd >= 0) f = fdopen(fd, "wb");
        if (!f && fd >= 0) { close(fd); unlink(cfile); }
    }
#else
    snprintf(cfile, sizeof cfile, opt_keep ? "%s.c" : "%s.spc_tmp.c", exe);
    f = fopen(cfile, "wb");
#endif
    if (!f) { fprintf(stderr, "spc: can't write `%s`\n", cfile); return 2; }
    size_t written = fwrite(BS(c), 1, (size_t)c.len, f);
    int close_error = fclose(f);
    if (written != (size_t)c.len || close_error) {
        fprintf(stderr, "spc: failed writing generated C\n");
        if (!opt_keep) remove(cfile);
        return 2;
    }
    audit("[SECURITY] Generated C stored in %s", cfile);

    const char *cc = find_cc();
    if (!cc) {
        fprintf(stderr, "spc: I couldn't find a C compiler (tried cc, gcc, clang).\n"
                        "     Install one, or set the SPC_CC environment variable. The C code was saved as %s\n", cfile);
        return 2;
    }
    stage(4, "Wrote %d bytes of C code. The Sealer wrote %d frees into it.", c.len, sealed_frees);
    stage(5, "Compiling the C code with %s ...", cc);
    char sdl[1600] = "";
    if (!lis_root) lis_root = getenv("SPC_LIB_PATH");
    if (mod_on[M_GFX] && !opt_headless && graphics_backend == 1) {
        char *fl = capture_argv("pkg-config", "--cflags", "--libs", "raylib");
        if (!fl) { fprintf(stderr, "spc: raylib not found (install libraylib-dev or use --headless)\n"); if (!opt_keep) remove(cfile); return 2; }
        snprintf(sdl, sizeof sdl, "%s", fl);
    } else if (mod_on[M_GFX] && !opt_headless) {
        char *fl = getenv("SPC_SDL_FLAGS") ? xstrdup(getenv("SPC_SDL_FLAGS")) : capture_argv("sdl2-config", "--cflags", "--libs", NULL);
        if (!fl) fl = capture_argv("pkg-config", "--cflags", "--libs", "sdl2");
        if (!fl) {
            if (!opt_keep) remove(cfile);
            fprintf(stderr, "spc: SDL2 flags unavailable; set SPC_SDL_FLAGS or use --headless\n");
            return 2;
        }
        snprintf(sdl, sizeof sdl, "%s", fl);
    }
    if (lis_pkg[0] && !mod_on[M_GFX]) {
        char *fl = capture_argv("pkg-config", "--cflags", "--libs", lis_pkg);
        if (!fl) { fprintf(stderr, "spc: LIS dependency '%s' not found via pkg-config\n", lis_pkg); if (!opt_keep) remove(cfile); return 2; }
        snprintf(sdl, sizeof sdl, "%s", fl);
    }
    audit("[NATIVE] Invoking C compiler: %s", cc);
    int rc = -1;
#ifndef _WIN32
    char *args[160]; int n = 0;
    args[n++] = (char *)cc;
    char opts[] = SIZE_FLAGS;
    int count = split_flags(opt_fast ? "-O2" : opts, args+n, 60);
    if (count < 0) die("invalid compiler flags");
    n += count;
    args[n++] = "-fstack-protector-strong";
    args[n++] = "-D_FORTIFY_SOURCE=2";
    args[n++] = "-fPIE";
    args[n++] = "-pie";
    args[n++] = "-Wl,-z,relro,-z,now";
    args[n++] = "-w"; args[n++] = "-o"; args[n++] = exe;
    if (getenv("SPC_SPARKDE_X11")) { args[n++] = "-include"; args[n++] = getenv("SPC_SPARKDE_X11"); }
    args[n++] = "-x"; args[n++] = "c"; args[n++] = cfile; args[n++] = "-x"; args[n++] = "none";
    args[n++] = "-lm";
    if (getenv("SPC_SPARKDE_X11")) args[n++] = "-lX11";
    char sdlcopy[1600]; snprintf(sdlcopy, sizeof sdlcopy, "%s", sdl);
    if ((mod_on[M_GFX] && !opt_headless) || lis_pkg[0]) {
        if (mod_on[M_GFX] && !opt_headless) args[n++] = graphics_backend == 1 ? "-DSP_USE_RAYLIB" : "-DSP_USE_SDL";
        count = split_flags(sdlcopy, args+n, 60);
        if (count < 0) die("unsupported SDL compiler flag syntax");
        n += count;
    }
    args[n] = NULL;
    rc = launch(cc, args);
#else
    char cmd[4400];
    snprintf(cmd, sizeof cmd, "%s %s -w -o \"%s\" \"%s\" -lm %s", cc, opt_fast ? "-O2" : SIZE_FLAGS, exe, cfile, sdl);
    rc = system(cmd);
#endif
    audit("[NATIVE] Compiler exit status: %d", rc);
    if (!opt_keep) remove(cfile);
    if (rc != 0) {
        fprintf(stderr, "spc: the C compiler rejected the generated code. That is a bug in spc, not in your program.\n"
                        "     Run again with -k to keep the C file and report it.\n");
        return 2;
    }
    audit("[SUCCESS] Built %s", exe);
    audit_compilation_succeeded = 1;
    printf("Success! Made %s%s\n", exe, n_warnings ? " (with warnings)" : "");
    if (opt_run) {
        printf("--- running %s ---\n", exe);
        fflush(stdout);
#ifndef _WIN32
        char runpath[1100];
        if (strchr(exe, '/')) snprintf(runpath, sizeof runpath, "%s", exe);
        else snprintf(runpath, sizeof runpath, "./%s", exe);
        char *av[] = {runpath, NULL};
        return launch(runpath, av) == 0 ? 0 : 1;
#else
        char run[1100]; snprintf(run, sizeof run, "\"%s\"", exe);
        return system(run) == 0 ? 0 : 1;
#endif
    }
    return 0;
}
