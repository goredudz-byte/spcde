#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || exit 1
rm -f /usr/share/xsessions/spcde.desktop
