#!/bin/sh
ps -C Xorg,sparkde -o pid,comm,rss
for p in $(pgrep -x Xorg || :) $(pgrep -x sparkde || :); do
 echo "PID $p (KiB)"; grep -E '^(Rss|Pss|Private_Dirty|Private_Clean):' /proc/$p/smaps_rollup 2>/dev/null || :
done
