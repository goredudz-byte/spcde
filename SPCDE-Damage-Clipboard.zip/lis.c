#define _POSIX_C_SOURCE 200809L
#include "lis.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>

static int safe_name(const char *s) {
    size_t n = s ? strlen(s) : 0;
    if (!n || n > 80) return 0;
    for (size_t i = 0; i < n; ++i)
        if (!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-') return 0;
    return 1;
}
static void seterr(char *buf, size_t cap, const char *msg) {
    if (buf && cap) snprintf(buf, cap, "%s", msg);
}
static void trim(char *s) {
    size_t n = strlen(s);
    while (n && (s[n-1]=='\n' || s[n-1]=='\r' || isspace((unsigned char)s[n-1]))) s[--n] = 0;
}
int lis_resolve(const char *root, const char *module, const char *alternative,
                LisLibrary *out, char *error, size_t error_size) {
    if (!root || !out || !safe_name(module) || !safe_name(alternative)) {
        seterr(error,error_size,"invalid LIS arguments or library name"); return -1;
    }
    memset(out, 0, sizeof *out);
    char dir[1024], manifest[1200], line[1200];
    if (snprintf(dir,sizeof dir,"%s/%s/%s",root,module,alternative) >= (int)sizeof dir ||
        snprintf(manifest,sizeof manifest,"%s/library.lis",dir) >= (int)sizeof manifest) {
        seterr(error,error_size,"LIS path too long"); return -1;
    }
    FILE *f = fopen(manifest,"r");
    if (!f) { seterr(error,error_size,"LIS alternative not installed"); return -2; }
    char source[128] = "", pkg[128] = "";
    while (fgets(line,sizeof line,f)) {
        trim(line);
        if (!line[0] || line[0]=='#') continue;
        char *eq = strchr(line,'=');
        if (!eq) { fclose(f); seterr(error,error_size,"malformed LIS manifest"); return -3; }
        *eq++ = 0;
        if (!strcmp(line,"source")) snprintf(source,sizeof source,"%s",eq);
        else if (!strcmp(line,"pkg_config")) snprintf(pkg,sizeof pkg,"%s",eq);
        else { fclose(f); seterr(error,error_size,"unknown LIS manifest key"); return -3; }
    }
    fclose(f);
    if (!safe_name(pkg) && pkg[0]) { seterr(error,error_size,"invalid pkg_config name"); return -3; }
    /* Keep the source inside its own backend directory. */
    size_t len = strlen(source);
    if (len < 4 || strcmp(source+len-3,".sp") || strchr(source,'/') || strchr(source,'\\') ||
        strstr(source,"..")) { seterr(error,error_size,"invalid backend source filename"); return -3; }
    if (snprintf(out->source,sizeof out->source,"%s/%s",dir,source) >= (int)sizeof out->source) {
        seterr(error,error_size,"source path too long"); return -3;
    }
    struct stat st;
    if (stat(out->source,&st) || !S_ISREG(st.st_mode)) {
        seterr(error,error_size,"backend source file missing"); return -2;
    }
    snprintf(out->pkg_config,sizeof out->pkg_config,"%s",pkg);
    seterr(error,error_size,""); return 0;
}
