#!/bin/sh
# Read-only: report possible legacy forced startup settings.
for p in /etc/lightdm /etc/X11/Xsession.d /etc/xdg/autostart /etc/skel /etc/profile.d /etc/profile /etc/environment /var/lib/AccountsService/users "$HOME/.dmrc" "$HOME/.xsession" "$HOME/.xinitrc" "$HOME/.profile" "$HOME/.xprofile" "$HOME/.config/autostart"; do
 [ ! -e "$p" ] || grep -rInE 'sparkde|spcde|session-wrapper|user-session|autologin-session' "$p" 2>/dev/null || :
done
